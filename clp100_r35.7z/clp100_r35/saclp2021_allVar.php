<?php

session_start();







if($_SESSION['demoskill']['username']!='ed6skillangels')



{



	header("location:index.php");



}



if(($_SESSION['demoskill']['key']!='sagujarati') && ($_SESSION['demoskill']['key']!='akilasa') && ($_SESSION['demoskill']['key']!='shivclp') &&
    ($_SESSION['demoskill']['key']!='kavisa') &&
    ($_SESSION['demoskill']['key']!='varshaclp') &&
    ($_SESSION['demoskill']['key']!='edsixsa') &&
    ($_SESSION['demoskill']['key']!='tejal')&&
	($_SESSION['demoskill']['key']!='SaClp2021_allVar'))


{



	header("location:index.php");



}



 if((date('Y-m-d')>$_SESSION['demoskill']['edate']) && ($_SESSION['demoskill']['edate']!=0))

{

    	header("location:index.php");

}



?> 

<!DOCTYPE html>

<html lang="en" class=""><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">

    <meta name="description" content="">

    <meta name="author" content="">

	<title>Skill Angels Game Suite</title>

    <!-- Bootstrap Core CSS -->

    <link  href="css/bootstrap.min.css" rel="stylesheet">

	<!-- MetisMenu CSS -->

    <link  href="css/metisMenu.min.css" rel="stylesheet">

	<!-- Custom CSS -->

    <link  href="css/sb-admin-2.css" rel="stylesheet">

    <link  href="css/style.css" rel="stylesheet">

	<!-- Custom Fonts -->

    <link  href="css/font-awesome.min.css" rel="stylesheet" type="text/css">

	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->

    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->

    <!--[if lt IE 9]>

        <script src="js/html5shiv.js"></script>

        <script src="js/respond.min.js"></script>

    <![endif]-->

	<link rel="icon" href="favicon.ico">

<script src="js/jquery-1.11.0.min.js"></script>

<link rel="stylesheet" type="text/css" href="js/fancy/jquery.fancybox.css" media="screen">

<link rel="stylesheet" type="text/css" href="js/fancy/fullscreen.css" media="screen">

<script type="text/javascript" src="js/fancy/jquery.fancybox.js"></script>

 

<style>

.divSep{padding-bottom:10px;}

.minHght{min-height:218px;}

.minHght h4.ng-binding{min-height:28px;}

.active

{

background-color:rgba(0, 67, 113, 0.65);

}

.active a.menuparent

{

color:#fff !important;

}

.menu

{

background-color:#e0f1ef;	

}

.not-active {

   pointer-events: none;

   cursor: default;

}

.nav>li>a:focus, .nav>li>a:hover {

    text-decoration: none;

    background-color: rgb(218, 247, 255);

	color:#35605c !important;

}



</style>

</head>

<body style="" >

<div id="wrapper">

<!-- header starts here -->

 <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">

<div class="pageheader">           

		   <div class="navbar-header">

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">

                    <span class="sr-only">Toggle navigation</span>

                    <span class="icon-bar"></span>

                    <span class="icon-bar"></span>

                    <span class="icon-bar"></span>

                </button>

				<a style="clear:both;" class="navbar-brand navbar-brand1" href="javascript:;"><img src="images/Parrot_logo_wink2.png" width="90" height="90" alt="logo"></a>

			



            </div>

            <!-- /.navbar-header -->

		<div class="" style="text-align: center;">

			<span style="clear:both;position:relative" class="topHead">Puzzle Suite</span>

			<ul style="float:right;" class="nav navbar-top-links navbar-right rightSideButton">

                <a href="logout.php" class="btn btn-primary">Logout</a>

            </ul>

			</div>

            

			</div>

			<div class="pagemenu" style="padding-top: 40px;">

		   <div class="navbar-default sidebar" role="navigation">

                <div class="sidebar-nav navbar-collapse">

                    <ul class="nav" id="side-menu">

				  

						 

                        <li>

                            <a id="I" class="Cognitive  menu" style="cursor:pointer">I<i class="fa fa-gamepad fa-fw"></i></a>

                        </li>  

						<li>

                            <a id="II" class="Cognitive  menu" style="cursor:pointer">II<i class="fa fa-gamepad fa-fw"></i></a>

                        </li>

						<li>

                            <a id="III" class="Cognitive  menu" style="cursor:pointer">III<i class="fa fa-gamepad fa-fw"></i></a>

                        </li>

                       <li>

                            <a id="IV" class="Cognitive  menu" style="cursor:pointer">IV<i class="fa fa-gamepad fa-fw"></i></a>

                        </li>

						<li>

                            <a id="V" class="Cognitive  menu" style="cursor:pointer">V<i class="fa fa-gamepad fa-fw"></i></a>

                        </li>

                       <li>

                            <a id="VI" class="Cognitive  menu" style="cursor:pointer">VI<i class="fa fa-gamepad fa-fw"></i></a>

                        </li>

						<li>

                            <a id="VII" class="Cognitive  menu" style="cursor:pointer">VII<i class="fa fa-gamepad fa-fw"></i></a>

                        </li>

						<li>

                            <a id="VIII" class="Cognitive  menu" style="cursor:pointer">VIII<i class="fa fa-gamepad fa-fw"></i></a>

                        </li>
						
						<li>

                            <a id="IA" class="Cognitive  menu" style="cursor:pointer">IA<i class="fa fa-gamepad fa-fw"></i></a>

                        </li>

						  

                </ul>

				 

				

				 

                     

                       

               

                    </ul>

					<script>

					$(document).ready(function(){

						$(".NewBanner").hide();

					$("div.Cognitive").show();

					$("div.Math").hide();

					$("div.Skill").hide();

					//$("div.Cognitive#LKG").show();

					$("a.menuparent").click(function(){

					$("a.menuparent").parent().removeClass("active");

					$(this).parent().addClass("active");

					});

					$("a.Cognitive").click(function(){

						$(".NewBanner").hide();

					$("div.Math").hide();

					$("div.Life").hide();

					$("div.Skill").hide();

					$("a.Math").removeClass("active");

					$("a.Skill").removeClass("active");

					$("a.Cognitive").removeClass("active");

					$("a.Cognitive#"+$(this).attr('id')).addClass("active");

					$("div.Cognitive").hide();

					$("div.Cognitive#"+$(this).attr('id')).show();



					});

					

					$("a.liaLife").click(function(){

						$(".NewBanner").hide();

					$("div.Cognitive").hide();

					$("div.Math").hide();

					$("div.Skill").hide();

					$("a.Cognitive").removeClass("active");

					$("a.Math").removeClass("active");

					$("a.Skill").removeClass("active");

					$("div.Life").show();

					

					});

					$("a.Math").click(function(){

						$(".NewBanner").hide();

					$("div.Cognitive").hide();

					$("div.Life").hide();

					$("div.Skill").hide();

					$("a.Cognitive").removeClass("active");

					$("a.Math").removeClass("active");

					$("a.Skill").removeClass("active");

					$("a.Math#"+$(this).attr('id')).addClass("active");

					$("div.Math").hide();

					$("div.Math#"+$(this).attr('id')).show();



					});

					$("a.Skill").click(function(){

						$(".NewBanner").hide();

					$("div.Cognitive").hide();

					$("div.Life").hide();

					$("div.Math").hide();

					$("a.Cognitive").removeClass("active");

					$("a.Math").removeClass("active");

					$("a.Skill").removeClass("active");

					$("a.Skill#"+$(this).attr('id')).addClass("active");

					$("div.Skill").hide();

					$("div.Skill#"+$(this).attr('id')).show();



					});

					<?php if(!$_SESSION['demoskill']['ukg']=='1'){ ?>

					$("a.Cognitive#I").click();

					<?php } 

					else{ ?>

					$("a.Cognitive#I").click();	

					<?php } ?>

					});

					</script>

                    <!--

					<ul class="side-skill pageHomePager myprofilehide DashboardPager MyGamesPager MyReportsPager" style="display: block;">

                            	<li>Memory (M)<span class="performanceMemory"></span></li>

                                <li>Visual Processing (VP)<span class="performanceVP"></span></li>

                                <li>Focus and Attention (FA)<span class="performanceFA"></span></li>

                                <li>Problem Solving (PS)<span class="performancePS"></span></li>

                                <li>Linguistics (LI)<span class="performanceLinguistics"></span></li>

                            </ul>

							-->

                </div>

            </div>	

			  </div>	

</nav>

 <!--  header ends here -->

<div id="page-wrapper">

 <!-- home page starts here -->

<!--home page ends here  -->

<!--  Dashboard starts here -->

<!--Dashboard ends here-->

<!--My games starts here -->









<div class="MyGamesPager pageHomePagerHide Dashboardhide myreporthide myprofilehide" style="display: block;">

  <div class="row">

                <div class="col-lg-12">

                    <h1 class="page-header"></h1>

                </div>

                <!-- /.col-lg-12 -->

            </div>

            <div class="row">

			<div class="col-lg-12 NewBanner">

			<!-- <img width="100%" src="images/Newbanner.jpg"/> -->

			

			</div>

      			<div class="col-lg-12">

				 

						

						<div class="contentbox Cognitive" style="display:none;" id="I">

        					<div class="gamesList">

                			<div class="gameBox MemoryGame">

                				<h3 title="" class="ng-binding">Memory</h3>

								<div class="minHght"><h4 title="" class="ng-binding">Fishing</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Fishing&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Fishing_4694063616.png" /></a> 

                    			

                			</div><hr class="CustomHR"/>

							<div class="minHght"><h4 title="" class="ng-binding">BalloonBurst-A1</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BalloonBurst-A1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/BalloonBurst-Level3_2492009233.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Bus Ride</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BusRide-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/BusRide-Level2_6232746895.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/>

								 <div class="minHght"><h4 title="" class="ng-binding">Mind Capture</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MindCapture-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MindCapture-Level3_3766070040.png" /></a> 

                    			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">AlphaNumeric Encode</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=AlphaNumericEncode-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/AlphaNumericEncode-Level3_387589167.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Mom And Me</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MomAndMe&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MomAndMe_6942562656.png.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Mind Capture</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MindCapture-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MindCapture-Level3_3766070040.png" /></a> 

                    			

                			</div> 
						 

           				  	</div>

            				</div><div class="gamesList">

                			<div class="gameBox VisualProcessingGame">

                            	<h3 title="" class="ng-binding">VisualProcessing</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">EdCells</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=EdCells-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/EdCells-Level3_4655870916.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Eye  Cells</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=EyeCells-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/EyeCells-Level3_8897464917.png" /></a>  

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Clock Arithmetic</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ClockArithmetic&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ClockArithmetic_6831587473.png" /></a>  

                			</div>

							

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Face2Face</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Face2Face-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Face2Face-Level1_5178543743.png" /></a>  

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Word Wipe</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WordWipe-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WordWipe-Level2_4875887525.png" /></a>  

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Object Shade</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ObjectShade&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ObjectShade_7239343100.png.png" /></a>  

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Face2Face</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Face2Face-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Face2Face-Level1_5178543743.png" /></a>  

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Character Shade</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=CharacterShade-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/CharacterShade-Level3_3322312142.png" /></a>  

                			</div>

            				</div>

            		</div><div class="gamesList">

                			<div class="gameBox FocusGame">

                            	<h3 title="" class="ng-binding">FocusAndAttention</h3>	

<div class="minHght"><h4 title="" class="ng-binding">Word Spell</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WordSpell-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WordSpell-Level1_4793716236.png.png" /></a> 

                			</div>

							<hr class="CustomHR"/>	

<div class="minHght"><h4 title="" class="ng-binding">Letter Jigsaw</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=LetterJigsaw-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/AlphabetJigsaw-Level3_1882078954.png" /></a> 

                			</div>

							<hr class="CustomHR"/>							

                				<div class="minHght"><h4 title="" class="ng-binding">Number Jigsaw</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=NumberJigsaw-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/NumberJigsaw-Level3_7143653305.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Stranger Grid</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=StrangerGrid-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/StrangerGrid_9728514011.png.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">MoreLess</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MoreLess&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/StrangerGrid_9728514011.png.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Spot Me</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=SpotMe-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/SpotMe-Level2_5270674000.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Ball Bounce</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BallBounce-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WordSpell-Level1_4793716236.png.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Star Light</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=StarLight-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/StarLight-Level2_988681958.png" /></a> 

                			</div>

							 

            				</div>  

            				</div><div class="gamesList">

                			<div class="gameBox ProblemSolvingGame">

                            	<h3 title="" class="ng-binding">ProblemSolving</h3>

								<div class="minHght"><h4 title="" class="ng-binding">Add Master</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=AddMaster-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/AddMaster-Level3_2056090440.png" /></a> 

                			</div>

							<hr class="CustomHR"/>

							<div class="minHght"><h4 title="" class="ng-binding">Clock Arithmetic</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ClockArithmetic&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ClockArithmetic_6831587473.png" /></a> 

                			</div><hr class="CustomHR"/>

                				<div class="minHght"><h4 title="" class="ng-binding">Number Decode</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=NumberDecode&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/NumberDecode-Level2_2425581049.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">What Comes Next</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WhatComesNext&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WhatComesNext-Level1_3932243706.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Reshuffle</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Reshuffle&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Reshuffle-Level3_2661516019.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Word Shapes</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WordShapes-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WordShapes-Level3_9543727268.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Descending Order</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=DescendingOrder&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WordShapes-Level3_9543727268.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Dice Addition</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=DiceAddition-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Reshuffle-Level3_2661516019.png" /></a> 

                			</div>
							
							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Date</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Date-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Reshuffle-Level3_2661516019.png" /></a> 

                			</div>

							

            				</div>

            				</div><div class="gamesList">

                			<div class="gameBox LinguisticsGame">

                            	<h3 title="" class="ng-binding">Linguistics</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">Compound Words </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=CompoundWords&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ArrangeTheWords-Level2_2614120254.png" /></a> 

                				</div>

								<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Who Am I-Birds </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WhoAmI-Birds&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WhoAmI-Birds_7869069152.png.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Who Am I-Colors </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WhoAmI-Colors&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WhoAmI-Colors_1446446431.png.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Who Am I-HouseHoldThings </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WhoAmI-HouseHoldThings&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/HouseHoldThings_8783441544.png.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Who Am I-Shapes</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WhoAmI-Shapes&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WhoAmI-Shapes_7515025790.png.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Who Am I-Vegetables</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WhoAmI-Vegetables&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WhoAmI-Vegetables_7871570191.png.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Who Am I-DomesticAnimals </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WhoAmI-DomesticAnimals&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WhoAmI-DomesticAnimals_818332880.png.png" /></a> 

                			</div> 

            				</div> 

            			</div></div> 

						

						<div class="contentbox Cognitive" style="display:none;" id="II">

        					<div class="gamesList">

                			<div class="gameBox MemoryGame">

                				<h3 title="" class="ng-binding">Memory</h3>

								<div class="minHght"><h4 title="" class="ng-binding">Mind Capture</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MindCapture-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MindCapture-Level4_95845567.png" /></a> 

                    			

                			</div><hr class="CustomHR"/>

							<div class="minHght"><h4 title="" class="ng-binding">Balloon Burst</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BalloonBurst-A2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MemoryCheck-Level2_8882285202.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Cycle Race</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=CycleRace-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/CycleRace-Level3_6173525671.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/>

								 <div class="minHght"><h4 title="" class="ng-binding">Memory Check</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MemoryCheck-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MemoryCheck-Level3_7822075057.png" /></a> 

                    			</div><hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Mind Capture</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MindCapture-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MindCapture-Level3_3766070040.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Sequence Memory</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=SequenceMemory-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/SequenceMemory-Level3_9452287289.png" /></a> 

                    			

                			</div> 
							 
 

           				  	</div>

            				</div><div class="gamesList">

                			<div class="gameBox VisualProcessingGame">

                            	<h3 title="" class="ng-binding">VisualProcessing</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">EdCells</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=EdCells-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/EdCells-Level3_4655870916.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Eye Cells</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=EyeCells-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/EyeCells-Level3_8897464917.png" /></a>  

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Reflection Read</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ReflectionRead-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ReflectionRead-Level1_7608671374.png" /></a>  

                			</div>  

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Word Wipe</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WordWipe-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WordWipe-Level2_4875887525.png" /></a>  

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Character Shade</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=CharacterShade-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/CharacterShade-Level3_3322312142.png" /></a>  

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Missing Piece</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MissingPiece-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MissingPiece-Level1_5453919009.png" /></a>  

                			</div>

							<!--<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Best Fit Optimized</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="swfn/BestFit-Level4a.html" class="fancybox fancybox.iframe"> <img  src="images/icon/BestFit-Level3_8792649721.png" /></a>  

                			</div>

							-->
 

            				</div>

            		</div><div class="gamesList">

                			<div class="gameBox FocusGame">

                            	<h3 title="" class="ng-binding">FocusAndAttention</h3>	

<div class="minHght"><h4 title="" class="ng-binding">Spot Me</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=SpotMe-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/SpotMe-Level2_5270674000.png" /></a> 

                			</div>

							<hr class="CustomHR"/>	

<div class="minHght"><h4 title="" class="ng-binding">Letter Jigsaw</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=LetterJigsaw-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/AlphabetJigsaw-Level3_1882078954.png" /></a> 

                			</div>

							<hr class="CustomHR"/>							

                				<div class="minHght"><h4 title="" class="ng-binding">Object Spell</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ObjectSpell-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ObjectSpell-Level2_9643486370.png" /></a> 

                			</div><hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Down Under</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=DownUnder-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/DownUnder-Level2_5347298909.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Spot Me </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=SpotMe-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/SpotMe-Level3_4077972709.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Basket Ball </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BasketBall-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WordSpell-Level1_4793716236.png.png" /></a> 

                			</div> 
							

            				</div>  

            				</div><div class="gamesList">

                			<div class="gameBox ProblemSolvingGame">

                            	<h3 title="" class="ng-binding">ProblemSolving</h3>

								<div class="minHght"><h4 title="" class="ng-binding">Number Decode </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=NumberDecode-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/NumberDecode-Level2_2425581049.png" /></a> 

                			</div>

							<hr class="CustomHR"/>

							<div class="minHght"><h4 title="" class="ng-binding">Reverse Reading</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ReverseReading-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ReverseReading-Level1_3469542353.png" /></a> 

                			</div><hr class="CustomHR"/>

                				<div class="minHght"><h4 title="" class="ng-binding">Para Master</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ParaMaster-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ParaMaster-Level3_8316638404.png" /></a> 

                			</div><hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Numbers On The Wheel</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=NumbersOnTheWheel-A2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/NumbersOnTheWheel-Level3_7181768785.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Dice Addition</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=DiceAddition-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WordShapes-Level3_9543727268.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Numbers On The Wheel</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=NumbersOnTheWheel-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/NumbersOnTheWheel-Level3_7181768785.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Missing Shapes</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MissingShapes-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/NumbersOnTheWheel-Level3_7181768785.png" /></a> 

                			</div>
 

							

            				</div>

            				</div><div class="gamesList">

                			<div class="gameBox LinguisticsGame">

                            	<h3 title="" class="ng-binding">Linguistics</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">Anagrams-Food </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Anagrams-Food&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Anagrams-Food_9358940329.png" /></a> 

                				</div>

								<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Who Am I-Clothes</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WhoAmI-Clothes&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WhoAmI-Clothes_236435011.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Who Am I-Flowers</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WhoAmI-Flowers&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WhoAmI-Flowers_4361387616.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Who Am I-Insects</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WhoAmI-Insects&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WhoAmI-Insects_9486121060.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Who Am I-School</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WhoAmI-School&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WhoAmI-School_1506193187.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Who Am I-WildAnimals</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WhoAmI-WildAnimals&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WhoAmI-WildAnimals_8843113635.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Cross Words</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=CrossWords&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WhoAmI-Flowers_4361387616.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">FindMe </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=FindMe&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Anagrams-CountryNames_9848174657.png" /></a> 

                			</div>

							<!--<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">BalloonWorks-Level1 </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="swfn/BalloonWorks-Level1.html" class="fancybox fancybox.iframe"> <img  src="images/icon/BalloonBurst-Level1_8117342898.png" /></a> 

                			</div>

							 -->

            				</div> 

            			</div></div>

						

						 

						 

						 

						 

						 

						 

						 <div class="contentbox Cognitive" style="display:none;" id="III">

        					<div class="gamesList">

                			<div class="gameBox MemoryGame">

                				<h3 title="" class="ng-binding">Memory</h3>

								<div class="minHght"><h4 title="" class="ng-binding">Memory Master</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MemoryMaster&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/BalloonBurst-Level3_2492009233.png" /></a> 

                    			

                			</div><hr class="CustomHR"/>

							<div class="minHght"><h4 title="" class="ng-binding">AlphaNumeric Encode</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=AlphaNumericEncode-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/AlphaNumericEncode-Level3_387589167.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Balloon Burst</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BalloonBurst-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/BalloonBurst-Level3_2492009233.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/>

								 <div class="minHght"><h4 title="" class="ng-binding">Cycle Race </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=CycleRace-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/CycleRace-Level3_6173525671.png" /></a> 

                    			</div><hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Memory Check</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MemoryCheck-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MemoryCheck-Level3_7822075057.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Bus Ride</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BusRide-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/BusRide-Level2_6232746895.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Ball Arrangement   </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BallArrangement&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MindCapture-Level4_95845567.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Mind Capture</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MindCapture-Level5&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MindCapture-Level5_2807246898.png" /></a> 

                     			

                			</div>

           				  	</div>

            				</div><div class="gamesList">

                			<div class="gameBox VisualProcessingGame">

                            	<h3 title="" class="ng-binding">VisualProcessing</h3>

                				

							 <div class="minHght"><h4 title="" class="ng-binding">Just Not Half</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=JustNotHalf-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/JustNotHalf-Level1_6506787771.png" /></a>  

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">EdCells </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=EdCells-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/EdCells-Level3_4655870916.png" /></a>  

                			</div>

							

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Hand2Hand </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Hand2Hand&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Hand2Hand_5783699043.png" /></a>  

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Reverse Reading</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ReverseReading-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ReverseReading-Level1_3469542353.png" /></a>  

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Form The Square </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=FormTheSquare-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/FormTheSquare-Level1_9003437426.png" /></a>  

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Flipped Image</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=FlippedImage-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/AnimalWipe_6567529789.png" /></a>  

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Best Fit</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BestFit-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/BestFit-Level2.png" /></a>  

                			</div>
							
							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Animal Wipe</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=AnimalWipe&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/AnimalWipe_6567529789.png" /></a>  

                			</div>

							 

            				</div>

            		</div><div class="gamesList">

                			<div class="gameBox FocusGame">

                            	<h3 title="" class="ng-binding">FocusAndAttention</h3>	

<div class="minHght"><h4 title="" class="ng-binding">Animal Spell</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=AnimalSpell&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/AnimalSpell_5479293791.png" /></a> 

                			</div>

							<hr class="CustomHR"/>	

<div class="minHght"><h4 title="" class="ng-binding">Balloon Light </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BalloonLight-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/DarkLight-Level1_1779258348.png

" /></a> 

                			</div>

							<hr class="CustomHR"/>							

                				<div class="minHght"><h4 title="" class="ng-binding">Deep Under </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=DeepUnder-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/DeepUnder-Level1_7213067221.png" /></a> 

                			</div><hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Number Jigsaw </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=NumberJigsaw-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/DeepUnder-Level1_7213067221.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Object Spell</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ObjectSpell-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ObjectSpell-Level2_9643486370.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Basket Ball</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BasketBall-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/DeepUnder-Level1_7213067221.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Car Park</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=CarPark-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/CarPark-Level1_8054239703.png" /></a> 

                			</div> 
							 

            				</div>  

            				</div><div class="gamesList">

                			<div class="gameBox ProblemSolvingGame">

                            	<h3 title="" class="ng-binding">ProblemSolving</h3>

								<div class="minHght"><h4 title="" class="ng-binding">Add Master</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=AddMaster-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/AddMaster-Level3_2056090440.png" /></a> 

                			</div>

							<hr class="CustomHR"/>

							<div class="minHght"><h4 title="" class="ng-binding">Heavy Or Light</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=HeavyOrLight-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/HeavyOrLight-Level2_607259180.png" /></a> 

                			</div><hr class="CustomHR"/>

                				<div class="minHght"><h4 title="" class="ng-binding">Shape Rollers </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ShapeRollers-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ShapeRollers-Level4_452656652.png" /></a> 

                			</div><hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Para Master</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ParaMaster-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ParaMaster-Level3_8316638404.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Word Shapes</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WordShapes-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WordShapes-Level3_9543727268.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Word Walls</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WordWalls-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WordWalls-Level1_1536627309.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Number Decode </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=NumberDecode-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/NumberDecode-Level2_2425581049.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Find The Vertex</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=FindTheVertex&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WordWalls-Level1_1536627309.png" /></a> 

                			</div>

							

            				</div>

            				</div><div class="gamesList">

                			<div class="gameBox LinguisticsGame">

                            	<h3 title="" class="ng-binding">Linguistics</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">Anagrams-CountryNames</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Anagrams-CountryNames&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Anagrams-CountryNames_9848174657.png" /></a> 

                				</div>

								<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Anagrams-Clothes </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Anagrams-Clothes&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Anagrams-Clothing_8464276143.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Arrange The Words </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ArrangeTheWords-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ArrangeTheWords-Level2_2614120254.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Name Land </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=NameLand-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/NameLand-Level1_3850891082.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Vowel Magic</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=VowelMagic&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/VowelMagic_9324571550.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Who Am I-Birthday</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WhoAmI-Birthday&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WhoAmI-Birthday_9790617101.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Who Am I-SeaAnimals</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WhoAmI-SeaAnimals&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WhoAmI-SeaAnimals_9400465255.png" /></a> 

                			</div>

							 

            				</div> 

            			</div></div>

						

						

						

						

						

						<div class="contentbox Cognitive" style="display:none;" id="IV">

        					<div class="gamesList">

                			<div class="gameBox MemoryGame">

                				<h3 title="" class="ng-binding">Memory</h3>

								<div class="minHght"><h4 title="" class="ng-binding">Back Track </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BackTrack-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/BackTrack-Level1_257858377.png" /></a> 

                    			

                			</div><hr class="CustomHR"/>

							<div class="minHght"><h4 title="" class="ng-binding">Balloon Burst </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BalloonBurst-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/BalloonBurst-Level3_2492009233.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Whats In Store </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WhatsInStore-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WhatsInStore-Level2_3776093176.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/>

								 <div class="minHght"><h4 title="" class="ng-binding">Dial A Number </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=DialAnumber&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/DialANumber_8347820923.png" /></a> 

                    			</div><hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Cycle Race </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=CycleRace-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/CycleRace-Level3_6173525671.png" /></a>  

                			</div>  
							<hr class="CustomHR"/>

								 <div class="minHght"><h4 title="" class="ng-binding">Sequence Memory </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=SequenceMemory-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/SequenceMemory-Level3_9452287289.png" /></a> 

                    			</div>
								
								<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Whats In Store </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WhatsInStore-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WhatsInStore-Level1_99412277.png" /></a> 

                    			

                			</div>
							 
           				  	</div>

            				</div><div class="gamesList">

                			<div class="gameBox VisualProcessingGame">

                            	<h3 title="" class="ng-binding">VisualProcessing</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">Eye Cells </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=EyeCells-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/EyeCells-Level3_8897464917.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Find The Twins </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=FindTheTwins-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/FindTheTwins-Level1_7979904958.png" /></a>  

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Form The Square </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=FormTheSquare-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/FormTheSquare-Level2_925395623.png" /></a>  

                			</div>

							

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Reverse Reading  </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ReverseReading-Level5&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ReverseReading-Level5_5669675888.png" /></a>  

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding"> Character Shade </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=CharacterShade-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/CharacterShade-Level4_7572658732.png" /></a>  

                			</div>   

            				</div>

            		</div><div class="gamesList">

                			<div class="gameBox FocusGame">

                            	<h3 title="" class="ng-binding">FocusAndAttention</h3>	

<div class="minHght"><h4 title="" class="ng-binding">Last Legend  </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=LastLegend-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/LastLegend-Level3_5495434515.png" /></a> 

                			</div>

							<hr class="CustomHR"/>	

<div class="minHght"><h4 title="" class="ng-binding">Balloon Light </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BalloonLight-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/DarkLight-Level3_6337577155.png" /></a> 

                			</div>

							<hr class="CustomHR"/>							

                				<div class="minHght"><h4 title="" class="ng-binding">Ball Shooter </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BallShooter-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Ball_Shooter.png" /></a> 

                			</div><hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Down Under  </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=DownUnder-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/DownUnder-Level2_5347298909.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Number Jigsaw  </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=NumberJigsaw-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/NumberJigsaw-Level3_7143653305.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Spot Me </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=SpotMe-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/SpotMe-Level4_1111856144.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Deep Under </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=DeepUnder-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/DeepUnder-Level2_5933240540.png

" /></a> 

                			</div>

							 <hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Odd Ball </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=OddBall-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/OddBall-Level1_1096781706.png" /></a> 

                			</div>

							 

            				</div>  

            				</div><div class="gamesList">

                			<div class="gameBox ProblemSolvingGame">

                            	<h3 title="" class="ng-binding">ProblemSolving</h3>

								<div class="minHght"><h4 title="" class="ng-binding">Missing Dots</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MissingDots&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ParaMaster-Level3_8316638404.png" /></a> 

                			</div>

							<hr class="CustomHR"/>

							<div class="minHght"><h4 title="" class="ng-binding">Add Master </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=AddMaster-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/AddMaster-Level3_2056090440.png" /></a> 

                			</div><hr class="CustomHR"/>

                				<div class="minHght"><h4 title="" class="ng-binding">Fit Me Right  </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=FitMeRight-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/FitMeRight-Level1_9128276687.png" /></a> 

                			</div><hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Numbers On The Wheel </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=NumbersOnTheWheel-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/NumbersOnTheWheel-Level3_7181768785.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Para Master </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ParaMaster-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ParaMaster-Level3_8316638404.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Reshuffle </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Reshuffle-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Reshuffle-Level3_2661516019.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Word Walls </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WordWalls-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WordWalls-Level2_7409162675.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Word Shapes </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WordShapes-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WordShapes-Level4_9880864322.png" /></a> 

                			</div>

							

            				</div>

            				</div><div class="gamesList">

                			<div class="gameBox LinguisticsGame">

                            	<h3 title="" class="ng-binding">Linguistics</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">Anagrams-Colors</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Anagrams-Colors&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Anagrams-Colors_4401654419.png" /></a> 

                				</div>

								<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Anagrams-Math </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Anagrams-Math&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Anagrams-Math_3996595479.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Anagrams-Plants </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Anagrams-Plants&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Anagrams-Plants_2974008941.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Arrange The Words </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ArrangeTheWords-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ArrangeTheWords-Level3_6521334904.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Missing Letter </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MissingLetter-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MissingLetter-Level1_4396478235.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Name Land  </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=NameLand-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/NameLand-Level2_9281079615.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Arrange The Words </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ArrangeTheWords-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ArrangeTheWords-Level2_2614120254.png" /></a> 

                			</div>

							<!-- <hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Missing Letter</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="swfn/MissingLetter-Level2.html" class="fancybox fancybox.iframe"> <img  src="images/icon/MissingLetter-Level2_3469503405.png" /></a> 

                			</div>--> 

            				</div> 

            			</div></div>

						

						

						

						

						

						<div class="contentbox Cognitive" style="display:none;" id="V">

        					<div class="gamesList">

                			<div class="gameBox MemoryGame">

                				<h3 title="" class="ng-binding">Memory</h3>

								 <div class="minHght"><h4 title="" class="ng-binding">Planets </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Planets&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/BalloonBurst-Level4_2785141328.png" /></a> 

                    			

                			</div><hr class="CustomHR"/> 

							<div class="minHght"><h4 title="" class="ng-binding">Back Track </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BackTrack-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/BackTrack-Level2_16276659.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Balloon Burst </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BalloonBurst-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/BalloonBurst-Level4_2785141328.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/>

								 <div class="minHght"><h4 title="" class="ng-binding">Sequence Memory </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=SequenceMemory-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/SequenceMemory-Level4_9387351195.png" /></a> 

                    			</div><hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Cycle Race </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=CycleRace-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/CycleRace-Level4_4780295565.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Memory Check  </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MemoryCheck-Level5&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MemoryCheck-Level5_9116933126.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Mind Capture </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MindCapture-Level6&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MindCapture-Level6_6117593380.png" /></a> 

                    			

                			</div>

							 <hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Route Memory  </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=RouteMemory-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/RouteMemory-Level1_3141601332.png" /></a> 

                     			

                			</div> 

           				  	</div>

            				</div><div class="gamesList">

                			<div class="gameBox VisualProcessingGame">

                            	<h3 title="" class="ng-binding">VisualProcessing</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">I Am Cube </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=IAmCube-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/IAmCube-Level1_3901067436.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Just Not Half </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=JustNotHalf-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/JustNotHalf-Level2_2203953666.png" /></a>  

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Reverse Reading </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ReverseReading-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ReverseReading-Level3_5393561688.png" /></a>  

                			</div>

							

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Reflection Read </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ReflectionRead-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ReflectionRead-Level3_7118542841.png" /></a>  

                			</div>
 

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Reverse Reading  </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ReverseReading-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ReverseReading-Level3_5393561688.png" /></a>  

                			</div> 

							 

            				</div>

            		</div><div class="gamesList">

                			<div class="gameBox FocusGame">

                            	<h3 title="" class="ng-binding">FocusAndAttention</h3>	

<div class="minHght"><h4 title="" class="ng-binding">Car Park  </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=CarPark-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/CarPark-Level2_116904969.png" /></a> 

                			</div>

							 <hr class="CustomHR"/>	

<div class="minHght"><h4 title="" class="ng-binding">Last Legend  </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=LastLegend-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/LastLegend-Level4_3372493218.png" /></a> 

                			</div>

							<hr class="CustomHR"/>							

                				<div class="minHght"><h4 title="" class="ng-binding">Letter Jigsaw </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=LetterJigsaw-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/AlphabetJigsaw-Level3_1882078954.png" /></a> 

                			</div><hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Number Jigsaw </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=NumberJigsaw-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/NumberJigsaw-Level4_3807144016.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Shape Rollers </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ShapeRollers-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ShapeRollers-Level1_1497070817.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Deep Under </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=DeepUnder-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/DeepUnder-Level3_9918525810.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Shape Vs Color</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ShapeVsColor&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ShapeVsColor_5882827830.png" /></a> 

                			</div> 

            				</div>  

            				</div><div class="gamesList">

                			<div class="gameBox ProblemSolvingGame">

                            	<h3 title="" class="ng-binding">ProblemSolving</h3>
 

							<div class="minHght"><h4 title="" class="ng-binding">Number Series </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=NumberSeries-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/NumberSeries-Level1_292791444.png" /></a> 

                			</div><hr class="CustomHR"/>

                				<div class="minHght"><h4 title="" class="ng-binding">Para Master </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ParaMaster-Level5&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ParaMaster-Level5_5265605337.png" /></a> 

                			</div><hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Numbers On The Wheel </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=NumbersOnTheWheel-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/NumbersOnTheWheel-Level4_1754132225.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Para Master  </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ParaMaster-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ParaMaster-Level4_3163872654.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Number Series  </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=NumberSeries-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/NumberSeries-Level2_1761797624.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Reshuffle </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Reshuffle-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Reshuffle-Level4_4280022010.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Analogy Action </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=AnalogyAction-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/AnalogyAction-Level1_6299363239.png" /></a> 

                			</div>

							

            				</div>

            				</div><div class="gamesList">

                			<div class="gameBox LinguisticsGame">

                            	<h3 title="" class="ng-binding">Linguistics</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">Missing Letter </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MissingLetter-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MissingLetter-Level4_7994128023.png" /></a> 

                				</div>

								<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Arrange The Words </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ArrangeTheWords-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ArrangeTheWords-Level4_1263861129.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Anagrams-HouseHold</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Anagrams-HouseHold&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Anagrams-Household_4300776333.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Word Stem</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WordStem&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WordStem_1920470679.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Missing Letter </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MissingLetter-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MissingLetter-Level2_3469503405.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">HomoPhones </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=HomoPhones-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/HomoPhones-Level1_1627698740.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Root Words 	</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=RootWords-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/RootWords-Level1_8710642922.png" /></a> 

                			</div> 
							 

            				</div> 

            			</div></div>

						

						

						

						

						

						

						<div class="contentbox Cognitive" style="display:none;" id="VI">

        					<div class="gamesList">

                			<div class="gameBox MemoryGame">

                				<h3 title="" class="ng-binding">Memory</h3>

								<div class="minHght"><h4 title="" class="ng-binding">AlphaNumeric Encode </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=AlphaNumericEncode-Level5&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/AlphaNumericEncode-Level5_5666280859.png" /></a> 

                    			

                			</div><hr class="CustomHR"/>

							<div class="minHght"><h4 title="" class="ng-binding">Cycle Race </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=CycleRace-Level5&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/CycleRace-Level5_1506978459.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Animal Watch </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=AnimalWatch-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/AnimalWatch-Level1_8736748136.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/>

								 <div class="minHght"><h4 title="" class="ng-binding">Sequence Memory</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=SequenceMemory-Level5&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/SequenceMemory-Level5_7487447718.png" /></a> 

                    			</div><hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Back Track </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BackTrack-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/BackTrack-Level3_4500490999.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Animal Watch </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=AnimalWatch-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/AnimalWatch-Level2_2552103889.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Whats In Store </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WhatsInStore-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WhatsInStore-Level3_4075730568.png" /></a> 

                    			

                			</div>

							 <hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Route Memory  </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=RouteMemory-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/RouteMemory-Level2_3784374403.png" /></a> 

                     			

                			</div>

           				  	</div>

            				</div>

							<div class="gamesList">

                			<div class="gameBox VisualProcessingGame">

                            	<h3 title="" class="ng-binding">VisualProcessing</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">Just Not Half </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=JustNotHalf-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/JustNotHalf-Level3_486829234.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Find My Pair</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=FindMyPair&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/FindTheTwins-Level2_3434965950.png" /></a>  

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Cube Sherlock </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=CubeSherlock-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/CubeSherlock-Level1_9494013660.png" /></a>  

                			</div>

							

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Find The Twins </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=FindTheTwins-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/FindTheTwins-Level2_3434965950.png" /></a>  

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Reverse Reading </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ReverseReading-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ReverseReading-Level4_3547282922.png" /></a>  

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">I Am Cube </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=IAmCube-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/IAmCube-Level2_7666559526.png" /></a>  

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Reflection Read </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ReflectionRead-Level5&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ReflectionRead-Level5_3237627618.png" /></a>  

                			</div>
 

            				</div>

            		</div>

					

					

					<div class="gamesList">

                			<div class="gameBox FocusGame">

                            	<h3 title="" class="ng-binding">FocusAndAttention</h3>	

<div class="minHght"><h4 title="" class="ng-binding">Balloon Light </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BalloonLight-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/DarkLight-Level5_4619532418.png" /></a> 

                			</div>

							<hr class="CustomHR"/>	

<div class="minHght"><h4 title="" class="ng-binding">Deep Under </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=DeepUnder-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/DeepUnder-Level4_8108292836.png" /></a> 

                			</div>

							<hr class="CustomHR"/>							

                				<div class="minHght"><h4 title="" class="ng-binding">Shape Rollers </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ShapeRollers-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ShapeRollers-Level2_5863707675.png" /></a> 

                			</div><hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Last Legend </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=LastLegend-Level5&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/LastLegend-Level5_7495082467.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Rainbow </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Rainbow-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Rainbow-Level1_1321175633.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Discrete Paddle </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=DiscretePaddle-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/DiscretePadle-Level1_2005080394.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Shape Rollers </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ShapeRollers-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ShapeRollers-Level2_5863707675.png" /></a> 

                			</div>
 

            				</div>  

            				</div>

							

							<div class="gamesList">

                			<div class="gameBox ProblemSolvingGame">

                            	<h3 title="" class="ng-binding">ProblemSolving</h3>

								<div class="minHght"><h4 title="" class="ng-binding">Color Guess</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ColorGuess&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ColorGuess_7757099242.png" /></a> 

                			</div>

							<hr class="CustomHR"/>

							<div class="minHght"><h4 title="" class="ng-binding">Fit Me Right </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=FitMeRight-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/FitMeRight-Level2_340231573.png" /></a> 

                			</div>

							<hr class="CustomHR"/>

                				<div class="minHght"><h4 title="" class="ng-binding">Numbers On The Wheel  </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=NumbersOnTheWheel-Level5&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/NumbersOnTheWheel-Level5_1027476550.png" /></a> 

                			</div>

						

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Take Turns </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=TakeTurns-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/TakeTurns-Level1_1136886626.png" /></a> 

                			</div> 
							
							<hr class="CustomHR"/>

                				<div class="minHght"><h4 title="" class="ng-binding">Reshuffle </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Reshuffle-Level5&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Reshuffle-Level5_1823949897.png" /></a> 

                			</div>
							
							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Master Venn </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MasterVenn-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MasterVenn-Level1_7031834167.png" /></a> 

                			</div>
							 

            				</div>

            				</div>

							

							<div class="gamesList">

                			<div class="gameBox LinguisticsGame">

                            	<h3 title="" class="ng-binding">Linguistics</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">Anagrams-Jobs</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Anagrams-Jobs&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Anagrams-Jobs_2256901105.png" /></a> 

                				</div> 

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Anagrams-Schools</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Anagrams-Schools&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Anagrams-School_220320839.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Anagrams-Sports</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Anagrams-Sports&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Anagrams-Sports_9202636964.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Anagrams-Weather</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Anagrams-Weather&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Anagrams-Weather_3403326552.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Arrange The Words </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ArrangeTheWords-Level5&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ArrangeTheWords-Level5_4423534446.png" /></a> 

                			</div>

							 
							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Missing Letter </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MissingLetter-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MissingLetter-Level3_7274801447.png" /></a> 

                			</div>
 
							 

            				</div> 

            			</div> 

						

						</div>

						

						

						

						<div class="contentbox Cognitive" style="display:none;" id="VII">

        					<div class="gamesList">

                			<div class="gameBox MemoryGame">

                				<h3 title="" class="ng-binding">Memory</h3>

								<div class="minHght"><h4 title="" class="ng-binding">Spot My Place </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=SpotMyPlace-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/SpotMyPlace-Level1_8555905618.png" /></a> 

                    			

                			</div>

							 <hr class="CustomHR"/>

							<div class="minHght"><h4 title="" class="ng-binding">Coordinate Graph </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=CoordinateGraph-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/CoordinateGraph-Level1_1309713018.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Bug Spot </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BugSpot-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/BugSpot-Level1_4068491952.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/>

								 <div class="minHght"><h4 title="" class="ng-binding">Drop Box</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=DropBox-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/DropBox-Level1_6700938204.png" /></a> 

                    			</div>

								

								<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Graph Decoder </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=GraphDecoder&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/GraphDecoder_6767004569.png" /></a> 

                    			

                			</div> 

           				  	</div>

            				</div>

							<div class="gamesList">

                			<div class="gameBox VisualProcessingGame">

                            	<h3 title="" class="ng-binding">VisualProcessing</h3>

                				 <div class="minHght"><h4 title="" class="ng-binding">Flip Trick </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=FlipTrick-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/FlipTrick-Level1_6290403776.png" /></a>  

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Mirror Image </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MirrorImage-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MirrorImage-Level1_4596876199.png" /></a>  

                			</div>

							

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Cube Sherlock </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=CubeSherlock-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/CubeSherlock-Level2_2803261997.png" /></a>  

                			</div> 

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Missing Piece </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MissingPiece-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/FindTheTwins-Level3_8413515225.png" /></a>  

                			</div>
							
							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Water Image </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WaterImage-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WaterImage-Level1_4578736186.png" /></a>  

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Reflection Read </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ReflectionRead-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ReflectionRead-Level4_4669125583.png" /></a>  

                			</div> 
            				</div>

            		</div>

					

					

					<div class="gamesList">

                			<div class="gameBox FocusGame">

                            	<h3 title="" class="ng-binding">FocusAndAttention</h3>	

<div class="minHght"><h4 title="" class="ng-binding">Balloon Light </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BalloonLight-Level5&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/DarkLight-Level5_4619532418.png" /></a> 

                			</div>

							
							<hr class="CustomHR"/>							

                				<div class="minHght"><h4 title="" class="ng-binding">Color In Color </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ColorInColor-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ColorInColor-Level2_4620457286.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Light Rays  </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=LightRays-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/LightRays1.png" /></a> 

                			</div>
							
							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Rainbow </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Rainbow-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Rainbow-Level2_2451191339.png" /></a> 

                			</div> 
							

							 <hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Shape Rollers </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ShapeRollers-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ShapeRollers-Level4_452656652.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Shape Vs Color Vs Pattern </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ShapeVsColorVsPattern-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ShapeVsColorVsPattern-Level1_9182052793.png" /></a> 

                			</div> 
							

            				</div>  

            				</div>

							

							<div class="gamesList">

                			<div class="gameBox ProblemSolvingGame">

                            	<h3 title="" class="ng-binding">ProblemSolving</h3>
								
								
								<div class="minHght"><h4 title="" class="ng-binding">Analogy Action	</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=AnalogyAction-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/AnalogyAction-Level2_5585269308.png" /></a> 

                			</div>
								
							<hr class="CustomHR"/>	 

							<div class="minHght"><h4 title="" class="ng-binding">A Teddy For A Teddy </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ATeddyForATeddy-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ATeddyForATeddy-Level3_1824636519.png" /></a> 

                			</div>
							
							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Number Puzzle </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=NumberPuzzle-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/NumberPuzzle-Level2_6727183759.png" /></a> 

                			</div>
							
							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Numbers On The Wheel </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=NumbersOnTheWheel-Level6&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/NumbersOnTheWheel-Level6_2458961391.png" /></a> 

                			</div> 
							

							<hr class="CustomHR"/> 

							<div class="minHght"><h4 title="" class="ng-binding">Reshuffle </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Reshuffle-Level6&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Reshuffle-Level6_4803005247.png" /></a> 

                			</div><hr class="CustomHR"/>

                				<div class="minHght"><h4 title="" class="ng-binding">Shopping </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Shopping-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Shopping-Level1_6256451136.png" /></a> 

                			</div>
							 

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Take Turns </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=TakeTurns-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/TakeTurns-Level2_7725315545.png" /></a> 

                			</div> 

            				</div> 
            				</div> 

							<div class="gamesList">

                			<div class="gameBox LinguisticsGame">

                            	<h3 title="" class="ng-binding">Linguistics</h3>
								
								<div class="minHght"><h4 title="" class="ng-binding">Anagrams-FourLetterWord </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Anagrams-FourLetterWord&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Anagrams-FourLetterWords_96878870.png" /></a> 

                			</div>
							<hr class="CustomHR"/>
                				<div class="minHght"><h4 title="" class="ng-binding">Anagrams-Geography</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Anagrams-Geography&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Anagrams-Geography_5710392687.png" /></a> 

                				</div>

								<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Anagrams-Military</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Anagrams-Military&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Anagrams-Military_2205101763.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Anagrams-People</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Anagrams-People&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Anagrams-People_1156277623.png" /></a> 

                			</div> 

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Divided Words </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=DividedWords-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/DividedWords-Level1_9592156563.png" /></a> 

                			</div>
							
							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">HomoPhones </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=HomoPhones-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/HomoPhones-Level2_3726777150.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Rebus </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Rebus-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Rebus-Level1_8831456145.png" /></a> 

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Root Words </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=RootWords-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/RootWords-Level2_162112307.png" /></a> 

                			</div> 

            				</div> 

            			</div>  

						</div> 

						

						

						<div class="contentbox Cognitive" style="display:none;" id="VIII">

        					 <div class="gamesList">

                			<div class="gameBox MemoryGame">

                				<h3 title="" class="ng-binding">Memory</h3>

								<div class="minHght"><h4 title="" class="ng-binding">AlphaNumeric Encode </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=AlphaNumericEncode-Level6&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/AlphaNumericEncode-Level6_7225111038.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/>

							<div class="minHght"><h4 title="" class="ng-binding">Cycle Race</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=CycleRace-Level6&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/CycleRace-Level6_5745665873.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Spot My Place </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=SpotMyPlace-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/SpotMyPlace-Level2_128739713.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/>

								 <div class="minHght"><h4 title="" class="ng-binding">Ball And Box </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BallAndBox-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/BallAndBox-Level2_5648189471.png" /></a> 

                    			</div>

								

								<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Bug Spot </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BugSpot-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/BugSpot-Level2_807683826.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Drop Box </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=DropBox-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/DropBox-Level2_6796904369.png" /></a> 

                    			

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Misplaced Buddy </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MisplacedBuddy-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MisplacedBuddy-Level1_4661093535.png" /></a> 

                    			

                			</div>

							 <hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Coordinate Graph </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=CoordinateGraph-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/CoordinateGraph-Level2_2700936608.png" /></a> 

                     			

                			</div> 

           				  	</div>

            				</div> 

							 <div class="gamesList">

                			<div class="gameBox VisualProcessingGame">

                            	<h3 title="" class="ng-binding">VisualProcessing</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">Just Not Half </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=JustNotHalf-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/JustNotHalf-Level4_2555441330.png" /></a> 

                    			

                			</div>
							
							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Flip Trick </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=FlipTrick-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/FlipTrick-Level2_2970519540.png" /></a>  

                			</div>
							
							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Water Image </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WaterImage-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WaterImage-Level2_3779711904.png" /></a>  

                			</div>
							
							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Color Me</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ColorMe&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WhoIsNotThere-Level2_67013050.png" /></a>  

                			</div>


							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Mirror Image </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MirrorImage-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MirrorImage-Level2_8513625911.png" /></a>  

                			</div>

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Who Is Not There </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WhoIsNotThere-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/WhoIsNotThere-Level1_3340305127.png" /></a>  

                			</div> 
							

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Choose Three To Make One </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ChooseThreeToMakeOne-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ChooseThreeToMakeOne_6421778858.png" /></a>  

                			</div>

							
							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Master Shape </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MasterShape-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/BallAndBox-Level2_5648189471.png" /></a>  

                			</div>

							 

            				</div>

            		</div> 

					

					

					<div class="gamesList">

                			<div class="gameBox FocusGame">

                            	<h3 title="" class="ng-binding">FocusAndAttention</h3>

									<div class="minHght"><h4 title="" class="ng-binding">Spot Me </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=SpotMe-Level7&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/SpotMe-Level7_2691923594.png" /></a> 

                			</div> 
							
								<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Balloon Light </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BalloonLight-Level6&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/DarkLight-Level6_8921038703.png" /></a> 

                			</div> 
							<hr class="CustomHR"/>	

									<div class="minHght"><h4 title="" class="ng-binding">Number Me </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=NumberMe-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/NumberMe-Level1_9366972525.png" /></a> 

                			</div>
							
							
							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Discrete Paddle </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=DiscretePaddle-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/DiscretePadle-Level3_3544559371.png" /></a> 

                			</div>


							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Color In Color </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ColorInColor-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ColorInColor-Level1_1204938488.png" /></a> 

                			</div> 
							

							<hr class="CustomHR"/>	 

                				<div class="minHght"><h4 title="" class="ng-binding">Number Me </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=NumberMe-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/NumberMe-Level2_1924527920.png" /></a> 

                			</div> 
							
							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Odd Ball </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=OddBall-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/OddBall-Level2_3363969377.png" /></a> 

                			</div>  
            				</div>  

            				</div>

							

							<div class="gamesList">

                			<div class="gameBox ProblemSolvingGame">

                            	<h3 title="" class="ng-binding">ProblemSolving</h3>
								
								<div class="minHght"><h4 title="" class="ng-binding">Analogy Action </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=AnalogyAction-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/AnalogyAction-Level3_1947425035.png" /></a> 

                			</div><hr class="CustomHR"/>

								<div class="minHght"><h4 title="" class="ng-binding">Equate	</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Equate-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Equate-Level1_3846404044.png" /></a> 

                			</div>
							
							
							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Logical Sequence</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=LogicalSequence&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/LogicalSequence_3583530234.png" /></a> 

                			</div>
							
							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Master Venn </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MasterVenn-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MasterVenn-Level2_6223853942.png" /></a> 

                			</div>
							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Number Puzzle </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=NumberPuzzle-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/NumberPuzzle-Level3_4147070031.png" /></a> 

                			</div>
							

							<hr class="CustomHR"/>
							

							<div class="minHght"><h4 title="" class="ng-binding">Numbers On The Vertices </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=NumbersOnTheVertices-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/NumbersOnTheVertices-Level1_6839827257.png" /></a> 

                			</div> 
							

							

							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Smart Rider</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=SmartRider&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/SmartRider_1083469698.png" /></a> 

                			</div> 

            				</div>

            				</div>

							

							<div class="gamesList">

                			<div class="gameBox LinguisticsGame">

                            	<h3 title="" class="ng-binding">Linguistics</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">Guess The Word </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=GuessTheWord-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/GuessTheWord-Level1_8028972977.png" /></a> 

                				</div>
								
								<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Jumbled Letters</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=JumbledLetters-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/JumbledLetters-Level1_7572877304.png" /></a> 

                			</div>
							
							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Prefix Root And Suffix</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=PrefixRootAndSuffix&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/PrefixRootAndSuffix_204385071.png" /></a> 

                			</div>
							
							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Confusion Galore </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ConfusionGalore-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ConfusionGalore-Level2_9538272568.png" /></a> 

                			</div> 
							
							<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Kangaroo Words</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=KangarooWords&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/KangarooWords_1111639351.png" /></a> 

                			</div> 
 

            				</div> 

            			</div> 

						

						</div> 
						

					</div>
					
					
					
					<div class="col-lg-12">

				 

						

						<div class="contentbox Cognitive" style="display:none;" id="IA">

<div><h3 title="" class="ng-binding">Grade I</h3></div>
        					<div class="gamesList">
							
							
							
                			<div class="gameBox MemoryGame">

                				<h3 title="" class="ng-binding">Memory</h3>

								<div class="minHght"><h4 title="" class="ng-binding">Memory Check</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MemoryCheck-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MemoryCheck-Level2_8882285202.png" /></a> 

                    			

                			</div>
						 

           				  	</div>

            				</div><div class="gamesList">

                			<div class="gameBox VisualProcessingGame">

                            	<h3 title="" class="ng-binding">VisualProcessing</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">Best Fit</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BestFit-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/BestFit-Level2.png" /></a> 

                			</div>

            				</div>

            		</div><div class="gamesList">

                			<div class="gameBox FocusGame">

                            	<h3 title="" class="ng-binding">FocusAndAttention</h3>	

<div class="minHght"><h4 title="" class="ng-binding">Last Legend</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=LastLegend-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/LastLegend-Level3_5495434515.png" /></a> 

                			</div>

							 

            				</div>  

            				</div><div class="gamesList">

                			<div class="gameBox ProblemSolvingGame">

                            	<h3 title="" class="ng-binding">ProblemSolving</h3>

								<div class="minHght"><h4 title="" class="ng-binding">Heavy Or Light</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=HeavyOrLight-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/HeavyOrLight-Level2_607259180.png" /></a> 

                			</div>

							

            				</div>

            				</div><div class="gamesList">

                			<div class="gameBox LinguisticsGame">

                            	<h3 title="" class="ng-binding">Linguistics</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">Who Am I-Fruits </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WhoAmI-Fruits&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ArrangeTheWords-Level2_2614120254.png" /></a> 

                				</div>

            				</div> 

            			</div> 
													<h3 title="" class="ng-binding">Grade II</h3>


        					<div class="gamesList">
                 			<div class="gameBox MemoryGame">

                				<h3 title="" class="ng-binding">Memory</h3>
                				

								<div class="minHght"><h4 title="" class="ng-binding">Balloon Burst</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BalloonBurst-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/BalloonBurst-Level3_2492009233.png" /></a> 

                    			

                			</div>
							 
 

           				  	</div>

            				</div><div class="gamesList">

                			<div class="gameBox VisualProcessingGame">

                            	<h3 title="" class="ng-binding">VisualProcessing</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">Match Me</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MatchMe-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/EdCells-Level3_4655870916.png" /></a> 

                    			

                			</div>

							<!--<hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Best Fit Optimized</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="swfn/BestFit-Level4a.html" class="fancybox fancybox.iframe"> <img  src="images/icon/BestFit-Level3_8792649721.png" /></a>  

                			</div>

							-->
 

            				</div>

            		</div><div class="gamesList">

                			<div class="gameBox FocusGame">

                            	<h3 title="" class="ng-binding">FocusAndAttention</h3>	

<div class="minHght"><h4 title="" class="ng-binding">Last Legend</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=LastLegend-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/LastLegend-Level3_5495434515.png" /></a> 

                			</div>
							

            				</div>  

            				</div><div class="gamesList">

                			<div class="gameBox ProblemSolvingGame">

                            	<h3 title="" class="ng-binding">ProblemSolving</h3>

								<div class="minHght"><h4 title="" class="ng-binding">Reshuffle</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Reshuffle-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Reshuffle-Level3_2661516019.png" /></a> 

                			</div>
 

							

            				</div>

            				</div><div class="gamesList">

                			<div class="gameBox LinguisticsGame">

                            	<h3 title="" class="ng-binding">Linguistics</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">Who Am I-Transport </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=WhoAmI-Transport&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Anagrams-Food_9358940329.png" /></a> 

                				</div> 

            				</div> 

            			</div> 
						
						
						<h3 title="" class="ng-binding">Grade III</h3>

        					<div class="gamesList">
							

                			<div class="gameBox MemoryGame">

                				<h3 title="" class="ng-binding">Memory</h3>
                				

								<div class="minHght"><h4 title="" class="ng-binding">Sequence Memory</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=SequenceMemory-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/SequenceMemory-Level3_9452287289.png" /></a> 

                    			

                			</div>

           				  	</div>

            				</div><div class="gamesList">

                			<div class="gameBox VisualProcessingGame">

                            	<h3 title="" class="ng-binding">VisualProcessing</h3>

                				

							 <div class="minHght"><h4 title="" class="ng-binding">Match Me</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MatchMe-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/JustNotHalf-Level1_6506787771.png" /></a>  

                			</div>

							 

            				</div>

            		</div><div class="gamesList">

                			<div class="gameBox FocusGame">

                            	<h3 title="" class="ng-binding">FocusAndAttention</h3>	

<div class="minHght"><h4 title="" class="ng-binding">Balloon Light </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=BalloonLight-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/DarkLight-Level1_1779258348.png" /></a> 

                			</div>
							 

            				</div>  

            				</div><div class="gamesList">

                			<div class="gameBox ProblemSolvingGame">

                            	<h3 title="" class="ng-binding">ProblemSolving</h3>

								<div class="minHght"><h4 title="" class="ng-binding">Reshuffle</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Reshuffle-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/AddMaster-Level3_2056090440.png" /></a> 

                			</div>

							

            				</div>

            				</div><div class="gamesList">

                			<div class="gameBox LinguisticsGame">

                            	<h3 title="" class="ng-binding">Linguistics</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">Anagrams-Animals</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Anagrams-Animals&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Anagrams-CountryNames_9848174657.png" /></a> 

                				</div>

							 

            				</div> 

            			</div> 


<h3 title="" class="ng-binding">Grade IV</h3>
        					<div class="gamesList">
							
                			<div class="gameBox MemoryGame">

                				<h3 title="" class="ng-binding">Memory</h3>
                				

								<div class="minHght"><h4 title="" class="ng-binding">AlphaNumeric Encode </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=AlphaNumericEncode-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/BackTrack-Level1_257858377.png" /></a> 

                    			

                			</div>
							 
           				  	</div>

            				</div><div class="gamesList">

                			<div class="gameBox VisualProcessingGame">

                            	<h3 title="" class="ng-binding">VisualProcessing</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">Reflection Read</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ReflectionRead-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ReflectionRead-Level1_7608671374.png" /></a> 

                    			

                			</div>

            				</div>

            		</div><div class="gamesList">

                			<div class="gameBox FocusGame">

                            	<h3 title="" class="ng-binding">FocusAndAttention</h3>	

<div class="minHght"><h4 title="" class="ng-binding">Letter Jigsaw</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=LetterJigsaw-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/AlphabetJigsaw-Level3_1882078954.png" /></a> 

                			</div> 

            				</div>  

            				</div><div class="gamesList">

                			<div class="gameBox ProblemSolvingGame">

                            	<h3 title="" class="ng-binding">ProblemSolving</h3>

								<div class="minHght"><h4 title="" class="ng-binding">A Teddy For A Teddy</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ATeddyForATeddy-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ATeddyForATeddy-Level3_1824636519.png" /></a> 

                			</div>

							

            				</div>

            				</div><div class="gamesList">

                			<div class="gameBox LinguisticsGame">

                            	<h3 title="" class="ng-binding">Linguistics</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">Anagrams-Body</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Anagrams-Body&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Anagrams-Colors_4401654419.png" /></a> 

                				</div>

							<!-- <hr class="CustomHR"/><div class="minHght"><h4 title="" class="ng-binding">Missing Letter</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="swfn/MissingLetter-Level2.html" class="fancybox fancybox.iframe"> <img  src="images/icon/MissingLetter-Level2_3469503405.png" /></a> 

                			</div>--> 

            				</div> 

            			</div> 


<h3 title="" class="ng-binding">Grade V</h3>
        					<div class="gamesList">
							

                			<div class="gameBox MemoryGame">

                				<h3 title="" class="ng-binding">Memory</h3>
                				

								 <div class="minHght"><h4 title="" class="ng-binding">AlphaNumeric Encode</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=AlphaNumericEncode-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/AlphaNumericEncode-Level3_387589167.png" /></a> 

                    			

                			</div>

           				  	</div>

            				</div><div class="gamesList">

                			<div class="gameBox VisualProcessingGame">

                            	<h3 title="" class="ng-binding">VisualProcessing</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">Missing Piece </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MissingPiece-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MissingPiece-Level1_5453919009.png" /></a> 

                    			

                			</div>

							 

            				</div>

            		</div><div class="gamesList">

                			<div class="gameBox FocusGame">

                            	<h3 title="" class="ng-binding">FocusAndAttention</h3>	

<div class="minHght"><h4 title="" class="ng-binding">Car Park</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=CarPark-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/CarPark-Level2_116904969.png" /></a> 

                			</div>

							

            				</div>  

            				</div><div class="gamesList">

                			<div class="gameBox ProblemSolvingGame">

                            	<h3 title="" class="ng-binding">ProblemSolving</h3>
 

							<div class="minHght"><h4 title="" class="ng-binding">Hue Cram</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=HueCram&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/NumberSeries-Level1_292791444.png" /></a> 

                			</div>

							

            				</div>

            				</div><div class="gamesList">

                			<div class="gameBox LinguisticsGame">

                            	<h3 title="" class="ng-binding">Linguistics</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">Anagrams-Vehicles </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Anagrams-Vehicles&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MissingLetter-Level4_7994128023.png" /></a> 

                				</div>
							 

            				</div> 

            			</div>
						
						
						<h3 title="" class="ng-binding">Grade VI</h3>

        					<div class="gamesList">
							
                			<div class="gameBox MemoryGame">

                				<h3 title="" class="ng-binding">Memory</h3>
                				

								<div class="minHght"><h4 title="" class="ng-binding">Memory Check</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MemoryCheck-Level6&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MemoryCheck-Level3_7822075057.png" /></a> 

                    			

                			</div>

           				  	</div>

            				</div>

							<div class="gamesList">

                			<div class="gameBox VisualProcessingGame">

                            	<h3 title="" class="ng-binding">VisualProcessing</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">Missing Piece</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=MissingPiece-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/MissingPiece-Level1_5453919009.png" /></a> 

                    			

                			</div>
 

            				</div>

            		</div>

					

					

					<div class="gamesList">

                			<div class="gameBox FocusGame">

                            	<h3 title="" class="ng-binding">FocusAndAttention</h3>	

<div class="minHght"><h4 title="" class="ng-binding">Car Park</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=CarPark-Level4&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/CarPark-Level2_116904969.png" /></a> 

                			</div>
 

            				</div>  

            				</div>

							

							<div class="gamesList">

                			<div class="gameBox ProblemSolvingGame">

                            	<h3 title="" class="ng-binding">ProblemSolving</h3>

								<div class="minHght"><h4 title="" class="ng-binding">Sequence Grid</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=SequenceGrid&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ColorGuess_7757099242.png" /></a> 

                			</div>
							 

            				</div>

            				</div>

							

							<div class="gamesList">

                			<div class="gameBox LinguisticsGame">

                            	<h3 title="" class="ng-binding">Linguistics</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">Anagrams-DolchWords</h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Anagrams-DolchWords&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Anagrams-Jobs_2256901105.png" /></a> 

                				</div> 
 
							 

            				</div> 

            			</div> 


						
 <h3 title="" class="ng-binding">Grade VII</h3>

        					<div class="gamesList">
							
                			<div class="gameBox MemoryGame">

                				<h3 title="" class="ng-binding">Memory</h3>
                				

								<div class="minHght"><h4 title="" class="ng-binding">Sequence Memory</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=SequenceMemory-Level7&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/SequenceMemory-Level3_9452287289.png" /></a> 

                    			

                			</div>

           				  	</div>

            				</div>

							<div class="gamesList">

                			<div class="gameBox VisualProcessingGame">

                            	<h3 title="" class="ng-binding">VisualProcessing</h3>

                				 <div class="minHght"><h4 title="" class="ng-binding">Find The Twins</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=FindTheTwins-Level3&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/FindTheTwins-Level1_7979904958.png" /></a>  

                			</div>
            				</div>

            		</div>

					

					

					<div class="gamesList">

                			<div class="gameBox FocusGame">

                            	<h3 title="" class="ng-binding">FocusAndAttention</h3>	

<div class="minHght"><h4 title="" class="ng-binding">Discrete Paddle</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=DiscretePaddle-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/DiscretePadle-Level1_2005080394.png" /></a> 

                			</div> 

            				</div>  

            				</div>

							

							<div class="gamesList">

                			<div class="gameBox ProblemSolvingGame">

                            	<h3 title="" class="ng-binding">ProblemSolving</h3>
								
								
								<div class="minHght"><h4 title="" class="ng-binding">Nitty Gritty</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=NittyGritty&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/AnalogyAction-Level2_5585269308.png" /></a> 

                			</div> 
			
            				</div> 
            				</div> 

							<div class="gamesList">

                			<div class="gameBox LinguisticsGame">

                            	<h3 title="" class="ng-binding">Linguistics</h3>
								
								<div class="minHght"><h4 title="" class="ng-binding">Confusion Galore </h4>

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ConfusionGalore-Level1&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ConfusionGalore-Level2_9538272568.png" /></a> 

                			</div>
							

            				</div> 

            			</div>  
 
 
 <h3 title="" class="ng-binding">Grade VIII</h3>

        					 <div class="gamesList">
							 

                			<div class="gameBox MemoryGame">

                				<h3 title="" class="ng-binding">Memory</h3>
                				

								<div class="minHght"><h4 title="" class="ng-binding">Sequence Memory</h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=SequenceMemory-Level8&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/SequenceMemory-Level3_9452287289.png" /></a> 

                    			

                			</div> 

           				  	</div>

            				</div> 

							 <div class="gamesList">

                			<div class="gameBox VisualProcessingGame">

                            	<h3 title="" class="ng-binding">VisualProcessing</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">Choose Two To Make One </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ChooseTwoToMakeOne&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/JustNotHalf-Level4_2555441330.png" /></a> 

                    			

                			</div> 

            				</div>

            		</div> 

					

					

					<div class="gamesList">

                			<div class="gameBox FocusGame">

                            	<h3 title="" class="ng-binding">FocusAndAttention</h3>

									<div class="minHght"><h4 title="" class="ng-binding">Shape Vs Color Vs Pattern </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=ShapeVsColorVsPattern-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/ShapeVsColorVsPattern-Level1_9182052793.png" /></a> 

                			</div> 
							
								 
            				</div>  

            				</div>

							

							<div class="gamesList">

                			<div class="gameBox ProblemSolvingGame">

                            	<h3 title="" class="ng-binding">ProblemSolving</h3>
								
								<div class="minHght"><h4 title="" class="ng-binding">Shopping  </h4>

								<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=Shopping-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/Shopping-Level1_6256451136.png" /></a> 

                			</div>

            				</div>

            				</div>

							

							<div class="gamesList">

                			<div class="gameBox LinguisticsGame">

                            	<h3 title="" class="ng-binding">Linguistics</h3>

                				<div class="minHght"><h4 title="" class="ng-binding">Jumbled Letters

                				<a data-fancybox  data-type="iframe" href="javascript:;" data-src="https://puzzle.skillangels.com/CLP2021/assets/SaClp2021_allVar/games.php?gamename=JumbledLetters-Level2&gamelang=<?php echo $_SESSION['demoskill']['glang']; ?>" class="fancybox fancybox.iframe"> <img  src="images/icon/JumbledLetters-Level1_7572877304.png" /></a> 

                				</div>  

            				</div> 

            			</div> 

						

						</div> 
						

					</div>

					

</div>

</div>

</div>

 <!-- Footer starts here-->

	 <!--

	 <div class="footer pagefooter">

    	<div class="row">

        	<div class="col-lg-6">

    			Copyright © 2015 Skill Angels. All rights reserved.

            </div>

            

        </div>

    </div>

	-->

	<!-- footer ends here --> 

    <!-- /#wrapper -->

	<!-- jQuery -->

	 <style>

 .minHght1 { min-height: 218px;}

  </style>

      <script src="js/bootstrap.min.js"></script>

	 <script src="js/jquery-ui.js"></script>

	   <?php include_once('site_access.php'); ?> 

</body></html>