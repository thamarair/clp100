var introQuestxt, introArrow, introQuestion1, introQuestion2Text, introQuestion2, introTitle, introfingure, introHolder, introtextArr1, introQuestion;
var introChoice1 = [];
var introChoice1TweenArr = [];
var highlightTweenArr = [];
var setIntroCnt = 0;
var removeIntraval = 0;
var introHolder1X = [230, 550, 850]
var introArrowX = 370, introArrowY = 330;
var introfingureX = 381, introfingureY = 425;
var introQuesTextX = 0, introQuesTextY = 10;
var introbtnX = [40 + 35, 300 + 35, 540 + 35, 780 + 35, 1020 + 35];
var introbtnY = [600, 520, 570, 520, 610]
var introHolderX = 530, introHolderY = 590
function commongameintro() {
    introTitle = Title.clone();
    introTitle.visible = true;
    container.parent.addChild(introTitle)

    introQuestxt = questionText.clone()
    introArrow = arrow1.clone()
    introfingure = fingure.clone()
    introHolder = introAnsHolder.clone()
    introQuestion = introquesHolder.clone()
    introQuestion1 = introquesHolder1.clone()
    introQuestion2 = introquesHolder2.clone()
    container.parent.addChild(introQuestxt)
    introQuestxt.visible = true;
    introQuestxt.x = introQuesTextX;
    introQuestxt.y = introQuesTextY;

    container.parent.addChild(introHolder)
    introHolder.visible = false;
    introHolder.scaleX = introHolder.scaleY = 1;
    container.parent.addChild(introQuestion)
    introQuestion.visible = false;
    introQuestion.y = -200
    container.parent.addChild(introQuestion1)
    introQuestion1.visible = false;
    introQuestion1.y = 30
    container.parent.addChild(introQuestion2)
    introQuestion2.visible = false;
    introQuestion2.y = 30
    introtextArr1 = new createjs.Text("", "50px lato-Bold", "brown")
    container.parent.addChild(introtextArr1);
    introtextArr1.textAlign = "center";
    introtextArr1.textBaseline = "middle";
    introtextArr1.x = 635
    introtextArr1.y = 642
    introtextArr1.visible = false;

    introQuestion2Text = new createjs.Text("6", "75px lato-Bold", "blue")
    container.parent.addChild(introQuestion2Text);
    introQuestion2Text.textAlign = "center";
    introQuestion2Text.textBaseline = "middle";
    introQuestion2Text.x = 828
    introQuestion2Text.y = 657
    introQuestion2Text.visible = false;

    introQuestxt.alpha = 0;
    createjs.Tween.get(introQuestxt).wait(100)
        .to({ alpha: .5 }, 100)
        .to({ alpha: 1 }, 100).call(handleComplete2_1);

}
function handleComplete2_1() {
    createjs.Tween.removeAllTweens();
    HolderTween();
}
function HolderTween() {

    createjs.Tween.get(introQuestion)
        .to({ visible: true, alpha: 0 }, 250)
        .to({ visible: true, alpha: 1, y: 30, scaleX: 1, scaleY: 1 }, 750).call(handleComplete3_1);
}
function handleComplete3_1() {
    createjs.Tween.removeAllTweens();
    Ansholder();
}
function Ansholder() {
    introHolder.visible = true;
    introHolder.alpha = 0;
    createjs.Tween.get(introHolder)
        .to({ alpha: 1 }, 500)
    introtextArr1.x = 639
    introtextArr1.y = 650
    introtextArr1.color = "red"
    introtextArr1.text = "?"
    introtextArr1.visible = false
    createjs.Tween.get(introtextArr1).wait(500)
        .to({ visible: true,  font: "bold 60px Lato-Bold",alpha: 1, scaleX: 1, scaleY: 1 }, 500)
        .to({ visible: true, alpha: 1, scaleX: .85, scaleY: .85 }, 500)
        .to({ visible: true, alpha: 1, scaleX: 1, scaleY: 1 }, 500)
        .to({ visible: true, alpha: 1, scaleX: .85, scaleY: .85 }, 500).wait(500)
        .call(handleComplete3_2);

}

function handleComplete3_2() {
    createjs.Tween.removeAllTweens();
   introtextArr1.font= "bold 60px Lato-Bold"
    CalculateTween();
}
function CalculateTween() {
    introQuestion1.visible = true
    introQuestion1.alpha = 0
    createjs.Tween.get(introQuestion1)
        .to({ visible: true, alpha: 0.5 }, 250)
        .to({ visible: true, alpha: 1, y: 30, scaleX: 1, scaleY: 1 }, 750)
        .call(handleComplete3_3);

}

function handleComplete3_3() {
    createjs.Tween.removeAllTweens();
    CalAnsTween();
}
function CalAnsTween() {
    introQuestion2Text.visible = true;
    introQuestion2Text.alpha = 1
    createjs.Tween.get(introQuestion2Text)
        .to({ visible: true, alpha: 0.5, font: "bold 55px Lato-Bold",  x: 480, y: 440, scaleX: .65, scaleY: .65 }, 500)
        .to({ visible: false, alpha: 0 }, 500)

    introQuestion2.alpha = 0
    introQuestion2.scaleX = introQuestion2.scaleY = 1
    createjs.Tween.get(introQuestion2).wait(900)
        .to({ visible: true, alpha: 1, x: 6, y: 31 }, 750).wait(500)
        .call(handleComplete3_4);
}
function handleComplete3_4() {

    createjs.Tween.removeAllTweens();
    setArrowTween()
}
function setArrowTween() {
    if (stopValue == 0) {
        console.log("setArrowTween  == stopValue")
        removeGameIntro()
    }
    else {
        container.parent.addChild(introArrow);
        introArrow.visible = true;
        introArrow.x = introArrowX;
        introArrow.y = introArrowY;
        highlightTweenArr[0] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[0])
        highlightTweenArr[0] = createjs.Tween.get(introArrow)
            .to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350)
            .to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350)
            .to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350)
            .wait(400)
            .call(this.onComplete1)
    }
}

function setFingureTween() {
    if (stopValue == 0) {
        console.log("setFingureTween  == stopValue")
        removeGameIntro()
    }
    else {
        container.parent.removeChild(introArrow);
        introArrow.visible = false;
        container.parent.addChild(introfingure);
        introfingure.visible = true;
        introfingure.x = introfingureX;
        introfingure.y = introfingureY;
        highlightTweenArr[1] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[1])
        highlightTweenArr[1] = createjs.Tween.get(introfingure)
            .to({ x: introfingureX }, 350)
            .to({ x: introfingureX - 15 }, 350)
            .to({ x: introfingureX }, 350)
            .to({ x: introfingureX - 15 }, 350).wait(200).call(this.onComplete2)

    }
}

this.onComplete1 = function (e) {
    createjs.Tween.removeAllTweens();

    if (highlightTweenArr[0]) {
        console.log("onComplete1")
        container.parent.removeChild(highlightTweenArr[0]);
    }

    container.parent.removeChild(introArrow);
    if (stopValue == 0) {
        console.log("onComplete1  == stopValue")
        removeGameIntro()

    } else {
        setTimeout(setFingureTween, 200)
    }
}


this.onComplete2 = function (e) {
    createjs.Tween.removeAllTweens();

    if (highlightTweenArr[1]) {
        console.log("onComplete2")
        container.parent.removeChild(highlightTweenArr[1]);
    }

    container.parent.removeChild(introfingure);
    introfingure.visible = false;

    if (stopValue == 0) {
        console.log("onComplete2  == stopValue")
        removeGameIntro()

    }
    else {
        // introtextArr1.text = "3"
        // introChoice1[1].scaleX = introChoice1[1].scaleY = 1
        // setTimeout(setCallDelay, 500)

        introtextArr1.visible = true;
        introtextArr1.alpha = 0;
        // introtextArr1.x = 395
        // introtextArr1.y = 445

        introtextArr1.text = "93"
        introtextArr1.color = "brown"

         introtextArr1.font = "40px lato-Bold"
        introtextArr1.color = "brown"
        introtextArr1.x = 393
        introtextArr1.y = 441
      
        createjs.Tween.get(introtextArr1)
            .to({ visible: true, alpha: 1 }, 500)
            .to({ x: 640, y: 651, visible: true, font: "bold 75px Lato-Bold", color: "red", alpha: 1 }, 500).wait(1000)
            .call(setCallDelay)
    }


}

function setCallDelay() {
    clearInterval(removeIntraval)
    removeIntraval = 0
    setIntroCnt++
    console.log("check cnt = " + setIntroCnt)
    removeGameIntro()
    if (stopValue == 0) {
        console.log("setCallDelay  == stopValue")
        removeGameIntro()
    }
    else {
        commongameintro()
        if (setIntroCnt > 0) {
            isVisibleStartBtn()
        }
    }

}
function removeGameIntro() {
    createjs.Tween.removeAllTweens();
    // introTitle.visible = false;
    // container.parent.removeChild(introTitle)

    container.parent.removeChild(introArrow)
    introArrow.visible = false
    container.parent.removeChild(introfingure)
    introfingure.visible = false
    container.parent.removeChild(introQuestxt)
    introQuestxt.visible = false
    container.parent.removeChild(introHolder)
    introHolder.visible = false;

    container.parent.removeChild(introQuestion)
    introQuestion.visible = false;
    container.parent.removeChild(introQuestion1)
    introQuestion1.visible = false;
    container.parent.removeChild(introQuestion2)
    introQuestion2.visible = false;
    container.parent.removeChild(introQuestion2Text)
    introQuestion2Text.visible = false;

    introtextArr1.visible = false;
    container.parent.removeChild(introtextArr1)

    if (highlightTweenArr[0]) {
        highlightTweenArr[0].setPaused(false);
        container.parent.removeChild(highlightTweenArr[0]);
    }
    if (highlightTweenArr[1]) {
        highlightTweenArr[1].setPaused(false);
        container.parent.removeChild(highlightTweenArr[1]);
    }

}