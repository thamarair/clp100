
///////////////////////////////////////////////////-------Common variables--------------/////////////////////////////////////////////////////////////////////
var messageField;		//Message display field
var assets = [];
var cnt = -1, qscnt = -1, ans, uans, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, choiceCnt = 5, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;
var startBtn, introScrn, container, choice1, choice2, choice3, choice4, question, circleOutline, circle1Outline, boardMc, helpMc, quesMarkMc, questionText, quesHolderMc, resultLoading, preloadMc;
var mc, mc1, mc2, mc3, mc4, mc5, startMc, questionInterval = 0;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc, gameIntroAnimMc;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;
var bg
var BetterLuck, Excellent, Nice, Good, Super, TryAgain;
var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle, timeOver_Status = 0;
var isBgSound = true;
var isEffSound = true;

var url = "";
var nav = "";
var isResp = true;
var respDim = 'both'
var isScale = true
var scaleType = 1;
var text1, text2, text3, text4, text5;
var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var loadProgressLabel, progresPrecentage, loaderWidth;
/////////////////////////////////////////////////////////////////////////GAME SPECIFIC VARIABLES//////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////GAME SPECIFIC ARRAY//////////////////////////////////////////////////////////////
var qno = [];
var yArr = [];
var textArr = []
var dummyArr = []
var btnx = [36, 282, 525, 770, 1020]
var btny = [235, 154, 200, 154, 235]
// var btnx = [40, 300, 540, 780, 1020]
// var btny = [230, 150, 200, 150, 230]
var texty = [519, 437, 485, 437, 518]
var textx = [35, 285, 528, 770, 1018]
var balloonArray = []
var symbolArr = ["-", "+", "x", "/"]
//register key functions
///////////////////////////////////////////////////////////////////
window.onload = function (e) {
    checkBrowserSupport();
}
///////////////////////////////////////////////////////////////////s
function init() {

    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);

    callLoader();
    createLoader()
    createCanvasResize()

    stage.update();
    stage.enableMouseOver(40);
    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////

    /*Always specify the following terms as given in manifest array. 
         1. choice image name as "ChoiceImages1.png"
         2. question text image name as "questiontext.png"
     */

    assetsPath = "assets/";
    gameAssetsPath = "ParaMaster-Level2/";
    soundpath = "FA/"

    var success = createManifest();
    if (success == 1) {
        manifest.push(
            { id: "dummy", src: gameAssetsPath + "dummyHolder.png" },
            { id: "chHolder", src: gameAssetsPath + "chHolder.png" },
            { id: "qhHolder", src: gameAssetsPath + "qhHolder.png" },
            { id: "introAnsHolder", src: gameAssetsPath + "chHolder2.png" },
            { id: "introquesHolder1", src: gameAssetsPath + "chHolder4.png" },
            { id: "introquesHolder", src: gameAssetsPath + "chHolder3.png" },
            { id: "introquesHolder2", src: gameAssetsPath + "chHolder5.png" },
            { id: "questionText", src: questionTextPath + "ParaMaster-Level2-QT.png" }
        )
        preloadAllAssets()
        stage.update();
    }

}


function doneLoading1(event) {

    var event = assets[i];
    var id = event.item.id;

    if (id == "dummy") {
        dummy = new createjs.Bitmap(preload.getResult('dummy'));
        container.parent.addChild(dummy);
        dummy.visible = false;

    }
    if (id == "chHolder") {
        chHolder = new createjs.Bitmap(preload.getResult('chHolder'));
        container.parent.addChild(chHolder);
        chHolder.visible = false;

    }
    if (id == "qhHolder") {
        qhHolder = new createjs.Bitmap(preload.getResult('qhHolder'));
        container.parent.addChild(qhHolder);
        qhHolder.visible = false;

    }
    if (id == "introAnsHolder") {
        introAnsHolder = new createjs.Bitmap(preload.getResult('introAnsHolder'));
        container.parent.addChild(introAnsHolder);
        introAnsHolder.visible = false;
    }
    if (id == "introquesHolder") {
        introquesHolder = new createjs.Bitmap(preload.getResult('introquesHolder'));
        container.parent.addChild(introquesHolder);
        introquesHolder.visible = false;
    }
    if (id == "introquesHolder1") {
        introquesHolder1 = new createjs.Bitmap(preload.getResult('introquesHolder1'));
        container.parent.addChild(introquesHolder1);
        introquesHolder1.visible = false;
    }

    if (id == "introquesHolder2") {
        introquesHolder2 = new createjs.Bitmap(preload.getResult('introquesHolder2'));
        container.parent.addChild(introquesHolder2);
        introquesHolder2.visible = false;
    }
    if (id == "questionText") {
        questionText = new createjs.Bitmap(preload.getResult('questionText'));
        container.parent.addChild(questionText);
        questionText.visible = false;

    }



}

function tick(e) {

    stage.update();
}
/////////////////////////////////////////////////////////////////=======GAME START========///////////////////////////////////////////////////////////////////
function handleClick(e) {
    qno = between(1, 100)
    CreateGameStart()
    if (gameType == 0) {
        CreateGameElements()
        getStartQuestion();
    } else {

        getdomainpath()

    }
}


function CreateGameElements() {

    interval = setInterval(countTime, 1000);
    container.parent.addChild(questionText);
    questionText.visible = false;
    questionText.x = questionText.x + 15
    container.parent.addChild(chHolder);
    chHolder.visible = false
    container.parent.addChild(qhHolder);
    qhHolder.visible = false
    qhHolder.y = qhHolder.y + 30
    for (i = 0; i < 5; i++) {
        dummyArr[i] = dummy.clone()
        container.parent.addChild(dummyArr[i])
        dummyArr[i].visible = false
        dummyArr[i].x = btnx[i] //- 2
        dummyArr[i].y = btny[i] + 5
        dummyArr[i].alpha = .01
        dummyArr[i].scaleX = dummyArr[i].scaleY = 1.02
        dummyArr[i].name = symbolArr[i]
    }
    for (i = 0; i < 5; i++) {
        textArr[i] = new createjs.Text("s", "bold 40px lato-Bold", "brown");
        textArr[i].x = textx[i] + 112
        textArr[i].y = texty[i] //+ 23;
        textArr[i].textAlign = "center"
        textArr[i].textBaseline = "middle"
        textArr[i].visible = false;
        container.parent.addChild(textArr[i]);
    }
    text1 = new createjs.Text("", "bold 50px lato-Bold", "blue");
    container.parent.addChild(text1);
    text1.textAlign = "center"
    text1.textBaseline = "middle"
    text1.x = 432;
    text1.y = 648;
    text1.visible = false;

    text2 = new createjs.Text("", "bold 50px lato-Bold", "blue");
    container.parent.addChild(text2);

    text2.textAlign = "center"
    text2.textBaseline = "middle"
    text2.x = 536.5;
    text2.y = 648;
    text2.visible = false;

    text3 = new createjs.Text("", "bold 50px lato-Bold", "red");
    container.parent.addChild(text3);
    text3.textAlign = "center"
    text3.textBaseline = "middle"
    text3.x = 641;
    text3.y = 648;
    text3.visible = false;

    text4 = new createjs.Text("", "bold 50px lato-Bold", "blue");
    container.parent.addChild(text4);
    text4.textAlign = "center"
    text4.textBaseline = "middle"
    text4.x = 744;
    text4.y = 648;
    text4.visible = false;

    text5 = new createjs.Text("", "bold 50px lato-Bold", "blue");
    container.parent.addChild(text5);
    text5.textAlign = "center"
    text5.textBaseline = "middle"
    text5.x = 849;
    text5.y = 648;
    text5.visible = false;
    if (isQuestionAllVariations) {
        qcheck = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2]
        //  createGameWiseQuestions()
        // pickques()
    } else {
        qcheck = [1, 2, 1, 1, 1, 2, 1, 1, 1, 2]

        //  pickques()
    }

    qcheck.sort(randomSort)
    stage.update();
}

function helpDisable() {

}

function helpEnable() {

}
//=================================================================================================================================//
function pickques() {
    pauseTimer()
    tx = 0;
    cnt++;
    qscnt++;
    quesCnt++;
    chpos = [];
    panelVisibleFn()
    //=================================================================================================================================//
    do {
        var num1 = range(25, 100) + 25;
        var num2 = range(1, 100);
        var num3 = num1 - num2;
    } while (num3 <= 0)

    text1.text = num1;
    text2.text = "-";
    text3.text = "?";
    text4.text = "=";
    text5.text = num3;


    //////////////////////////////////////////////////////////////////
    balloonArray = between(1, 125);

    if (balloonArray.indexOf(num2) != -1)
        balloonArray.splice(balloonArray.indexOf(num2), 1)
    balloonArray.splice(5, balloonArray.length);
    balloonArray.push(num2);
    balloonArray.sort(randomSort);
    ans = num2
    console.log(ans)
    createTween();
    createjs.Ticker.addEventListener("tick", tick);
    stage.update();
}
function createTween() {
    //////////////////////////////QuestionText////////////////////////////    
    questionText.visible = true
    questionText.alpha = 0;
    questionText.y = -100
    createjs.Tween.get(questionText).wait(200)
        .to({ y: 10, alpha: .5, scaleX: 1, scaleY: 1 }, 100)
        .to({ y: 10, alpha: 1 }, 100)

    qhHolder.visible = true
    qhHolder.alpha = 0;
    qhHolder.x = 0
    qhHolder.y = -280
    createjs.Tween.get(qhHolder).wait(400)
        .to({ x: 0, y: 28, alpha: .5 }, 400)
        .to({ x: 0, y: 28, alpha: 1 }, 100)


    for (i = 0; i < 5; i++) {
        textArr[i].visible = true;
        textArr[i].text = balloonArray[i]
        textArr[i].alpha = 0;
        createjs.Tween.get(textArr[i]).wait(1000)
            .to({ rotation: 180, alpha: .5, scaleX: .5, scaleY: .5 }, 200)
            .to({ rotation: 360, alpha: 1, scaleX: .9, scaleY: .9 }, 200)
    }
    chHolder.visible = true
    chHolder.alpha = 0;
    chHolder.x = -250
    chHolder.y = 0
    createjs.Tween.get(chHolder).wait(1500)
        .to({ x: 0, y: 0, alpha: .5 }, 100)
        .to({ x: 0, y: 0, alpha: 1 }, 100)
    text1.visible = true;
    text1.alpha = 0
    text1.scaleX = text1.scaleY = .85
    createjs.Tween.get(text1).wait(1400)
        .to({ alpha: 1 }, 200)
    text3.visible = true;
    text3.alpha = 0
    text3.scaleX = text3.scaleY = .85
    createjs.Tween.get(text3).wait(1700)
        .to({ alpha: 1, scaleX: .9, scaleY: .9 }, 350)
        .to({ alpha: 1, scaleX: .85, scaleY: .85 }, 200)
        .to({ alpha: 1, scaleX: .9, scaleY: .9 }, 350)
    //////////////////////////////////////////////////////////////////  
    text2.visible = true;
    text2.alpha = 0
    text2.scaleX = text2.scaleY = .85
    createjs.Tween.get(text2).wait(1400)
        .to({ alpha: 1 }, 200)
    //////////////////////////////////////////////////////////////////    
    text4.visible = true;
    text4.alpha = 0
    text4.scaleX = text4.scaleY = .85
    createjs.Tween.get(text4).wait(1400)
        .to({ alpha: 1 }, 200)
    //////////////////////////////////////////////////////////////////    
    text5.visible = true;
    text5.alpha = 0
    text5.scaleX = text5.scaleY = .85
    createjs.Tween.get(text5).wait(1400)
        .to({ alpha: 1 }, 200)


    //////////////////////////////////////////////////////////////////    
    repTimeClearInterval = setTimeout(AddListenerFn, 2800)
}

function AddListenerFn() {
    clearTimeout(repTimeClearInterval)
    console.log("eventlisterneer")
    for (i = 0; i < 5; i++) {
        dummyArr[i].visible = true
        dummyArr[i].addEventListener("click", answerSelected);
        dummyArr[i].cursor = "pointer";
        dummyArr[i].mouseEnabled = true
        textArr[i].text = balloonArray[i]
        dummyArr[i].name = balloonArray[i]
    }
    rst = 0;
    gameResponseTimerStart();
    restartTimer()
}
function disablechoices() {
    createjs.Tween.removeAllTweens();
    for (i = 0; i < 5; i++) {
        dummyArr[i].visible = false
        dummyArr[i].removeEventListener("click", answerSelected);
        dummyArr[i].cursor = "default";
        dummyArr[i].mouseEnabled = false
    }
}

function disablechoices() {
    for (i = 0; i < 5; i++) {
        dummyArr[i].visible = false
        dummyArr[i].removeEventListener("click", answerSelected);
        dummyArr[i].cursor = "default";
        dummyArr[i].mouseEnabled = false
        textArr[i].visible = false;
    }
    text1.visible = false;
    text2.visible = false;
    text3.visible = false;
     text4.visible = false;
    text5.visible = false;
}
function onRoll_over(e) {

    stage.update();
}
function onRoll_out(e) {

    stage.update();
}

function answerSelected(e) {

    e.preventDefault();
    uans = e.currentTarget.name
    e.currentTarget.mouseEnabled = false;
    e.currentTarget.cursor = "default";
    gameResponseTimerStop();

    console.log(uans)
    if (ans == uans) {
        currentX = e.currentTarget.x + 50
        currentY = e.currentTarget.y + 100
        e.currentTarget.visible = true;
        for (i = 0; i < 5; i++) {
            dummyArr[i].removeEventListener("click", answerSelected);
        }
        disableMouse()

        setTimeout(correct, 500)
    } else {
        getValidation("wrong");
        disablechoices();
    }

}
function correct() {
    getValidation("correct");
    disablechoices();
}


function disableMouse() {

    for (i = 0; i < 4; i++) {
        dummyArr[i].mouseEnabled = false
    }
}
function enableMouse() {
}
//===============================================================================================//

