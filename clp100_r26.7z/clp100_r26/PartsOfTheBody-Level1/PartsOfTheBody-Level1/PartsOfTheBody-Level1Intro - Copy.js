var introQues,  introQuestxt, introTitle,  introArrow,  introfingure;
var introChoice = []
var introChoice1TweenArr = []
var highlightTweenArr = []
var setIntroCnt = 0
var removeIntraval = 0
var introQuesTextX = 0, introQuesTextY = -20;
var introQuesX = 540, introQuesY = -200
var introArrowX = 150, introArrowY =270;
var introfingureX =250, introfingureY = 380;
function commongameintro() {
    introTitle = Title.clone()
    container.parent.addChild(introTitle)
    introTitle.visible = true;
    introQuestxt = questionText.clone();
    introQues = question.clone();   
    introArrow = arrow1.clone()
    introfingure = fingure.clone()
    
    container.parent.addChild(introQuestxt)
    introQuestxt.x = introQuesTextX;
    introQuestxt.y = introQuesTextY;
    introQuestxt.visible = true;

    container.parent.addChild(introQues)
    introQues.x = introQuesX;
    introQues.y = introQuesY;
    introQues.regX = introQues.regY = 50;
    introQues.visible = false;
    introQues.gotoAndStop(0);

 

    //////////////////////////////////////////////////////////////////////////
    for (i = 0; i < 2; i++) {
        introChoice[i] = choice1.clone()
        container.parent.addChild(introChoice[i])
        introChoice[i].visible = false
        introChoice[i].x = 80 + (i * 920);
        introChoice[i].y = 400;
        introChoice[i].scaleX = introChoice[i].scaleY = .85;
    }
    ////////////////////////////////////////////////////////////////////////////////////
    introQuestxt.alpha = 0;
    createjs.Tween.get(introQuestxt).to({ x:0,y:0,alpha: 1 }, 500).call(handleComplete1_1);

}
function handleComplete1_1() {
    createjs.Tween.removeAllTweens();
    quesTween()
}
function quesTween() {
    introQues.visible = true;
    introQues.alpha = 0
    introQues.scaleX=introQues.scaleY=1
    createjs.Tween.get(introQues).wait(600)
        .to({ y: 300, scaleX: 1, scaleY:1, alpha: 1 }, 500)
        .call(handleComplete2_1)
}

function handleComplete2_1() {
    createjs.Tween.removeAllTweens();
    quesScaleTween()
}

function quesScaleTween() {

    createjs.Tween.get(introQues)
        .to({ scaleX: 1, scaleY: 1, alpha: 1 }, 500)
        .to({ scaleX:1.1, scaleY:1.1, alpha: 1 }, 500).call(handleComplete2_2)
}
function handleComplete2_2() {
    createjs.Tween.removeAllTweens();
    ChoiceTween()
}

function ChoiceTween() {
    for (i = 0; i < 2; i++) {
        introChoice[i].visible = true
        introChoice[i].alpha = 0
        introChoice[i].gotoAndStop(i)
        introChoice[i].scaleX=introChoice[i].scaleY=.95
     
        if (i == 1) {
            createjs.Tween.get(introChoice[i]).wait(100)
                .to({ visible: true, rotation: 180, scaleX: .5, scaleY: .5, alpha: .5 }, 250)
                .to({ rotation: 360, scaleX: .95, scaleY: .95, alpha: 1 }, 500).wait(200)
                .call(handleComplete3_1)
        }
        else {
            createjs.Tween.get(introChoice[i]).wait(100)
                .to({ visible: true, rotation: 180, scaleX: .5, scaleY: .5, alpha: .5 }, 250)
                .to({  rotation: 360, scaleX: .95, scaleY: .95, alpha: 1 }, 500).wait(200)
        }
    }
}
function handleComplete3_1()
{
    createjs.Tween.removeAllTweens();
    Choice2Tween();
}
function Choice2Tween()
{
      createjs.Tween.get(introChoice[0]).wait(250)
                .to({ visible: true, scaleX: .9, scaleY: .9, alpha: 1 }, 500)
                .to({  scaleX: .95, scaleY: .95, alpha: 1 }, 500).wait(500)
                   .call(handleComplete3_2)
}
function handleComplete3_2() {
    createjs.Tween.removeAllTweens();
    setArrowTween()
}
function setArrowTween() {
    if (stopValue == 0) {
        console.log("setArrowTween  == stopValue")
        removeGameIntro()
    }
    else {
        container.parent.addChild(introArrow);
        introArrow.visible = true;
        introArrow.x = introArrowX;
        introArrow.y = introArrowY;
        highlightTweenArr[0] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[0])
        highlightTweenArr[0] = createjs.Tween.get(introArrow)
            .to({ y: introArrowY + 10 }, 350).to({ y: introArrowY }, 350)
            .to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350)
            .to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350)
            .wait(400)
            .call(this.onComplete1)
    }
}

function setFingureTween() {
    if (stopValue == 0) {
        console.log("setFingureTween  == stopValue")
        removeGameIntro()
    }
    else {
        container.parent.removeChild(introArrow);
        introArrow.visible = false;
        container.parent.addChild(introfingure);
        introfingure.visible = true;
        introfingure.x = introfingureX;
        introfingure.y = introfingureY;
        highlightTweenArr[1] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[1])
        highlightTweenArr[1] = createjs.Tween.get(introfingure)
            .to({ x: introfingureX }, 350).to({ x: introfingureX - 15 }, 350)
            .to({ x: introfingureX }, 350).to({ x: introfingureX - 15 }, 350)
            .wait(200)
            .call(this.onComplete2)
    }
}


function setFingureTween() {
    if (stopValue == 0) {
        console.log("setFingureTween  == stopValue")
        removeGameIntro()

    }
    else {

        container.parent.removeChild(introArrow);
        introArrow.visible = false;
        container.parent.addChild(introfingure);
        introfingure.visible = true;
        introfingure.x = introfingureX;
        introfingure.y = introfingureY;
        highlightTweenArr[1] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[1])
        highlightTweenArr[1] = createjs.Tween.get(introfingure)
            .to({ x: introfingureX }, 350)
            .to({ x: introfingureX - 15 }, 350)
            .to({ x: introfingureX }, 350)
            .to({ x: introfingureX - 15 }, 350)
            .wait(200)
            .call(this.onComplete2)
    }
}

this.onComplete1 = function (e) {
    createjs.Tween.removeAllTweens();

    if (highlightTweenArr[0]) {
        console.log("onComplete1")
        container.parent.removeChild(highlightTweenArr[0]);
    }

    container.parent.removeChild(introArrow);
    if (stopValue == 0) {
        console.log("onComplete1  == stopValue")
        removeGameIntro()

    } else {
        setTimeout(setFingureTween, 200)
    }
}

this.onComplete2 = function (e) {
    createjs.Tween.removeAllTweens();
    if (highlightTweenArr[1]) {
        console.log("onComplete2")
        container.parent.removeChild(highlightTweenArr[1]);
    }

    container.parent.removeChild(introfingure);
    introfingure.visible = false;

    if (stopValue == 0) {
        console.log("onComplete2  == stopValue")
        removeGameIntro()

    }
    else {

        setTimeout(setCallDelay, 500)
    }

}
function setCallDelay() {
    clearInterval(removeIntraval)
    removeIntraval = 0;
    setIntroCnt++;
    console.log("check cnt = " + setIntroCnt)
    removeGameIntro()
    if (stopValue == 0) {
        console.log("setCallDelay  == stopValue")
        removeGameIntro()
    }
    else {
        commongameintro()
        if (setIntroCnt > 0) {
            isVisibleStartBtn()
        }
    }

}
function removeGameIntro() {
    createjs.Tween.removeAllTweens();
    container.parent.removeChild(introTitle)
    introTitle.visible = false;
    container.parent.removeChild(introArrow)
    introArrow.visible = false
    container.parent.removeChild(introfingure)
    introfingure.visible = false   
    introQues.visible = false
    container.parent.removeChild(introQuestxt)
    introQuestxt.visible = false
    for (i = 0; i < 2; i++) {
        container.parent.removeChild(introChoice[i])
        introChoice[i].visible = false
    }
    if (highlightTweenArr[0]) {
        highlightTweenArr[0].setPaused(false);
        container.parent.removeChild(highlightTweenArr[0]);
    }
    if (highlightTweenArr[1]) {
        highlightTweenArr[1].setPaused(false);
        container.parent.removeChild(highlightTweenArr[1]);
    }
    container.parent.removeChild(introfingure);
    introfingure.visible = false;
}