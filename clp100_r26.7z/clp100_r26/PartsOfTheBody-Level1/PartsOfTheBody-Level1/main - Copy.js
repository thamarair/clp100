
///////////////////////////////////////////////////-------Common variables--------------/////////////////////////////////////////////////////////////////////
var messageField;		//Message display field
var assets = [];
var qscnt=-1, cnt = -1, ans, uans, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, choiceCnt = 2, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;
var startBtn, introScrn, container, choice1, choice2, choice3, choice4, question, circleOutline, circle1Outline, boardMc, helpMc, quesMarkMc, questionText, quesHolderMc, resultLoading, preloadMc;
var mc, mc1, mc2, mc3, mc4, mc5, startMc, questionInterval = 0;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc, gameIntroAnimMc;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;
var bg
var BetterLuck, Excellent, Nice, Good, Super, TryAgain;
var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle,timeOver_Status=0;//for db //q
var isBgSound = true;
var isEffSound = true;
var attemptCnt
var url = "";
var nav = "";
var isResp = true;
var respDim = 'both'
var isScale = true
var scaleType = 1;
var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var loadProgressLabel, progresPrecentage, loaderWidth;
/////////////////////////////////////////////////////////////////////////GAME SPECIFIC VARIABLES/////////////////////////////////////////////////////////
var currentX
var currentY
///////////////////////////////////////////////////////////////////////GAME SPECIFIC ARRAY//////////////////////////////////////////////////////////////
var qno = [];
var chpos = [];
var quesArr = []
var chposArr = []
var choiceArr = []
var currentObj = []
// var ansMc = []
// var choicePos = [1, 0, 1, 0, 1, 0, 1, 0, 1, 0]
var choicePos = []
//register key functions
///////////////////////////////////////////////////////////////////
window.onload = function (e) {
    checkBrowserSupport();
}
///////////////////////////////////////////////////////////////////
function init() {
    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);
    createLoader()
    createCanvasResize()
    stage.update();
    stage.enableMouseOver(40);
    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////
    /*Always specify the following terms as given in manifest array. 
         1. choice image name as "ChoiceImages1.png"
         2. question text image name as "questiontext.png"
     */
    assetsPath = "assets/";
    gameAssetsPath = "PartsOfTheBody-Level1/";
    soundpath = "FA/"

    var success = createManifest();
    if (success == 1) {
        manifest.push(
        { id: "choice1", src: gameAssetsPath + "ChoiceImages1.png" },            
        { id: "question", src: gameAssetsPath + "question.png" },
        { id: "questionText", src:questionTextPath + "PartsOfTheBody-Level1-QT.png" }          
        )
        preloadAllAssets()
        stage.update();
    }
}
//=================================================================DONE LOADING=================================================================//
function doneLoading1(event) {

    loaderBar.visible = false;
    stage.update();
    var event = assets[i];
    var id = event.item.id;
    console.log("get Id =" + id)
    if (id == "questionText") {
        questionText = new createjs.Bitmap(preload.getResult('questionText'));
        container.parent.addChild(questionText);
        questionText.visible = false;
    }
    if (id == "choice1") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice1")],
            "frames": { "regX": 50, "height": 100, "count": 0, "regY": 50, "width": 308 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        //
        choice1 = new createjs.Sprite(spriteSheet1);
        container.parent.addChild(choice1);
        choice1.visible = false;
        //			 
    }

    if (id == "question") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("question")],
            "frames": { "regX": 50, "height": 360, "count": 0, "regY": 50, "width": 390 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        //
        question = new createjs.Sprite(spriteSheet1);
        container.parent.addChild(question);
        question.visible = false;
        //			 
    }

   
}

function tick(e) {
    stage.update();
}
/////////////////////////////////////////////////////////////////=======HANDLE CLICK========///////////////////////////////////////////////////////////////////
function handleClick(e) {
  
    qno = between(0, 20);
    qno.splice(qno.indexOf(0),1)
 qno.push(0)      
    CreateGameStart()
    if (gameType == 0) {
        CreateGameElements()
        getStartQuestion();
    } else {
        //for db
        getdomainpath()
        //end
    }
}
////////////////////////////////////////////////////////////=======CREATION OF GAME ELEMENTS========///////////////////////////////////////////////////////////////////
function CreateGameElements() {
 
    container.parent.addChild(questionText);
    questionText.visible = false;    
    container.parent.addChild(question)
    question.visible = false;
    question.x = 480; question.y = 200
    question.scaleX = question.scaleY = .9;

    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i] = choice1.clone()
        container.parent.addChild(choiceArr[i])
        choiceArr[i].name = "ch" + i;
        choiceArr[i].visible = false;
    }
    choiceArr[0].x = 75; choiceArr[0].y = 400
    choiceArr[1].x = 1000; choiceArr[1].y = 400
  


    if (isQuestionAllVariations) {
      
        choicePos = [0, 1, 0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1]//25
        choicePos.sort(randomSort)        
    } else {
        choicePos = [0, 1, 0,1,0,1,0,1,0,1];
        choicePos.sort(randomSort)

      
    }
}
//==============================================================HELP ENABLE/DISABLE===================================================================//
function helpDisable() {
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].mouseEnabled = false;
    }
}

function helpEnable() {
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].mouseEnabled = true;
    }
}
//==================================================================PICKQUES==========================================================================//
function pickques() {
    pauseTimer()  
    qscnt++   
    cnt++;
    quesCnt++;
    chposArr = []
    pos = []
    currentObj = []
    attemptCnt = 0
   panelVisibleFn();
 
    //=================================================================

    questionText.visible = false;
    question.visible = false;
    question.gotoAndStop(qno[cnt]);
    console.log("qno[cnt]" + qno[cnt])
    temparr = between(0, 20)
    console.log("temparr" + temparr)
    var ind = temparr.indexOf(qno[cnt]);
    temparr.splice(ind, 1)
    console.log("temparr" + temparr)
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].visible = false;
        choiceArr[i].gotoAndStop(temparr[i])
        choiceArr[i].name = i
    }
    choiceArr[choicePos[cnt]].gotoAndStop(qno[cnt])
    ans = choicePos[cnt];   
    //=========================================================================================================================================================
    createTween();
    createjs.Ticker.addEventListener("tick", tick);
    stage.update();
}

function createTween() {
    //////////////////////////////QuestionText////////////////////////////    
    questionText.visible = true
    questionText.alpha = 0;
    questionText.y = -100
    createjs.Tween.get(questionText).wait(200)     
        .to({ y: 0, alpha: 1 }, 200)   

    question.visible=true;
    question.alpha=0
    question.y = -200;
    question.scaleX=question.scaleY=1
    createjs.Tween.get(question).wait(400)
        .to({y:280,alpha: 1,scaleX:1,scaleY:1}, 500)
        .to({  alpha: 1 ,scaleX:1.1,scaleY:1.1 }, 500)  
    
  for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].visible = true;        
        choiceArr[i].alpha=0
        choiceArr[i].scaleX=choiceArr[i].scaleY=.5
        createjs.Tween.get(choiceArr[i]).wait(1500)
        .to({ rotation: 180, alpha: .5,scaleX:.5,scaleY:.5 }, 500)
        .to({ rotation: 360, alpha: 1,scaleX:1,scaleY:1 }, 500)
    }
    repTimeClearInterval = setTimeout(AddListenerFn, 2500)
}
function AddListenerFn() {
    clearTimeout(repTimeClearInterval)
    console.log("eventlisterneer")
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].mouseEnabled = true;
        choiceArr[i].visible = true;        
        choiceArr[i].cursor = "pointer";
        choiceArr[i].addEventListener("click", answerSelected)
    }
    
    rst = 0;
    gameResponseTimerStart();
    restartTimer()
}
function disablechoices() {
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].mouseEnabled = false;
        choiceArr[i].visible = false;     
        choiceArr[i].cursor = "default";
        choiceArr[i].alpha = 1
        choiceArr[i].removeEventListener("click", answerSelected)
    }
     questionText.visible = false
    question.visible=false;

}
//===================================================================MOUSE ROLL OVER/ROLL OUT==============================================================//
function onRoll_over(e) {
    e.currentTarget.alpha = .5;
    stage.update();
}

function onRoll_out(e) {
    e.currentTarget.alpha = 1;
    stage.update();
}
//=================================================================ANSWER SELECTION=======================================================================//
function answerSelected(e) {
    e.preventDefault();
    uans = e.currentTarget.name;
    gameResponseTimerStop();
    console.log(ans + " =correct= " + uans)
    if (ans == uans) {
        e.currentTarget.removeEventListener("click", answerSelected)
        for (i = 0; i < choiceCnt; i++) {
            choiceArr[i].mouseEnabled = false;
        }
        currentX = e.currentTarget.x + 75
        currentY = e.currentTarget.y + 70
        setTimeout(correct, 800)

    } else {      
        getValidation("wrong");
        disablechoices();
    }

}
function correct() {
    getValidation("correct");
    disablechoices();
}

function disableMouse() {
}

function enableMouse() {
}