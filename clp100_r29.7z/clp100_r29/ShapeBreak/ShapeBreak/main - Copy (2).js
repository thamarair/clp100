

// //////////////////////////////////////////////////////===========COMMON GAME VARIABLES==========/////////////////////////////////////////////////////////////
var messageField; //Message display field
var assets = [];
var cnt = -1, qscnt = -1, ans, uans, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, choiceCnt = 5, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0; var startBtn, introScrn, container, choice1, choice2, choice3, choice4, question, circleOutline, circle1Outline, boardMc, helpMc, quesMarkMc, questionText, quesHolderMc, resultLoading, preloadMc, introHintImg;
var mc, mc1, mc2, mc3, mc4, mc5, startMc, questionInterval = 0;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc, gameIntroAnimMc;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;
var bg;
var BetterLuck, Excellent, Nice, Good, Super, TryAgain;
var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle, timeOver_Status = 0; //for db //q
var isBgSound = true;
var isEffSound = true;
var url = "";
var nav = "";
var isResp = true;
var respDim = "both";
var isScale = true;
var scaleType = 1;
var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var loadProgressLabel, progresPrecentage, loaderWidth;



/////////////////////////////////////////////////////////////////////////GAME SPECIFIC VARIABLES//////////////////////////////////////////////////////////
var ans1, ans2, ans3
var clk;
var question1, question2, question3;
///////////////////////////////////////////////////////////////////////GAME SPECIFIC ARRAY//////////////////////////////////////////////////////////////
var qno = [];
var ansarr = [1, 2, 3]
var btnX = [165, 410, 640, 870, 1120]

//register key functions
///////////////////////////////////////////////////////////////////
window.onload = function (e) {
    checkBrowserSupport();
}
///////////////////////////////////////////////////////////////////


function init() {
    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);

    createLoader()
    createCanvasResize()

    stage.update();
    stage.enableMouseOver(40);
    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////

    /*Always specify the following terms as given in manifest array. 
         1. choice image name as "ChoiceImages1.png"
         2. question text image name as "questiontext.png"
     */

    assetsPath = "assets/";
    gameAssetsPath = "ShapeBreak/";
    soundpath = "FA/"

    var success = createManifest();
    if (success == 1) {
        manifest.push(
            { id: "chHolder", src: gameAssetsPath + "chHolder.png" },
            { id: "choice1", src: gameAssetsPath + "ChoiceImages1.png" },
            { id: "choice2", src: gameAssetsPath + "ChoiceImages2.png" },
            { id: "choice3", src: gameAssetsPath + "ChoiceImages3.png" },
            { id: "choice4", src: gameAssetsPath + "ChoiceImages4.png" },
            { id: "choice5", src: gameAssetsPath + "ChoiceImages5.png" },
            { id: "question", src: gameAssetsPath + "question.png" },
            { id: "question1", src: gameAssetsPath + "question1.png" },
            { id: "question2", src: gameAssetsPath + "question2.png" },
            { id: "question3", src: gameAssetsPath + "question3.png" },
            { id: "questionText", src: questionTextPath + "ShapeBreak-QT.png" }
        )
        preloadAllAssets()
        stage.update();
    }
}

//=====================================================================//


function doneLoading1(event) {
    var event = assets[i];
    var id = event.item.id;

    if (id == "questionText") {
        questionText = new createjs.Bitmap(preload.getResult('questionText'));
        container.parent.addChild(questionText);
        questionText.visible = false;
    }
    if (id == "chHolder") {
        chHolder = new createjs.Bitmap(preload.getResult('chHolder'));
        container.parent.addChild(chHolder);
        chHolder.visible = false;
    }

    if (id == "question") {
        var spriteSheet3 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("question")],
            "frames": { "regX": 50, "height": 213, "count": 0, "regY": 50, "width": 280 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        //
        question = new createjs.Sprite(spriteSheet3);
        container.parent.addChild(question);
        question.visible = false;
    }

    if (id == "choice1" ) {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice1")],
            "frames": { "regX": 50, "height": 213, "count": 0, "regY": 50, "width": 197 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        //
        choice1 = new createjs.Sprite(spriteSheet1);
        container.parent.addChild(choice1);
        choice1.visible = false;
        //
        
    }

    if (id == "choice2") {
       var spriteSheet2 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice2")],
            "frames": { "regX": 50, "height": 211, "count": 0, "regY": 50, "width": 197 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        //
        choice2 = new createjs.Sprite(spriteSheet2);
        container.parent.addChild(choice2);
        choice2.visible = false;
    }

	if (id == "choice3") {
        var spriteSheet3 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice3")],
            "frames": { "regX": 50, "height": 211, "count": 0, "regY": 50, "width": 197 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        //
        choice3 = new createjs.Sprite(spriteSheet3);
        container.parent.addChild(choice3);
        choice3.visible = false;
    }

    if (id == "choice4") {
        var spriteSheet3 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice4")],
            "frames": { "regX": 50, "height": 211, "count": 0, "regY": 50, "width": 197 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        //
        choice4 = new createjs.Sprite(spriteSheet3);
        container.parent.addChild(choice4);
        choice4.visible = false;
    }

    if (id == "choice5") {
        var spriteSheet3 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice5")],
            "frames": { "regX": 50, "height": 211, "count": 0, "regY": 50, "width": 197 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        //
        choice5 = new createjs.Sprite(spriteSheet3);
        container.parent.addChild(choice5);
        choice5.visible = false;
    }

    if (id == "question1") {
        var spriteSheet3 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("question1")],
            "frames": { "regX": 50, "height": 212, "count": 0, "regY": 50, "width": 281 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        //
        question1 = new createjs.Sprite(spriteSheet3);
        container.parent.addChild(question1);
        question1.visible = false;
    }

    if (id == "question2") {
        var spriteSheet3 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("question2")],
            "frames": { "regX": 50, "height": 210, "count": 0, "regY": 50, "width": 281 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        //
        question2 = new createjs.Sprite(spriteSheet3);
        container.parent.addChild(question2);
        question2.visible = false;
    }

    if (id == "question3") {
        var spriteSheet3 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("question3")],
            "frames": { "regX": 50, "height": 211, "count": 0, "regY": 50, "width": 282 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        //
        question3 = new createjs.Sprite(spriteSheet3);
        container.parent.addChild(question3);
        question3.visible = false;
    }


}

function tick(e) {
    stage.update();
}
/////////////////////////////////////////////////////////////////=======GAME START========///////////////////////////////////////////////////////////////////
function handleClick(e) {
    qno = between(0, 9)
    CreateGameStart();
    if (gameType == 0) {
        CreateGameElements();
        getStartQuestion();
    } else {
        //for db
        getdomainpath();
        //end
    }

}

function CreateGameElements() {
    interval = setInterval(countTime, 1000);

    question.x = 550
    question.y = 220

    container.parent.addChild(question);
    chHolder.visible = false

    for (i = 1; i <= choiceCnt; i++) {
        this["choice" + i].y = 575
        this["choice" + i].x = btnX[i - 1];
        this["choice" + i].regX = 50;
        this["choice" + i].regY = 50;
        this["choice" + i].visible = false
        this["choice" + i].name = i
    }

    for (i = 1; i <= 3; i++) {
        this["question" + i].y = 220;
        this["question" + i].x = 550
        //   this["question" + i].scaleX = this["question" + i].scaleY = .9
        this["question" + i].visible = false
        container.parent.addChild(this["question" + i])
    }

    container.parent.addChild(questionText);
    questionText.visible = false;

    // if (isQuestionAllVariations) {
    //     createGameWiseQuestions()
    //     pickques()
    // } else {
    //     pickques()
    // }
}

function helpDisable() {
    for (i = 1; i <= choiceCnt; i++) {
        this["choice" + i].mouseEnabled = false;
    }
}

function helpEnable() {
    for (i = 1; i <= choiceCnt; i++) {
        this["choice" + i].mouseEnabled = true;
    }
}
//=================================================================================================================================//
function pickques() {

    pauseTimer();
    //for db
    tx = 0;
    qscnt++;
    //db
    cnt++;
    quesCnt++;
    chpos = [];
    clk = 0;
    panelVisibleFn();

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    chpos = between(0, 4);
    question.gotoAndStop(qno[cnt]);
    question.visible = false
    for (i = 1; i <= 3; i++) {
        this["question" + i].gotoAndStop(qno[cnt]);
        this["question" + i].visible = false
    }

    for (i = 1; i <= choiceCnt; i++) {
        this["choice" + i].gotoAndStop(qno[cnt]);
        this["choice" + i].x = btnX[chpos[i - 1]]
    }

    createTween();
}

function createTween() {
    questionText.visible = true;
    questionText.alpha = 0;
    createjs.Tween.get(questionText).wait(100).to({ alpha: 1 }, 200);

    createjs.Tween.get(chHolder).wait(200).to({ visible: true }, 600, createjs.Ease.bounceOut);

    question.visible = true;
    question.y = -1000
    createjs.Tween.get(question).wait(300).to({ y: 220 }, 600, createjs.Ease.bounceOut);


    var tempVal =400;
    for (i = 1; i <= 5; i++) {
        createjs.Tween.get(this["choice" + i]).wait(tempVal).to({ visible: true }, 600, createjs.Ease.bounceOut);
        tempVal += 10;
    }


    repTimeClearInterval = setTimeout(AddListenerFn, 2000)
}


function AddListenerFn() {
    clearTimeout(repTimeClearInterval);
    for (i = 1; i <= choiceCnt; i++) {
        this["choice" + i].addEventListener("click", answerSelected);
        this["choice" + i].visible = true;
        this["choice" + i].cursor = "pointer"
    }

    rst = 0;
    gameResponseTimerStart();
    restartTimer()
}


function disablechoices() {
    for (i = 1; i <= choiceCnt; i++) {
        this["choice" + i].removeEventListener("click", answerSelected);
        this["choice" + i].visible = false;

    }

}


function answerSelected(e) {
    clk++
    e.preventDefault();
    uans = e.currentTarget.name;
    e.currentTarget.visible = false;
    gameResponseTimerStop();
    // pauseTimer();
    console.log(ansarr[clk - 1] + " =correct= " + uans)

    if (uans == 1 || uans == 2 || uans == 3) {
        this["question" + uans].visible = true
        //   this["choice" + uans].x=500
        //  this["choice" + uans].y=110
        if (clk == 3) {
            setTimeout(correct, 700)
            disablechoices();
        }
    }
    else {
        getValidation("wrong");
        disablechoices();
    }
}

function correct() {
    getValidation("correct");
    for (i = 1; i <= 3; i++) {
        this["question" + i].visible = false
    }

}
//===========================================================================================//
