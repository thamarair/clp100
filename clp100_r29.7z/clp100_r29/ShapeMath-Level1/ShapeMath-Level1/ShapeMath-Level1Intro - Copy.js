var introArrow, introquestionText, introfingure, introTitle, introHintimg;
var introChoiceArr = []
var introQuesArr = []
var highlightTweenArr = []
var highlightTweenArr = [],introqtextArr1=[],introqtextArr2=[],introoperationsArr=[];
var setIntroCnt = 0
var removeIntraval = 0
var introChoiceX = [, 180, 870, 525];
var introChoiceY = [, 210, 210, 440];
var introQuestxtX = 636; introQuestxtY = 120;
var introHintImgX = 425, introHintImgY = 200
var introquestionX = 450; introquestionY = 240;
var introArrowX = 686, introArrowY = 493;
var introfingureX = 703, introfingureY = 610;
var introChoiceArrX = [400, 535, 685, 820]
var introBall = new Array(6);
var introRadiusArray = [18, 16, 14, 22, 30];

var introqtextArr1X = [470,730, 770,510];
var introqtextArr1Y = [240, 240, 480, 480];
var introqtextArr2X = [820,820, 780, 834];
var introqtextArr2Y = [221, 331, 458, 458];

var introQuesX =  [440, 680, 440, 680, 396, 599]	//797 , 458
var introQuesY = [221, 221, 331, 331, 458, 458]
var introsX = [350, 690, 890, 570];
var introsY = [260, 340, 210, 395];
var introoperationX = [566, 566, 502,702];
var introoperationY = [221, 331, 458, 458];
var introrandomnum = [3, 0, 2, 1];
function commongameintro() {
    TempIntroVal = -1;
    introTitle = Title.clone()
    introArrow = arrow1.clone()
    introfingure = fingure.clone()
	introHolder = qHolder.clone()
	introHintimg=hintImage.clone();
	
	//intQuesArr = [1,1,2,1,3,4] 
    // questionText1.visible = false;

    for (i = 0; i < 6; i++) {
		introQuesArr[i] =question.clone();
        // introQuesArr[i].gotoAndStop(intQuesArr[i])
		introQuesArr[i].visible = false;
		//introQuesArr[i].x = introQuesX[i].x
       // introQuesArr[i].y = introQuesY[i].y
       // introQuesArr[i].alpha = 1;
    }  
	
	for (i = 0; i < 4; i++) {
        introoperationsArr[i] =operations.clone();
    }
    introquestionText = questionText.clone()
	
	
	for (i = 0; i < 4; i++) {
		introChoiceArr[i] = choice1.clone();
		introChoiceArr[i].visible = false;
	}
    container.parent.addChild(introTitle)
    introTitle.visible = true;

    container.parent.addChild(introquestionText);
    introquestionText.visible = true
	container.parent.addChild(introHolder)
    introHolder.visible = false;
	
	// for (i = 0; i < 6; i++) {
        // container.parent.addChild(introQuesArr[i])
        // introQuesArr[i].visible = false;
        // introQuesArr[i].x = introQuesX[i]
        // introQuesArr[i].y = introQuesY[i]
        // introQuesArr[i].gotoAndStop(i)
        // introQuesArr[i].scaleX = introQuesArr[i].scaleY =1.1      
    // }
	
	
	intQuesArr = [1,3,2,1,2,1] //,3

    for (i = 0; i < 6; i++) {
		introQuesArr[i] =question.clone();
        introQuesArr[i].gotoAndStop(intQuesArr[i])
		container.parent.addChild(introQuesArr[i])
		introQuesArr[i].visible = false;
		introQuesArr[i].x = introQuesX[i]
        introQuesArr[i].y = introQuesY[i]
        introQuesArr[i].alpha = 1;
    }
	
	for (i = 0; i < 4; i++) {
        container.parent.addChild(introoperationsArr[i])
        introoperationsArr[i].visible = false;
        introoperationsArr[i].x = introoperationX[i]
        introoperationsArr[i].y = introoperationY[i]
        introoperationsArr[i].gotoAndStop(i)
        introoperationsArr[i].scaleX = introoperationsArr[i].scaleY =1.1      
    } 
	
      introRand = [0, 3, 4, 1, 3, 2, 6]
    // for (i = 0; i < 4; i++) {
        // introBall[i] = new introballs(i);
        // introBall[i].obj = choice1.clone();
        // introBall[i].obj.gotoAndStop(introRand[i]);
        // container.parent.addChild(introBall[i].obj)
        // introBall[i].obj.visible = false;
        // introBall[i].obj.x = introBall[i].x
        // introBall[i].obj.y = introBall[i].y
        // introBall[i].obj.alpha = 1;
    // } 
	
	intchoiceArr = [0,2,3,1] 
      for (i = 0; i < 4; i++) {
		  introChoiceArr[i] =choice1.clone();
          container.parent.addChild(introChoiceArr[i])
          introChoiceArr[i].visible = false;
          introChoiceArr[i].x = introChoiceArrX[i]   //30 + (i * 120) //btnX[i]
          introChoiceArr[i].y = 605;
          introChoiceArr[i].scaleX = introChoiceArr[i].scaleY = .5
          introChoiceArr[i].gotoAndStop(intchoiceArr[i]);
      }
	  
		container.parent.addChild(introHintimg)
		introHintimg.visible = false;
	
	for (i = 0; i < 4; i++) {
        introqtextArr1[i] = new createjs.Text("=", "50px lato-Bold", "red")
        container.parent.addChild(introqtextArr1[i])
        introqtextArr1[i].textAlign = "center";
        introqtextArr1[i].textBaseline = "middle";
        introqtextArr1[i].visible = false;
        introqtextArr1[i].x = introqtextArr1X[i];
        introqtextArr1[i].y = introqtextArr1Y[i];
    }
    var introVal2 = ["= 9", "= 6", "?", "= 9"];
    for (i = 0; i < 4; i++) {
        introqtextArr2[i] = new createjs.Text("", "35px lato-Bold", "black")
        container.parent.addChild(introqtextArr2[i])
        introqtextArr2[i].text = introVal2[i]
        introqtextArr2[i].textAlign = "center";
        introqtextArr2[i].textBaseline = "middle";
        introqtextArr2[i].visible = false;
        introqtextArr2[i].x = introqtextArr2X[i];
        introqtextArr2[i].y = introqtextArr2Y[i];
    }
	
	// introqtextArr2[2].color = "red"
	// introqtextArr2[2].x = 780
	// introqtextArr2[3].color = "black"
	// introqtextArr2[3].x = 830
	
   // introChoiceArr[1].gotoAndStop(6);
   
    introHolder.visible = true;
    introHolder.alpha = 0;
    introHolder.y = -3000;
    createjs.Tween.get(introHolder).wait(400).to({ alpha: 1, y: 100 }, 100, createjs.Ease.bounceOut).to({ y: 50 }, 100, createjs.Ease.bounceOut)
        .to({ y: 0 }, 100, createjs.Ease.bounceOut).wait(2000);
    introquestionText.alpha = 0;
    createjs.Tween.get(introquestionText).to({ alpha: 1 }, 1000).call(handleComplete1_1);

}

function handleComplete1_1() {
    createjs.Tween.removeAllTweens();
    quesTween()
}

function quesTween() {
	
	// introHolder.visible = true;
    // introHolder.alpha = 0;
    // introHolder.y = -3000;
    // createjs.Tween.get(introHolder).wait(400).to({ alpha: 1, y: 100 }, 100, createjs.Ease.bounceOut).to({ y: 50 }, 100, createjs.Ease.bounceOut)
        // .to({ y: 0 }, 100, createjs.Ease.bounceOut).wait(2000);
		
		
		for (i = 0; i < 6; i++) {
         introQuesArr[i].alpha = 0
         
              createjs.Tween.get(introQuesArr[i]).wait(700).to({visible:true,  x: introQuesArr[i].x, y: introQuesArr[i].y, alpha: .5 }, 200).to({ x: introQuesArr[i].x, y: introQuesArr[i].y, alpha: 1 }, 200);
        
          introQuesArr[i].visible = true
      }
	  
	 //  var introTempVal = 400;
	  for (i = 0; i < 4; i++) {
        introoperationsArr[i].visible = true;
        introoperationsArr[i].alpha = 0;
        
            createjs.Tween.get(introoperationsArr[i]).wait(1200).to({ alpha: 1, x: introoperationsArr[i].x, y:introoperationsArr[i].y  }, 200); 
        //introTempVal += 20;
    } 
	
	var introChWait1 = 1500;
		for (i = 0; i < 4; i++) {
			introqtextArr1[i].alpha = 0
			if (i == 2) {
				createjs.Tween.get(introqtextArr1[i]).wait(introChWait1).to({ visible: true, alpha: 1 }, 600).wait(1000).call(handleComplete3_1);
			} else {
				createjs.Tween.get(introqtextArr1[i]).wait(introChWait1).to({ visible: true, alpha: 1 }, 600);
			}
			introChWait1 += 400;
		}
		
		var introChWait1 = 1500;
		for (i = 0; i < 4; i++) {
			introqtextArr2[i].alpha = 0
			if (i == 2) {
				createjs.Tween.get(introqtextArr2[i]).wait(introChWait1).to({ visible: true, alpha: 1 }, 600).wait(1000).call(handleComplete3_1);
			} else {
				createjs.Tween.get(introqtextArr2[i]).wait(introChWait1).to({ visible: true, alpha: 1 }, 600);
			}
			introChWait1 += 400;
		} 
	

      for (i = 0; i < 4; i++) {
          introChoiceArr[i].alpha = 0
         
              createjs.Tween.get(introChoiceArr[i]).wait(2800).to({ x: introChoiceArr[i].x, y: introChoiceArr[i].y, alpha: .5 }, 200).to({ x: introChoiceArr[i].x, y: introChoiceArr[i].y, alpha: 1 }, 200).call(handleComplete2_1);
        
          introChoiceArr[i].visible = true
      }
  //  createjs.Ticker.addEventListener("tick", handleComplete2_1);
}
 
   
function handleComplete2_1() {
    if (stopValue == 0) {
        removeGameIntro()
    } else {
        createjs.Tween.removeAllTweens();
        choiceTween()
    }
}
function choiceTween() {
    if (stopValue == 0) {
        removeGameIntro()
    } else { 
		 setTimeout( hintTween, 1700)
		// var introChWait1 = 1500;
		// for (i = 0; i < 4; i++) {
			// introqtextArr2[i].alpha = 0
			// if (i == 3) {
				// createjs.Tween.get(introqtextArr2[i]).wait(introChWait1).to({ visible: true, alpha: 1 }, 600).wait(1000).call(handleComplete3_1);
			// } else {
				// createjs.Tween.get(introqtextArr2[i]).wait(introChWait1).to({ visible: true, alpha: 1 }, 600);
			// }
			// introChWait1 += 400;
		// }  
    } 

}

function hintTween()
{
   introHintimg.visible = true;
   introHintimg.alpha=0
   introHintimg.x=-250;
   introHintimg.y=0
     createjs.Tween.get(introHintimg)
        .to({visible: true, alpha: 1,x:-10,y:31},500, createjs.Ease.bounceOut)  
        .to({ scaleX:.75,scaleY:.75},500)
        .to({ scaleX:.8,scaleY:.8},500)
        .call(handleComplete3_1)
}

function handleComplete3_1() {
    if (stopValue == 0) {
        removeGameIntro()
    } else {
        createjs.Tween.removeAllTweens();
        setArrowTween()
    }
}

function setArrowTween() {
    if (stopValue == 0) {
        removeGameIntro()

    }
    else {
        container.parent.addChild(introArrow); 
        introArrow.visible = true;
        introArrow.x = introArrowX;
        introArrow.y = introArrowY;
        highlightTweenArr[0] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[0])
        highlightTweenArr[0] = createjs.Tween.get(introArrow).to({ y: introArrowY + 10 }, 350).to({ y: introArrowY }, 350).to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350)
            .to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350)
            .wait(400)
            .call(setFingureTween)
    }
}

function setFingureTween() {
    if (stopValue == 0) {
        console.log("setFingureTween  == stopValue")
        removeGameIntro()
    }
    else {

        container.parent.removeChild(introArrow);
        introArrow.visible = false;
        container.parent.addChild(introfingure);
        introfingure.visible = true; 
        introfingure.x = introfingureX;
        introfingure.y = introfingureY;
        highlightTweenArr[1] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[1])
        highlightTweenArr[1] = createjs.Tween.get(introfingure)
            .to({ x: introfingureX }, 350)
            .to({ x: introfingureX - 15 }, 350)
            .to({ x: introfingureX }, 350)
            .to({ x: introfingureX - 15 }, 350)
            .wait(200)
           // .call(setCallDelay)
            .call(textFn)
        //setTimeout(setstarAnimation, 1000)
    }
}
 function textFn() {
    var letterVerArr = [3]
    var letterVerArr1 = [3]
    //introqtextArr2[letterVerArr[TempIntroVal]] = letterVerArr1[TempIntroVal]
	introqtextArr2[letterVerArr[TempIntroVal]] = letterVerArr1[TempIntroVal]
	setTimeout(setCallDelay, 1000)
    // introqtextArr[letterVerArr[TempIntroVal]].color = "red"
    // introqtextArr[4].text = "?"
    //  introqtextArr[4].color = "red"
}

function setCallDelay() {
	createjs.Tween.removeAllTweens();
    clearInterval(removeIntraval)
    removeIntraval = 0
    setIntroCnt++
    removeGameIntro()
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        commongameintro()
        if (setIntroCnt > 0) {
            isVisibleStartBtn()
        }
    }

}
function removeGameIntro() {
    createjs.Tween.removeAllTweens();
    // container.parent.removeChild(introTitle)
    // introTitle.visible = false;
	 container.parent.removeChild(introHolder)
    introHolder.visible = false
    container.parent.removeChild(introArrow)
    introArrow.visible = false
    container.parent.removeChild(introfingure)
    introfingure.visible = false
    container.parent.removeChild(introquestionText)
    introquestionText.visible = false
	for (i = 0; i < 6; i++) {
        container.parent.removeChild(introQuesArr[i])
        introQuesArr[i].visible = false
    }
	for (i = 0; i < 4; i++) {
        container.parent.removeChild(introoperationsArr[i])
        introoperationsArr[i].visible = false
    }
    for (i = 0; i < 4; i++) {
	   container.parent.removeChild(introChoiceArr[i])
	   introChoiceArr[i].visible = false
    } 
	
	for (i = 0; i < 4; i++) {
		container.parent.removeChild(introqtextArr2[i])
	    introqtextArr2[i].visible = false 
			
	} 
	 introHintimg.visible = false;
	 container.parent.removeChild(introHintimg)
	// for (i = 0; i < 4; i++) {
        // container.parent.removeChild(introBall[i].obj)
        // introBall[i].obj.visible = false
    // }
}