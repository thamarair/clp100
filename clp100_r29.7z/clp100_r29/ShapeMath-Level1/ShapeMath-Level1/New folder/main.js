///////////////////////////////////////////////////-------Common variables--------------/////////////////////////////////////////////////////////////////////
var messageField;		//Message display field
var assets = [];
var cnt = -1, qscnt = -1, ans, uans, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, choiceCnt = 5, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;
var startBtn, introScrn, container, choice1, choice2, choice3, choice4, question, circleOutline, circle1Outline, boardMc, helpMc, quesMarkMc, questionText, quesHolderMc, resultLoading, preloadMc;
var mc, mc1, mc2, mc3, mc4, mc5, startMc, questionInterval = 0;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc, gameIntroAnimMc;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0, qcnt = 0;
var bg
var BetterLuck, Excellent, Nice, Good, Super, TryAgain;
var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle, timeOver_Status = 0;//for db //q
var isBgSound = true;
var isEffSound = true;

var url = "";
var nav = "";
var isResp = true;
var respDim = 'both'
var isScale = true
var scaleType = 1;

var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var loadProgressLabel, progresPrecentage, loaderWidth;
/////////////////////////////////////////////////////////////////////////GAME SPECIFIC VARIABLES//////////////////////////////////////////////////////////
var posx, posy;
var rand, clk
var removeIndex2, removeIndex1, removeIndex3
///////////////////////////////////////////////////////////////////////GAME SPECIFIC ARRAY//////////////////////////////////////////////////////////////
var qno = [];
var radiusArray=[]
var quesArr = []
var operationsArr = []
var textArr = [];
var qtextArr1 = [];
var qtextArr2 = [];
var qtextArr3 = [], cno = [];
var choiceArr = [460, 585, 730, 870]  
var numBalls = 6;
var balls = new Array(numBalls);
var width = 840;
var height = 430;
var btnX = [280, 500, 700, 922]
var posArr = [0, 1, 2, 0, 1, 2, 0, 1, 2, 0]
var quesX =  [420, 725, 420, 725, 372, 581]	//797 , 458
var quesY = [222, 222, 333, 333, 461, 461]
var introsX = [350, 690, 890, 570];
var introsY = [260, 340, 210, 395];
var operationX = [580, 580, 492,700];
var operationY = [222, 333, 461, 461];
 var alphaArr = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
var qtextArr2X = [867,867, 780, 864];
var qtextArr3X = [830,830, 830, 854];
var qtextArr2Y = [222, 333, 461, 461];

var sX=[]
var sY=[]
var randomnum=[]
//register key functions
///////////////////////////////////////////////////////////////////
window.onload = function (e) {
    checkBrowserSupport();
}
///////////////////////////////////////////////////////////////////
function init() {
    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);
    callLoader();
    createLoader()
    createCanvasResize()

    stage.update();
    stage.enableMouseOver(40);
    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////

    /*Always specify the following terms as given in manifest array. 
         1. choice image name as "ChoiceImages1.png"
         2. question text image name as "questiontext.png"
     */

    assetsPath = "assets/";
    gameAssetsPath = "ShapeMath-Level1/";
    soundpath = "FA/"

    var success = createManifest();
    if (success == 1) {
        manifest.push(
            { id: "choice1", src: gameAssetsPath + "ChoiceImages1.png" },
            { id: "question", src: gameAssetsPath + "question.png" },
			{ id: "qHolder", src: gameAssetsPath + "Holder.png" },
            { id: "operations", src: gameAssetsPath + "operations.png" }, 
			{ id: "hintImage", src: questionTextPath + "Hint/ShapeMath-Level1-Hint.png" },
            // { id: "questionText", src: gameAssetsPath + "questiontext.png" }
            { id: "questionText", src: questionTextPath + "ShapeMath-Level1-QT.png" }
        )
        preloadAllAssets()
        stage.update();
    }
}
//=====================================================================//
function doneLoading1(event) {
    var event = assets[i];
    var id = event.item.id;

    if (id == "question") {
        var spriteSheet3 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("question")],
            "frames": { "regX": 50, "height": 110, "count": 0, "regY": 50, "width": 110 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        }); 
        question = new createjs.Sprite(spriteSheet3);
        container.parent.addChild(question);
        question.visible = false;
    }  
	
	if (id == "choice1") {
        var spriteSheet3 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice1")],
            "frames": { "regX": 50, "height": 220, "count": 0, "regY": 50, "width": 220 } 
        }); 
        choice1 = new createjs.Sprite(spriteSheet3);
        container.parent.addChild(choice1);
        choice1.visible = false;
    }
	
	if (id == "operations") {
        var spriteSheet3 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("operations")],
            "frames": { "regX": 50, "height": 106, "count": 0, "regY": 50, "width": 106 } 
        }); 
        operations = new createjs.Sprite(spriteSheet3);
        container.parent.addChild(operations);
        operations.visible = false;
    }
	
	if (id == "qHolder") {
        qHolder = new createjs.Bitmap(preload.getResult('qHolder'));
        qHolder.visible = false;
        container.parent.addChild(qHolder);
    }

    if (id == "hintImage") {
        hintImage = new createjs.Bitmap(preload.getResult('hintImage'));
        container.parent.addChild(hintImage);
        hintImage.visible = false;
    }; 

    if (id == "questionText") {
        questionText = new createjs.Bitmap(preload.getResult('questionText'));
        container.parent.addChild(questionText);
        questionText.visible = false;
    }
}

function tick(e) {

    stage.update();
}

/////////////////////////////////////////////////////////////////=======GAME START========///////////////////////////////////////////////////////////////////
function handleClick(e) {
    qno = between(0, 9);
	qno.splice(qno.indexOf(0), 1);
    qno.push(0); 
	console.log('gggh '+qno)
    CreateGameStart()
    if (gameType == 0) {
        CreateGameElements()
        getStartQuestion();
    } else {
        //for db
        getdomainpath()
        //end
    }
} 
function CreateGameElements() {
    interval = setInterval(countTime, 1000);

    // chHolder.visible = true;
    container.parent.addChild(questionText);
    questionText.visible = false;
	container.parent.addChild(qHolder);
    qHolder.visible = false;
	
	// rand = between(0, 19)
	// for (i = 0; i < 6; i++) {
        // quesArr[i] = question.clone();
        // container.parent.addChild(quesArr[i]);
		// // quesArr[i]  = rand[i]
        // quesArr[i].visible = false;
        // quesArr[i].x = quesX[i];
        // quesArr[i].y = quesY[i];
         // quesArr[i].gotoAndStop(i)
        // quesArr[i].scaleX = quesArr[i].scaleY = 1.1
    // }
	console.log('gggh '+qno)
	// rand = between(0, 19)
    rand = [0,1,2,1,2,1] 
        for (i = 0; i < 6; i++) {
            quesArr[i] = question.clone()
            container.parent.addChild(quesArr[i]);
			console.log('quesArr '+i)
            quesArr[i].visible = false;
            quesArr[i].x = quesX[i]   
            quesArr[i].y = quesY[i];
            quesArr[i].scaleX = quesArr[i].scaleY = 1.1
            quesArr[i].gotoAndStop(rand[i]);
            quesArr[i].name = rand[i]; 
        }
	
	for (i = 0; i < 4; i++) {
        operationsArr[i] = operations.clone();
        container.parent.addChild(operationsArr[i]);
        operationsArr[i].visible = false;
        operationsArr[i].x = operationX[i];
        operationsArr[i].y = operationY[i];
        operationsArr[i].gotoAndStop(i)
        operationsArr[i].scaleX = operationsArr[i].scaleY = 1.1
    }
	
	//intQuesArr = [1,1,2,1,3,4] 
    // questionText1.visible = false;

    // for (i = 0; i < 6; i++) {
		// introQuesArr[i] =question.clone();
        // // introQuesArr[i].gotoAndStop(intQuesArr[i])
		// introQuesArr[i].visible = false;
		// //introQuesArr[i].x = introQuesX[i].x
       // // introQuesArr[i].y = introQuesY[i].y
       // // introQuesArr[i].alpha = 1;
    // } 
	
	
	
	// var qtextArr1X = [820,820, 780, 834];
// var qtextArr1Y = [222, 333, 461, 461];
  // var introVal = ["=", "=", "="];
 // for (i = 0; i < 3; i++) {
	 // console.log("jjggu")
        // qtextArr1[i] = new createjs.Text("", "46px lato-Bold", "red")
        // container.parent.addChild(qtextArr1[i])
		 // qtextArr1[i].text = introVal[i]
        // qtextArr1[i].textAlign = "center";
        // qtextArr1[i].textBaseline = "middle";
        // qtextArr1[i].visible = false;
        // qtextArr1[i].x = qtextArr1X[i].x;
        // qtextArr1[i].y = qtextArr1Y[i].y;
    // }
	
	 var introVal2 = ["9", "6", "?" ,"9"];
	 for (i = 0; i < 4; i++) {
         qtextArr2[i] = new createjs.Text("", "50px lato-Bold", "black")
          container.parent.addChild(qtextArr2[i])
          qtextArr2[i].text = introVal2[i]
          qtextArr2[i].textAlign = "center";
          qtextArr2[i].textBaseline = "middle"; 
          qtextArr2[i].visible = false;
          qtextArr2[i].x = qtextArr2X[i];
          qtextArr2[i].y = qtextArr2Y[i]; 
      }
	  
	  qtextArr2[2].color = "red"
	  //createjs.Tween.get(qtextArr2[2]).wait(200).to({ alpha: 1 }, 200);
	   createjs.Tween.get(qtextArr2[2],{loop:true}).wait(500).to({scaleX:1,scaleY:1},400).to({scaleX:.88,scaleY:.88},400).to({scaleX:1.3,scaleY:1.3},400)
	  
	 var introVal3 = ["=", "=", "="];
	 for (i = 0; i < 3; i++) {
         qtextArr3[i] = new createjs.Text("", "51px lato-Bold", "black")
          container.parent.addChild(qtextArr3[i])
          qtextArr3[i].text = introVal3[i]
          qtextArr3[i].textAlign = "center";
          qtextArr3[i].textBaseline = "middle"; 
          qtextArr3[i].visible = false;
          qtextArr3[i].x = qtextArr3X[i];
          qtextArr3[i].y = qtextArr2Y[i];
      }
	
	 var txtX = [480, 550, 715, 790, 685, 590]
    var txty = [300, 210, 210, 300, 510, 510]
    for (i = 0; i < 6; i++) {
        alphaArr[i] = new createjs.Text("", "45px lato-Bold", "red")
        container.parent.addChild(alphaArr[i]);
        alphaArr[i].textAlign = "center";
        alphaArr[i].textBaseline = "middle";
        alphaArr[i].x = txtX[i];
        alphaArr[i].y = txty[i];
        alphaArr[i].visible = false;
    }
    
   if (isQuestionAllVariations) {
        createGameWiseQuestions()
        // pickques()
        posArr = [0, 1, 2, 0, 1, 2, 0, 1, 2, 0,0, 1, 2, 0, 1, 2, 0, 1, 2, 0,0, 1, 2, 0, 1, 2, 0, 1, 2, 0]
    } else {
        // pickques()
        posArr = [0, 1, 2, 0, 1, 2, 0, 1, 2, 0]
    }
    posArr.sort(randomSort)
}

function helpDisable() {
    for (i = 1; i < 5; i++) {
        choiceArr[i].mouseEnabled = false;
    }
}

function helpEnable() {
    for (i = 1; i < 5; i++) {
        choiceArr[i].mouseEnabled = true;
    }
}


//=================================================================================================================================//
function pickques() {
    pauseTimer()
    //for db
    tx = 0;
    qscnt++;
    clk = 0;
    cnt++;
    quesCnt++;
    //db
    chpos = [];
	
    panelVisibleFn()
	// position = qno[qcnt];
    // console.log(qno);
    // console.log(position);  
	// for(i=0; i<7; i++){
        // if(i == qcnt){
            // console.log("Position Found", position, "value of X =", quesX[position], "value of Y =", quesY[position]);
            // quesArr[i].visible = true;
            // quesArr[i].x = quesX[position];
            // quesArr[i].y = quesX[position];
            // createjs.Tween.get(quesArr[i]).wait(3000).to({alpha: 0})
        // }
       // // quesArr[i].gotoAndStop(qno[i])
    // }
    // qcnt++;
	
	// for (i = 0; i < 20; i++) {

        // cno[i] = i
    // }
    // cno.sort(randomSort)

    // var rand = cno.indexOf(qno[cnt])
    // console.log("cno///" + cno)
    // cno.splice(rand, 1)
    // console.log("cno" + cno)
    //=================================================================================================================================//
   // rand = between(0, 19)
  // rand = [0] 
        for (i = 0; i < 4; i++) {
            choiceArr[i] = choice1.clone()
            container.parent.addChild(choiceArr[i]);
            choiceArr[i].visible = false;
            choiceArr[i].x = btnX[i]   //30 + (i * 120) //btnX[i]
            choiceArr[i].y = 580;
            choiceArr[i].scaleX = choiceArr[i].scaleY = .65
           // choiceArr[i].gotoAndStop(rand[i]);
           // choiceArr[i].name = rand[i];
			choiceArr[i].name = i
           // chpos.push({ posx: choiceArr[i].x, posy: choiceArr[i].y })
        }
    
    ans = rand[0];
   // chpos.sort(randomSort)
    // for (i = 0; i < 5; i++) {
        // choiceArr[i].x = chpos[i].posx
        // choiceArr[i].y = chpos[i].posy
    // }
	qHolder.visible=false
    createTween();
}
 
function createTween() {
    questionText.visible = true;  
	 
	//rand = between(0, 19) 
	rand = [0,1,2,1,2,1] 
	var tempVal = 300;
    for (i = 0; i < 6; i++) {
        quesArr[i].visible = true;
		console.log("quesArr")
        quesArr[i].alpha = 0;
		 quesArr[i].gotoAndStop(rand[i]);
            quesArr[i].name = rand[i]; 
        createjs.Tween.get(quesArr[i]).wait(tempVal).to({ alpha: .3, x: quesArr[i].x - 20 }, 200, createjs.Ease.bounceOut).to({ alpha: .6, y: quesArr[i].y + 20 }, 200, createjs.Ease.bounceOut)
            .to({ alpha: .8, x: quesArr[i].x + 20 }, 200, createjs.Ease.bounceOut).to({ alpha: 1, x: quesArr[i].x, y: quesArr[i].y }, 200, createjs.Ease.bounceOut);
        tempVal += 20;
    }  
	console.log('rand '+rand)
	
	
	for (i = 0; i < 4; i++) {
        operationsArr[i].visible = true;
        operationsArr[i].alpha = 0;
        createjs.Tween.get(operationsArr[i]).wait(tempVal).to({ alpha: .3, x: operationsArr[i].x - 20 }, 200, createjs.Ease.bounceOut).to({ alpha: .6, y: operationsArr[i].y + 20 }, 200, createjs.Ease.bounceOut)
            .to({ alpha: .8, x: operationsArr[i].x + 20 }, 200, createjs.Ease.bounceOut).to({ alpha: 1, x: operationsArr[i].x, y: operationsArr[i].y }, 200, createjs.Ease.bounceOut);
        tempVal += 20;
    }
	
	
	
    questionText.alpha = 0
    createjs.Tween.get(questionText).wait(200).to({ alpha: 1 }, 200).call(createTween1);

}
function createTween1() {
	qHolder.visible = true;
    qHolder.alpha = 0;
    qHolder.y=-3000;
    createjs.Tween.get(qHolder).wait(400).to({ alpha: 1, y: 100 }, 100, createjs.Ease.bounceOut).to({ y: 50 }, 100, createjs.Ease.bounceOut).to({ y: 0 }, 100, createjs.Ease.bounceOut)
	
    // for (i = 0; i < 4; i++) {
        // balls[i].obj.visible = true;
    // }

    
	
	  // var introChWait = 1500;
		  // for (i = 0; i < 3; i++) {
			   // qtextArr1[i].alpha = 0
			 
				  // createjs.Tween.get(qtextArr1[i]).wait(introChWait).to({ visible: true, alpha: 1 }, 600); 
			 // introChWait += 400;
		  // } 
	   var tempVal1 = 1200;
	 
	 var introChWait1 = 200;
		for (i = 0; i < 4; i++) {
			qtextArr2[i].alpha = 0
			if (i == 2) {
				createjs.Tween.get(qtextArr2[i]).wait(introChWait1).to({ visible: true, alpha: 1 }, 600).wait(1000);
			} else {
				createjs.Tween.get(qtextArr2[i]).wait(introChWait1).to({ visible: true, alpha: 1 }, 600);
			}
			introChWait1 += 400;
		} 
	 var tempVal1 = 1200; 
	 
	 var introChWait1 = 100;
		for (i = 0; i < 3; i++) {
			qtextArr3[i].alpha = 0
			if (i == 2) {
				createjs.Tween.get(qtextArr3[i]).wait(introChWait1).to({ visible: true, alpha: 1 }, 600).wait(1000);
			} else {
				createjs.Tween.get(qtextArr3[i]).wait(introChWait1).to({ visible: true, alpha: 1 }, 600);
			}
			introChWait1 += 400;
		} 
	 var tempVal1 = 1200;
	 
	 
	 
    for (i = 0; i < 6; i++) {
        createjs.Tween.get(alphaArr[i]).wait(tempVal1).to({ visible: true }, tempVal1, createjs.Ease.bounceIn);
        tempVal1 += 300;
    }
	
	//rand = between(0, 19)	
	randchoice = [0,1,2,1,2,1] 
	for (i = 0; i < 4; i++) {
         choiceArr[i].alpha = 0 
		  choiceArr[i].gotoAndStop(randchoice[i]);
            choiceArr[i].name = randchoice[i]; 
              createjs.Tween.get(choiceArr[i]).wait(2000).to({visible:true, x: choiceArr[i].x, y: choiceArr[i].y, alpha: 1 }, 200) 
          choiceArr[i].name = i
        choiceArr[i].visible = true
    }
	console.log('randchoice '+randchoice)
	
    //createjs.Ticker.addEventListener("tick", createRandomBalls);
    repTimeClearInterval = setTimeout(AddListenerFn, 1600)
}

// function AddListenerFn() {
    // clearTimeout(repTimeClearInterval)
    // for (i = 0; i < 4; i++) {
        // choiceArr[i].addEventListener("click", answerSelected)
        // choiceArr[i].cursor = "pointer";
        // choiceArr[i].mouseEnabled = true
    // }
    // rst = 0;
    // gameResponseTimerStart();
    // restartTimer()
// }
function AddListenerFn() {
    clearTimeout(repTimeClearInterval)
    for (i = 0; i < 4; i++) {
        choiceArr[i].addEventListener("click", answerSelected);
        choiceArr[i].visible = true;
        choiceArr[i].mouseEnabled = true;
        choiceArr[i].cursor = "pointer"
        choiceArr[i].alpha = 1;
    }

    rst = 0;
    gameResponseTimerStart();
    restartTimer()
}
 
// function enablechoices() {
    // for (i = 0; i < 4; i++) {
        // choiceArr[i].addEventListener("click", answerSelected);
        // choiceArr[i].mouseEnabled = true;
        // choiceArr[i].visible = true;
        // choiceArr[i].alpha = 1;
        // choiceArr[i].cursor = "pointer";
    // }
// } 
function disablechoices() {
    for (i = 0; i < 4; i++) {
        choiceArr[i].removeEventListener("click", answerSelected);
        choiceArr[i].visible = false;
    }
    // for (i = 0; i < 4; i++) {
        // balls[i].obj.visible = false;
    // }
}

function onRoll_over(e) {
    e.currentTarget.alpha = .5
    stage.update();
}

function onRoll_out(e) {
    e.currentTarget.alpha = 1
    stage.update();
}

function answerSelected(e) {
    e.preventDefault();
	 console.log("answer");
    uans = e.currentTarget.name;
    console.log("answer" + uans);
    console.log(ans + " =correct= " + uans)
    gameResponseTimerStop();
    if (ans == uans) {
        getValidation("correct");
        disablechoices();
    } else {
        getValidation("wrong");
        disablechoices();
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////