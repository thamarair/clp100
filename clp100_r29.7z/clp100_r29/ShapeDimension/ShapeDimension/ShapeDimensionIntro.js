var introArrow, introfingure, introTitle, introHolder, introQues;
var introChoiceArr = [];
var introChoiceArr1 = [];
var highlightTweenArr = []
var setIntroCnt = 0;
var removeIntraval = 0, introCount = -1;
var introArrowX = 132, introArrowY = 260;
var introfingureX = 210, introfingureY = 400;
var introQuesArr = [];
var introChoiceArr = [];
var introArr = [];
var introArr1 = [];
var introbtnX = [750, 750, 750];
var introbtnY = [330, 430, 530];
var introbtnX1 = [100, 1051];
var introbtnY1 = [400, 400];
var introTempVal = 0;
function commongameintro() {
    introTempVal = 0;
    introTitle = Title.clone();
    introArrow = arrow1.clone();
    introfingure = fingure.clone();
    introquestionText = questionText.clone();
    introQues = question.clone();
    introHolder = chHolder.clone();
    container.parent.addChild(introTitle)
    introTitle.visible = true;

    container.parent.addChild(introquestionText);
    introquestionText.visible = false;

    container.parent.addChild(introHolder);
    introHolder.visible = false;

    container.parent.addChild(introQues);
    introQues.gotoAndStop(2);
    introQues.visible = false;
    introQues.x = 350;
    introQues.y = 330;

    for (i = 0; i < 3; i++) {
        introQuesArr[i] = this["question" + (i + 1)].clone();
        container.parent.addChild(introQuesArr[i])
        introQuesArr[i].visible = false;
        introQuesArr[i].x = introbtnX[i];
        introQuesArr[i].y = introbtnY[i];
        introQuesArr[i].gotoAndStop(2);
    }



    for (i = 0; i < 2; i++) {
        introChoiceArr[i] = choice1.clone()
        container.parent.addChild(introChoiceArr[i])
        introChoiceArr[i].visible = false;
        introChoiceArr[i].x = introbtnX1[i];
        introChoiceArr[i].y = introbtnY1[i];
        introChoiceArr[i].gotoAndStop(i);
    }

    for (i = 0; i < 3; i++) {
        introArr[i] = introImg.clone();
        container.parent.addChild(introArr[i])
        introArr[i].visible = false;
        introArr[i].x = introbtnX[i] - 3;
        introArr[i].y = introbtnY[i] - 4;
        introArr[i].gotoAndStop(i);
    }

    for (i = 0; i < 13; i++) {
        introArr1[i] = introImg1.clone()
        container.parent.addChild(introArr1[i])
        introArr1[i].visible = false;
        introArr1[i].gotoAndStop(i);
        introArr1[i].x = 350;
        introArr1[i].y = 331;
    }

    introquestionText.alpha = 0;
    introquestionText.visible = true
    createjs.Tween.get(introquestionText).to({ alpha: 1 }, 1000).call(handleComplete1_1);
}
function handleComplete1_1() {
    createjs.Tween.removeAllTweens();
    quesTween()
}

function quesTween() {
    createjs.Tween.get(introHolder).wait(100).to({ visible: true }, 200, createjs.Ease.bounceOut);

    introQues.visible = true;
    introQues.y = -500;
    createjs.Tween.get(introQues).wait(200).to({ y: 330 }, 400, createjs.Ease.bounceOut);


    for (i = 0; i < 3; i++) {
        introQuesArr[i].visible = true;
        introQuesArr[i].y = 800;
        if (i == 2) {
            createjs.Tween.get(introQuesArr[i]).wait(400).to({ y: introbtnY[i] }, 200).wait(100).call(handleComplete2_1);
        } else {
            createjs.Tween.get(introQuesArr[i]).wait(400).to({ y: introbtnY[i] }, 200);

        }
    }

}
function handleComplete2_1() {
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        createjs.Tween.removeAllTweens();
        choiceTween()
    }
}


function choiceTween() {

    for (i = 0; i < 2; i++) {
        if (i == 1) {
            createjs.Tween.get(introChoiceArr[i]).wait(500).to({ visible: true }, 200, createjs.Ease.bounceOut).wait(1000)
                .call(handleComplete3_1)
        } else {
            createjs.Tween.get(introChoiceArr[i]).wait(500).to({ visible: true }, 200, createjs.Ease.bounceOut);
        }

    }
}

function handleComplete3_1() {

    if (stopValue == 0) {
        removeGameIntro()

    }
    else {
        createjs.Tween.removeAllTweens();


        if (introTempVal == 1) {
            choiceTween2();
        } else {
            choiceTween1();
        }
        // setArrowTween();
    }
}

function choiceTween1() {

    introArr[0].visible = true;

    introTempVal++;
    var introVal = 500
    for (i = 0; i < 8; i++) {

        // introQues.visible = false;
        introArr1[i].visible = true;
        introArr1[i].alpha = 0;

        if (i == 7) {
            createjs.Tween.get(introArr1[i]).wait(introVal)
                .to({ visible: true, alpha: 1 }, 500).wait(1000)
                .call(handleComplete3_1);
        }
        else {
            createjs.Tween.get(introArr1[i]).wait(introVal)
                .to({ visible: true, alpha: 1 }, 500)
        }
        introVal = introVal + 1000;
    }

}



function choiceTween2() {
    
    introArr[0].visible = false;
    introArr[1].visible = true;

    for (i = 0; i < 8; i++) {
        introArr1[i].visible = false;
    }
    var introVal1 = 1000
    for (i = 8; i < 11; i++) {
        introArr1[i].visible = true;
        introArr1[i].alpha = 0;

        if (i == 10) {
            createjs.Tween.get(introArr1[i]).wait(introVal1)
                .to({ visible: true, alpha: 1 }, 500).wait(1500)
                .call(handleComplete4_1);
        }
        else {
            createjs.Tween.get(introArr1[i]).wait(introVal1)
                .to({ visible: true, alpha: 1 }, 500)
        }
        introVal1 = introVal1 + 1000;
    }

}
function handleComplete4_1() {
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        createjs.Tween.removeAllTweens();
        choiceTween3();
    }
}

function choiceTween3(){
    introArr[1].visible = false;
    introArr[2].visible = true;

    for (i = 8; i < 11; i++) {
        introArr1[i].visible = false;
    }
    var introVal2 = 500;
    for (i = 11; i < 13; i++) {
        introArr1[i].visible = true;
        introArr1[i].alpha = 0;

        if (i == 12) {
            createjs.Tween.get(introArr1[i]).wait(introVal2)
                .to({ visible: true, alpha: 1 }, 500).wait(1000)
                .call(handleComplete5_1);
        }
        else {
            createjs.Tween.get(introArr1[i]).wait(introVal2)
                .to({ visible: true, alpha: 1 }, 500)
        }
        introVal2 = introVal2 + 1000;
    }

}
function handleComplete5_1() {

    if (stopValue == 0) {
        removeGameIntro()

    }
    else {
        createjs.Tween.removeAllTweens();

        setArrowTween();
    }
}
function setArrowTween() {
    if (stopValue == 0) {
        removeGameIntro()

    }
    else {
        container.parent.addChild(introArrow); 
        introArrow.visible = true;
        introArrow.x = introArrowX;
        introArrow.y = introArrowY;
        highlightTweenArr[0] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[0])

        highlightTweenArr[0] = createjs.Tween.get(introArrow).to({ y: introArrowY + 10 }, 350).to({ y: introArrowY }, 350).to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350)
            .to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350)
            .wait(400)
            .call(this.onComplete1)


    }
}

function setFingureTween() {
    if (stopValue == 0) {
        console.log("setFingureTween  == stopValue")
        removeGameIntro()

    }
    else {

        container.parent.removeChild(introArrow);
        introArrow.visible = false;
        container.parent.addChild(introfingure);
        introfingure.visible = true; 
        introfingure.x = introfingureX;
        introfingure.y = introfingureY;
        highlightTweenArr[1] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[1])
        highlightTweenArr[1] = createjs.Tween.get(introfingure)
            .to({ x: introfingureX }, 350)
            .to({ x: introfingureX - 15 }, 350)
            .to({ x: introfingureX }, 350)
            .to({ x: introfingureX - 15 }, 350)
            .wait(200)
            .call(this.onComplete2)
        //setTimeout(ansTween, 400)
    }
}

this.onComplete1 = function (e) {
    createjs.Tween.removeAllTweens();
    // for (i = 0; i < 2; i++) {
    if (highlightTweenArr[0]) {
        console.log("onComplete1")
        container.parent.removeChild(highlightTweenArr[0]);
    }
    // }
    container.parent.removeChild(introArrow);
    if (stopValue == 0) {
        console.log("onComplete1  == stopValue")
        removeGameIntro()

    } else {
        setTimeout(setFingureTween, 200)
    }
}

this.onComplete2 = function (e) {
    createjs.Tween.removeAllTweens();


    container.parent.removeChild(introfingure);
    introfingure.visible = false;

    if (stopValue == 0) {
        console.log("onComplete2  == stopValue")
        removeGameIntro()

    }
    else {
        console.log("///setcallDelat=====+");
        setTimeout(setCallDelay, 500)
    }

}

function setCallDelay() {
    clearInterval(removeIntraval)
    removeIntraval = 0
    setIntroCnt++
    removeGameIntro()
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        commongameintro()
        if (setIntroCnt > 0) {
            isVisibleStartBtn()
        }
    }

}
function removeGameIntro() {
    // createjs.Tween.removeAllTweens();
    container.parent.removeChild(introArrow);
    introArrow.visible = false;
    container.parent.removeChild(introfingure);
    introfingure.visible = false;
    // container.parent.removeChild(introTitle);
    // introTitle.visible = false;
    container.parent.removeChild(introquestionText);
    introquestionText.visible = false;

    container.parent.removeChild(introQues);
    introQues.visible = false;

    container.parent.removeChild(introHolder);
    introHolder.visible = false;


    for (i = 0; i < 3; i++) {
        container.parent.removeChild(introQuesArr[i])
        introQuesArr[i].visible = false;
    }



    for (i = 0; i < 2; i++) {
        container.parent.removeChild(introChoiceArr[i])
        introChoiceArr[i].visible = false;
    }


    for (i = 0; i < 3; i++) {
        container.parent.removeChild(introArr[i])
        introArr[i].visible = false;
    }

    for (i = 0; i < 13; i++) {
        container.parent.removeChild(introArr1[i])
        introArr1[i].visible = false;
    }

    if (highlightTweenArr[0]) {
        highlightTweenArr[0].setPaused(false);
        container.parent.removeChild(highlightTweenArr[0]);
    }
    if (highlightTweenArr[1]) {
        highlightTweenArr[1].setPaused(false);
        container.parent.removeChild(highlightTweenArr[1]);
    }
}