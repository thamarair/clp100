var introArrow, introquestionText, introfingure, introTitle, Title;
var introChoiceArr = []
var highlightTweenArr = []
var setIntroCnt = 0
var removeIntraval = 0
var introChoiceX = [, 180, 870, 525];
var introChoiceY = [, 210, 210, 440];
var introQuestxtX = 636; introQuestxtY = 120;
var introHintImgX = 425, introHintImgY = 200
var introquestionX = 450; introquestionY = 240;
var introArrowX = 410, introArrowY = 475;
var introfingureX = 435, introfingureY = 580;
var introChoiceArrX = [160, 330, 520, 712, 897, 1090]
var introBall = new Array(7);
var introRadiusArray = [18, 16, 14, 22, 30, 20];
var introsX = [250, 400, 600, 340, 700, 820];
var introsY = [280, 240, 220, 270, 300, 330];
var introrandomnum = [3, 0, 2, 4, 1, 5, 6];
function commongameintro() {
    TempIntroVal = -1;
    introTitle = Title.clone()
    introArrow = arrow1.clone()
    introfingure = fingure.clone()

    introquestionText = questionText.clone()
    for (i = 0; i < 5; i++) {
        introChoiceArr[i] = choice1.clone();
    }
    container.parent.addChild(introTitle)
    introTitle.visible = true;

    container.parent.addChild(introquestionText);
    introquestionText.visible = true
    introRand = [5, 2, 20, 8, 3, 6, 16]
    for (i = 0; i < 6; i++) {
        introBall[i] = new introballs(i);
        introBall[i].obj = choice1.clone();
        introBall[i].obj.gotoAndStop(introRand[i]);
        container.parent.addChild(introBall[i].obj)
        introBall[i].obj.visible = false;
        introBall[i].obj.x = introBall[i].x
        introBall[i].obj.y = introBall[i].y
        introBall[i].obj.scaleX = introBall[i].obj.scaleY = .8
        introBall[i].obj.alpha = 1;
    }
    for (i = 0; i < 5; i++) {
        container.parent.addChild(introChoiceArr[i])
        introChoiceArr[i].visible = false;
        introChoiceArr[i].x = introChoiceArrX[i] + 85 //30 + (i * 120) //btnX[i]
        introChoiceArr[i].y = 580;
        introChoiceArr[i].scaleX = introChoiceArr[i].scaleY = .9
        introChoiceArr[i].gotoAndStop(introRand[i]);
    }
    introChoiceArr[1].gotoAndStop(1);
    introquestionText.alpha = 0;
    createjs.Tween.get(introquestionText).to({ alpha: 1 }, 1000).call(handleComplete1_1);

}

function handleComplete1_1() {
    createjs.Tween.removeAllTweens();
    quesTween()
}

function quesTween() {
    for (i = 0; i < 6; i++) {
        introBall[i].obj.visible = true;
    }
    for (i = 0; i < 5; i++) {
        introChoiceArr[i].alpha = 0
        if (i == 2) {
            createjs.Tween.get(introChoiceArr[i]).wait(1000).to({ x: introChoiceArr[i].x, y: introChoiceArr[i].y - 60, alpha: .5 }, 200).to({ x: introChoiceArr[i].x, y: introChoiceArr[i].y, alpha: 1 }, 200);
        } else if (i < 2) {
            createjs.Tween.get(introChoiceArr[i]).wait(1000).to({ x: introChoiceArr[i].x - 60, y: introChoiceArr[i].y - 60, alpha: .5 }, 200).to({ x: introChoiceArr[i].x, y: introChoiceArr[i].y, alpha: 1 }, 200);
        } else if (i == 4) {
            createjs.Tween.get(introChoiceArr[i]).wait(1000).to({ x: introChoiceArr[i].x + 60, y: introChoiceArr[i].y + 60, alpha: .5 }, 200).to({ x: introChoiceArr[i].x, y: introChoiceArr[i].y, alpha: 1 }, 200).wait(2000).call(handleComplete2_1);
        } else {
            createjs.Tween.get(introChoiceArr[i]).wait(1000).to({ x: introChoiceArr[i].x + 60, y: introChoiceArr[i].y + 60, alpha: .5 }, 200).to({ x: introChoiceArr[i].x, y: introChoiceArr[i].y, alpha: 1 }, 200);
        }
        introChoiceArr[i].visible = true
    }

    createjs.Ticker.addEventListener("tick", introcreateRandomBalls);
}
function introcreateRandomBalls() {
    for (i = 0; i < 6; i++) {
        var introballs = introBall[i];
        if (introballs.obj.x <= 230 ||
            introballs.obj.x >= (width - introballs.radius)) {
            introballs.dx *= -1;
        }
        if (introballs.obj.y <= 200 ||
            introballs.obj.y >= (height - introballs.radius)) {
            introballs.dy *= -1;
        }
        // move ball
        introballs.obj.x += introballs.dx;
        introballs.obj.y += introballs.dy;
    }
}
function introballs(introvals) {
    this.radius = introRadiusArray[introvals];
    this.x = introsX[introrandomnum[introvals]];
    this.y = introsY[introrandomnum[introvals]];

    // random direction, +1 or -1
    this.dx = Math.floor(Math.random() * 2) * 2 - 12;
    this.dy = Math.floor(Math.random() * 2) * 2 - 12;
}
function handleComplete2_1() {
    if (stopValue == 0) {
        removeGameIntro()
    } else {
        createjs.Tween.removeAllTweens();
        choiceTween()
    }
}
function choiceTween() {
    if (stopValue == 0) {
        removeGameIntro()
    } else {
        createjs.Ticker.removeEventListener("tick", introcreateRandomBalls);
        var introValX = [832, 400, 960, 630, 868, 510]
        var introValY = [440, 292, 390, 312, 204, 440]
        for (i = 0; i < 6; i++) {
            introBall[i].obj.x = introValX[i]
            introBall[i].obj.y = introValY[i]
        }

        createjs.Tween.get(introquestionText).to({ alpha: 1 }, 1000).wait(4000).call(handleComplete3_1);
    }


}

function handleComplete3_1() {
    if (stopValue == 0) {
        removeGameIntro()
    } else {
        createjs.Tween.removeAllTweens();
        setArrowTween()
    }
}
function setArrowTween() {
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        container.parent.addChild(introArrow); 
        introArrow.visible = true;
        introArrow.x = introArrowX;
        introArrow.y = introArrowY;
        highlightTweenArr[0] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[0])
        highlightTweenArr[0] = createjs.Tween.get(introArrow).to({ y: introArrowY + 10 }, 350).to({ y: introArrowY }, 350).to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350)
            .to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350)
            .wait(400)
            .call(this.onComplete1)
    }
}

function setFingureTween() {
    if (stopValue == 0) {
        console.log("setFingureTween  == stopValue")
        removeGameIntro()
    }
    else {

        container.parent.removeChild(introArrow);
        introArrow.visible = false;
        container.parent.addChild(introfingure);
        introfingure.visible = true; 
        introfingure.x = introfingureX;
        introfingure.y = introfingureY;
        highlightTweenArr[1] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[1])
        highlightTweenArr[1] = createjs.Tween.get(introfingure)
            .to({ x: introfingureX }, 350)
            .to({ x: introfingureX - 15 }, 350)
            .to({ x: introfingureX }, 350)
            .to({ x: introfingureX - 15 }, 350)
            .wait(200)
            .call(this.onComplete2)
        //setTimeout(setstarAnimation, 1000)
    }
}
this.onComplete1 = function (e) {
    createjs.Tween.removeAllTweens();
    // for (i = 0; i < 2; i++) {
    if (highlightTweenArr[0]) {
        console.log("onComplete1")
        container.parent.removeChild(highlightTweenArr[0]);
    }
    // }
    container.parent.removeChild(introArrow);
    if (stopValue == 0) {
        console.log("onComplete1  == stopValue")
        removeGameIntro()

    } else {
        setTimeout(setFingureTween, 200)
    }
}

this.onComplete2 = function (e) {
    createjs.Tween.removeAllTweens();


    container.parent.removeChild(introfingure);
    introfingure.visible = false;

    if (stopValue == 0) {
        console.log("onComplete2  == stopValue")
        removeGameIntro()

    }
    else {
        console.log("///setcallDelat=====+");
        setTimeout(setCallDelay, 500)
    }

}

function setCallDelay() {
    clearInterval(removeIntraval)
    removeIntraval = 0
    setIntroCnt++
    removeGameIntro()
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        commongameintro()
        if (setIntroCnt > 0) {
            isVisibleStartBtn()
        }
    }

}
function removeGameIntro() {
    createjs.Tween.removeAllTweens();
    // container.parent.removeChild(introTitle)
    // introTitle.visible = false;
    container.parent.removeChild(introArrow)
    introArrow.visible = false
    container.parent.removeChild(introfingure)
    introfingure.visible = false
    container.parent.removeChild(introquestionText)
    introquestionText.visible = false

    for (i = 0; i < 5; i++) {
        container.parent.removeChild(introChoiceArr[i])
        introChoiceArr[i].visible = false
    }
    for (i = 0; i < 6; i++) {
        container.parent.removeChild(introBall[i].obj)
        introBall[i].obj.visible = false
    }
}