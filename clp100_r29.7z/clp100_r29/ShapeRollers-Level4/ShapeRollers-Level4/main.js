
///////////////////////////////////////////////////-------Common variables--------------/////////////////////////////////////////////////////////////////////
var messageField;		//Message display field
var assets = [];
var cnt = -1, qscnt = -1, ans, uans, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, choiceCnt = 5, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;
var startBtn, introScrn, container, choice1, choice2, choice3, choice4, question, circleOutline, circle1Outline, boardMc, helpMc, quesMarkMc, questionText, quesHolderMc, resultLoading, preloadMc;
var mc, mc1, mc2, mc3, mc4, mc5, startMc, questionInterval = 0;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc, gameIntroAnimMc;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;
var bg
var BetterLuck, Excellent, Nice, Good, Super, TryAgain;
var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle,timeOver_Status=0;//for db //q
var isBgSound = true;
var isEffSound = true;

var url = "";
var nav = "";
var isResp = true;
var respDim = 'both'
var isScale = true
var scaleType = 1;

var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var loadProgressLabel, progresPrecentage, loaderWidth;
/////////////////////////////////////////////////////////////////////////GAME SPECIFIC VARIABLES//////////////////////////////////////////////////////////
var posx, posy;
var rand, clk
var removeIndex2, removeIndex1, removeIndex3
///////////////////////////////////////////////////////////////////////GAME SPECIFIC ARRAY//////////////////////////////////////////////////////////////
var qno = [];
var qnoI = [];
var choiceArr = []
var choiceArr = [];
var numBalls = 6;
var balls = new Array(numBalls);
var width = 1000;
var height = 470;
var btnX = [, 145, 330, 520, 712, 897, 1090]
//register key functions
window.onload = function (e) {
    checkBrowserSupport();
}
///////////////////////////////////////////////////////////////////
function init() {
    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);
    callLoader();
    createLoader()
    createCanvasResize()

    stage.update();
    stage.enableMouseOver(40);
    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////

    /*Always specify the following terms as given in manifest array. 
         1. choice image name as "ChoiceImages1.png"
         2. question text image name as "questiontext.png"
     */

    assetsPath = "assets/";
    gameAssetsPath = "ShapeRollers-Level4/";
    soundpath = "FA/"

    var success = createManifest();
    if (success == 1) {
        manifest.push(
            { id: "choice1", src: gameAssetsPath + "ChoiceImages1.png" },
            { id: "questionText", src: questionTextPath + "ShapeRollers-Level4-QT.png" }
        )
        preloadAllAssets()
        stage.update();
    }
}
//=====================================================================//
function doneLoading1(event) {
    var event = assets[i];
    var id = event.item.id;

    if (id == "choice1") {
        var spriteSheet3 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice1")],
            "frames": { "regX": 50, "height": 131, "count": 0, "regY": 50, "width": 147 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        //
        choice1 = new createjs.Sprite(spriteSheet3);
        container.parent.addChild(choice1);
        choice1.visible = false;
    }


    if (id == "questionText") {
        questionText = new createjs.Bitmap(preload.getResult('questionText'));
        container.parent.addChild(questionText);
        questionText.visible = false;
    }
}

function tick(e) {
    stage.update();
}

/////////////////////////////////////////////////////////////////=======GAME START========///////////////////////////////////////////////////////////////////
function handleClick(e) {
    qno = between(0, 100);
    CreateGameStart()
    if (gameType == 0) {
        CreateGameElements()
        getStartQuestion();
    } else {
        //for db
        getdomainpath()
        //end
    }
}

function CreateGameElements() {

    interval = setInterval(countTime, 1000);


    container.parent.addChild(questionText);
    questionText.visible = false;
    // questiontext.y=questiontext.y+10
    answerarr = between(0, 9);
    answerarr.sort(randomSort);

    for (i = 0; i < 6; i++) {
        choiceArr[i] = choice1.clone()
        container.parent.addChild(choiceArr[i])
        choiceArr[i].name = i;
        choiceArr[i].visible = false;
    }

    for (i = 0; i < 5; i++) {
        choiceArr[i] = choice1.clone()
        container.parent.addChild(choiceArr[i])  
        choiceArr[i].name = i;
        choiceArr[i].x = btnX[i + 1] + 95;
        choiceArr[i].y = 600;
        choiceArr[i].visible = false;
        choiceArr[i].scaleX=choiceArr[i].scaleY=.9
    }
    if (isQuestionAllVariations) {
        createGameWiseQuestions()
        // pickques()
    } else {
        // pickques()
    }

}

function helpDisable() {
    for (i = 0; i < 5; i++) {
        choiceArr[i].mouseEnabled = false;
    }
}

function helpEnable() {
    for (i = 0; i < 5; i++) {
        choiceArr[i].mouseEnabled = true;
    }
}

//=================================================================================================================================//
function pickques() {
    pauseTimer()
    //for db
    tx = 0;
    qscnt++;
    clk = 0;
    cnt++;
    quesCnt++;
    chpos = [];
    //db
    panelVisibleFn()
    qnoI = between(0, 23);  
    var qno1 = between(0, 5);
    radiusArray = [18, 16, 14, 22, 30, 20];
    sX = [250, 400, 600, 300, 700,820];
    sY = [280, 240, 220, 270, 300,330];
    randomnum = between(0, 5);
    radiusArray.sort(randomSort);
     balls = new Array(numBalls);
    //=================================================================================================================================//
    //question.gotoAndStop(ans);

    for (i = 0; i < 6; i++) {
        balls[i] = new Ball(i);
        balls[i].obj = choiceArr[i].clone();
        balls[i].obj.gotoAndStop(qnoI[i]);
        container.parent.addChild(balls[i].obj)
        balls[i].obj.visible = false;
        balls[i].obj.x = balls[i].x
        balls[i].obj.y = balls[i].y
        balls[i].obj.scaleX= balls[i].obj.scaleY=.8
        balls[i].obj.alpha = 1;
    }
    ans = qnoI[6];
    var qArray = [];
    qArray.push(qnoI[6], qnoI[qno1[0]], qnoI[qno1[1]], qnoI[qno1[2]], qnoI[qno1[3]])
    qArray.sort(randomSort);

    for (i = 0; i < 5; i++) {
        choiceArr[i].gotoAndStop(qArray[i]);
        choiceArr[i].name = qArray[i];
    }
    createTween();
}

function createRandomBalls() {
    for (i = 0; i < 6; i++) {
        var ball = balls[i];
        if (ball.obj.x <= 230 ||
            ball.obj.x >= (width - ball.radius)) {
            ball.dx *= -1;
        }
        if (ball.obj.y <= 200 ||
            ball.obj.y >= (height - ball.radius)) {
            ball.dy *= -1;
        }
        // move ball
        ball.obj.x += ball.dx;
        ball.obj.y += ball.dy;
    }
}
function Ball(vals) {
    this.radius = radiusArray[vals];
    this.x = sX[randomnum[vals]];
    this.y = sY[randomnum[vals]];

    this.dx = Math.floor(Math.random() * 2) * 2 - 12;
    this.dy = Math.floor(Math.random() * 2) * 2 - 12;
}
function createTween() {
    questionText.visible = true;
    questionText.alpha = 0
    createjs.Tween.get(questionText).wait(200).to({ alpha: 1 }, 200).call(createTween1);
}

function createTween1() {
    for (i = 0; i < 6; i++) {
        balls[i].obj.visible = true;
    }
    for (i = 0; i < 5; i++) {
        choiceArr[i].alpha = 0
        if (i == 2) {
            createjs.Tween.get(choiceArr[i]).wait(500).to({ x: choiceArr[i].x, y: choiceArr[i].y - 60, alpha: .5 }, 200).to({ x: choiceArr[i].x, y: choiceArr[i].y, alpha: 1 }, 200);
        } else if (i < 2) {
            createjs.Tween.get(choiceArr[i]).wait(500).to({ x: choiceArr[i].x - 60, y: choiceArr[i].y - 60, alpha: .5 }, 200).to({ x: choiceArr[i].x, y: choiceArr[i].y, alpha: 1 }, 200);
        } else {
            createjs.Tween.get(choiceArr[i]).wait(500).to({ x: choiceArr[i].x + 60, y: choiceArr[i].y + 60, alpha: .5 }, 200).to({ x: choiceArr[i].x, y: choiceArr[i].y, alpha: 1 }, 200);
        }
        choiceArr[i].visible = true
    }
    createjs.Ticker.addEventListener("tick", createRandomBalls);
    repTimeClearInterval = setTimeout(AddListenerFn, 1800)
}

function AddListenerFn() {
    clearTimeout(repTimeClearInterval)
    for (i = 0; i < 5; i++) {
        choiceArr[i].addEventListener("click", answerSelected)
        choiceArr[i].cursor = "pointer";
        choiceArr[i].mouseEnabled = true
    }
    rst = 0;
    gameResponseTimerStart();
    restartTimer()
}
/*
function enablechoices() {
    for (i = 0; i < 5; i++) {
        choiceArr[i].addEventListener("click", answerSelected);
        choiceArr[i].mouseEnabled = true;
        choiceArr[i].visible = true;
        choiceArr[i].alpha = 1;
        choiceArr[i].cursor = "pointer";
    }
}
*/
function disablechoices() {
    for (i = 0; i < 5; i++) {
        choiceArr[i].removeEventListener("click", answerSelected);
        choiceArr[i].visible = false;
        choiceArr[i].alpha = .5;
    }
    for (i = 0; i < 6; i++) {
        balls[i].obj.visible = false;
    }
}

function onRoll_over(e) {
    e.currentTarget.alpha = .5;
    stage.update();
}

function onRoll_out(e) {
    e.currentTarget.alpha = 1;
    stage.update();
}

function answerSelected(e) {
    e.preventDefault();
    uans = e.currentTarget.name;
    console.log("answer" + uans);
    console.log(ans + " =correct= " + uans)
    gameResponseTimerStop();
    if (ans == uans) {
      
        e.currentTarget.visible = true;
        disableMouse()
        
        correct()
    } else {
        getValidation("wrong");
        disablechoices();
    }

}
function correct() {
    getValidation("correct");
    disablechoices();
}


function disableMouse() {

    for (i = 0; i < 5; i++) {
        choiceArr[i].mouseEnabled = false
    }
}
function enableMouse() {
}