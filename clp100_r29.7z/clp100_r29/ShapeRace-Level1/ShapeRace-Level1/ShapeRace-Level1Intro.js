//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var highlightTweenArr = []
var setIntroCnt = 0
var removeIntraval = 0
var introTitle
var introQuesText
var introchHolder; //introqhHolder;
var introChoice = [];
var qscnt = -1;
var introQues;
// var ArrowXArr = [,1180,820,280], ArrowYArr = [,230,230,230]
// var FingXArr = [,1185,840,300], FingYArr = [,390,390,390]

var introArrowX = 670, introArrowY = 230;
var introfingureX = 700, introfingureY = 400;
var TempIntroVal = 0;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function commongameintro() {
    // ///////////////////////////////////////Title//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    introTitle = Title.clone();
    container.parent.addChild(introTitle);
    introTitle.visible = true;
    // //////////////////////////////////////////////////////////Arrow and Fingure////////////////////////////////////////////////////////////////////////////////////
    introArrow = arrow1.clone();
    container.parent.addChild(introArrow);
    introfingure = fingure.clone();
    container.parent.addChild(introfingure);

    // // //////////////////////////////////////////////Question Text/////////////////////////////////////////////////////////////////////////////////////////////////////////
   
	if(lang == "EnglishQuestionText/")
	{	
	  introQuesText = new createjs.Text("Select the hexagon that passes through", "40px lato-Bold", "white");
      container.parent.addChild(introQuesText);	  
    }
    else if(lang == "TamilQuestionText/")
	{		
	  introQuesText = new createjs.Text("கடந்து செல்லும் அறுங்கோணம் தேர்ந்தெடுக்கவும்", "30px lato-Bold", "white");
      container.parent.addChild(introQuesText);	  
	}
	else if(lang == "HindiQuestionText/")
	{
		
		  introQuesText = new createjs.Text("उस  षट्भुज  का चयन करें जो कि उन मे से गुजरता है", "40px lato-Bold", "white");
		  container.parent.addChild(introQuesText);
	}
	
	else if(lang == "GujaratiQuestionText/")
	{
		
		  introQuesText = new createjs.Text("પસાર થતાં  ષટ્કોણ  ને પસંદ કરો", "40px lato-Bold", "white");
		  container.parent.addChild(introQuesText);
	} 
		else if(lang == "ArabicQuestionText/")
	{
		
		  introQuesText = new createjs.Text("حدد شكل سداس الذي يمر عبر", "40px lato-Bold", "white");
		  container.parent.addChild(introQuesText);
	} 
	
    introQuesText.x = 630; introQuesText.y = 100;
    introQuesText.textAlign = "center";
    introQuesText.lineWidth = 600
    introQuesText.lineHeight = 50
    introQuesText.textBaseline = "middle";
	
    // // //////////////////////////////////////////////introchHolder/////////////////////////////////////////////////////////////////////////////////////////////////////////
    introchHolder = chHolder.clone();
    container.parent.addChild(introchHolder);
    introchHolder.visible = false;


    // //////////////////////////////////////////Question1/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    for (i = 0; i <= 5; i++) {
        introChoice[i] = choice1.clone()
        container.parent.addChild(introChoice[i])
        introChoice[i].visible = false;
        introChoice[i].x = -50 + (i * 190);
        introChoice[i].scaleX = introChoice[i].scaleY = 0.7
        introChoice[i].y = 340
        if (i == 3) {
            introChoice[i].gotoAndStop(0);
        }
        else {

            introChoice[i].gotoAndStop(i + 1);
        }
    }

    for (i = 6; i < 10; i++) {
        introChoice[i] = choice1.clone()
        container.parent.addChild(introChoice[i])
        introChoice[i].visible = false;
        introChoice[i].x = -50 + (i * 190);
        introChoice[i].scaleX = introChoice[i].scaleY = 0.7
        introChoice[i].y = 340
        if (i == 8) {
            introChoice[i].gotoAndStop(5);
        }
        else {
            introChoice[i].gotoAndStop(i);
        }
    }
    createjs.Ticker.removeEventListener("tick", rollfn);
    // // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    introQuesText.alpha = 0
    introQuesText.x = -500
    createjs.Tween.get(introQuesText).to({ x: 630, visible: true, alpha: 1 }, 500).call(handleComplete1_0);


}
function rollfn() {

    for (i = 0; i < 10; i++) {
        introChoice[i].x = introChoice[i].x + 10;
        if (introChoice[i].x >= 1600) {
            introChoice[i].x = -400;
        }
    }

}
function handleComplete1_0() {
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        createjs.Tween.removeAllTweens()
        holderTween()
    }
}

function holderTween() {
    introchHolder.visible = true;
    introchHolder.x = -500
    introchHolder.alpha = 0

    createjs.Tween.get(introchHolder).to({ x: 0, alpha: 1 }, 250)
    // .call(handleComplete2_0)


    for (i = 0; i < 10; i++) {
        introChoice[i].visible = true
        introChoice[i].alpha = 0

        if (i == 9) {
            createjs.Tween.get(introChoice[i]).wait(500)
                .to({ alpha: 1, scaleX: 0.7, scaleY: 0.7 }, 100, createjs.Ease.bounceOut).wait(500).call(handleComplete2_0);

        }

        else {
            createjs.Tween.get(introChoice[i]).wait(500)
                .to({ alpha: 1, scaleX: 0.7, scaleY: 0.7 }, 100, createjs.Ease.bounceOut);

        }
    }

}

function handleComplete2_0() {
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        createjs.Tween.removeAllTweens()

        questionTween()
    }
}

function questionTween() {
    TempIntroVal = 0;
    createjs.Ticker.addEventListener("tick", rollfn);

    createjs.Tween.get(introChoice[9])
        .to({ alpha: 1, scaleX: 0.7, scaleY: 0.7 }, 100, createjs.Ease.bounceOut).wait(500).call(handleComplete3_0);
    

}


function handleComplete3_0() {

    createjs.Tween.removeAllTweens()
    createjs.Ticker.removeEventListener("tick", rollfn);
    answerTween();
}


function answerTween() {
    createjs.Tween.get(introChoice[3]).wait(200)
        .to({ scaleX: .65, scaleY: .65 }, 200)
        .to({ scaleX: .7, scaleY: .7 }, 200)
        .to({ scaleX: .65, scaleY: .65 }, 200)
        .to({ scaleX: .7, scaleY: .7 }, 200).call(handleComplete3_1);
}

function handleComplete3_1() {
    createjs.Tween.removeAllTweens();
    setArrowTween()
}
function setArrowTween() {
    if (stopValue == 0) {
        console.log("setArrowTween  == stopValue")
        removeGameIntro()
    }
    else {
        container.parent.addChild(introArrow);
        introArrow.visible = true;
        introArrow.x = introArrowX;
        introArrow.y = introArrowY;
        highlightTweenArr[0] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[0])
        highlightTweenArr[0] = createjs.Tween.get(introArrow)
            .to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350)
            .to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350)
            .to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350)
            .wait(400)
            .call(this.onComplete1)

    }

}

function setFingureTween() {
    if (stopValue == 0) {
        console.log("setFingureTween  == stopValue")
        removeGameIntro()

    }
    else {

        container.parent.removeChild(introArrow);
        introArrow.visible = false;
        container.parent.addChild(introfingure);
        introfingure.visible = true;
        introfingure.x = introfingureX;
        introfingure.y = introfingureY;
        highlightTweenArr[1] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[1])
        highlightTweenArr[1] = createjs.Tween.get(introfingure)
            .to({ x: introfingureX }, 350)
            .to({ x: introfingureX - 15 }, 350)
            .to({ x: introfingureX }, 350)
            .to({ x: introfingureX - 15 }, 350)
            .wait(200)
            .call(this.onComplete2)

    }
}
this.onComplete1 = function (e) {
    createjs.Tween.removeAllTweens();

    if (highlightTweenArr[0]) {
        console.log("onComplete1")
        container.parent.removeChild(highlightTweenArr[0]);
    }

    container.parent.removeChild(introArrow);
    if (stopValue == 0) {
        console.log("onComplete1  == stopValue")
        removeGameIntro()

    } else {
        setTimeout(setFingureTween, 200)
    }
}

this.onComplete2 = function (e) {
    createjs.Tween.removeAllTweens();
    if (highlightTweenArr[1]) {
        console.log("onComplete2")
        container.parent.removeChild(highlightTweenArr[1]);
    }
    container.parent.removeChild(introfingure);
    introfingure.visible = false;
    if (stopValue == 0) {
        console.log("onComplete2  == stopValue")
        removeGameIntro()
    }
    else {
        setTimeout(setCallDelay, 500)
    }


}

function setCallDelay() {

    createjs.Tween.removeAllTweens();

    clearInterval(removeIntraval)
    removeIntraval = 0
    setIntroCnt++
    console.log("check cnt = " + setIntroCnt)
    removeGameIntro()
    if (stopValue == 0) {
        console.log("setCallDelay  == stopValue")
        removeGameIntro()
    }
    else {
        commongameintro()
        if (setIntroCnt > 0) {
            isVisibleStartBtn()
        }
    }

}
function removeGameIntro() {

    createjs.Tween.removeAllTweens();
    container.parent.removeChild(introArrow)
    introArrow.visible = false
    container.parent.removeChild(introfingure)
    introfingure.visible = false
    // container.parent.removeChild(introTitle)
    // introTitle.visible = false
    container.parent.removeChild(introchHolder)
    introchHolder.visible = false

    for (i = 0; i < 10; i++) {
        container.parent.removeChild(introChoice[i])
        introChoice[i].visible = false
    }
    createjs.Ticker.removeEventListener("tick", rollfn);

    container.parent.removeChild(introQuesText)
    introQuesText.visible = false

    if (highlightTweenArr[0]) {
        highlightTweenArr[0].setPaused(false);
        container.parent.removeChild(highlightTweenArr[0]);
    }
    if (highlightTweenArr[1]) {
        highlightTweenArr[1].setPaused(false);
        container.parent.removeChild(highlightTweenArr[1]);
    }

}