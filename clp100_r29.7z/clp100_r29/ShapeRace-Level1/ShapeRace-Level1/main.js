///////////////////////////////////////////////////-------Common variables--------------/////////////////////////////////////////////////////////////////////
var messageField;		//Message display field
var assets = [];
var cnt = -1, ans, uans, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, qchoiceCnt = 10, choiceCnt = 20, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;
var startBtn, introScrn, container, choice1, choice2, choice3, choice4, question, circleOutline, circle1Outline, boardMc, helpMc, quesMarkMc, questionText, quesHolderMc, resultLoading, preloadMc;
var mc, mc1, mc2, mc3, mc4, mc5, startMc, questionInterval = 0;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc, gameIntroAnimMc;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;
var bg
var BetterLuck, Excellent, Nice, Good, Super, TryAgain;
var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle, timeOver_Status = 0;
var isBgSound = true;
var isEffSound = true;
var url = "";
var nav = "";
var isResp = true;
var respDim = 'both'
var isScale = true
var scaleType = 1;
var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var loadProgressLabel, progresPrecentage, loaderWidth;
var rand = []
var rand1 = []
var shape_arr = ["hexagon", "square", "circle", "pentagon", "star", "triangle", "diamond", "oval", "semicircle", "rectangle"];
var shape1_arr=["षट्भुज", "वर्गाकार", "वृत्त", "पंचकोण", "तारा", "त्रिकोण", "हीरा", "अंडाकार", "अर्धवृत्त", "आयत"];
var shape2_arr=["ષટ્કોણ", "ચોરસ", "વર્તુળ", "પંચકોણ", "તારો", "ત્રિકોણ", "હીરો", "અંડાકાર", "અર્ધવર્તુળ", "લંબચોરસ"];
var shape3_arr=["شكل سداسي", "مربع", "دائرة", "شكل خماسي", "نجمة","مثلث", "معيّن", "شكل بيضاوي","نصف دائرة", "مستطيل"];
var shape4_arr=["அறுங்கோணம்", "சதுரம்", "வட்டம்", "ஐங்கோணம்", "நட்சத்திரம்","முக்கோணம்", "வைரம்", "நீள் வட்டம்", "அரை வட்டம்","செவ்வகம்"];

/////////////////////////////////////////////////////////////////////////GAME SPECIFIC VARIABLES//////////////////////////////////////////////////////////
var tween
var question1
var currentX, currentY
var quesNo;
var mn = 0;
var currentObj = []
var currentObj1 = []
var animCnt
///////////////////////////////////////////////////////////////////////GAME SPECIFIC ARRAY//////////////////////////////////////////////////////////////
// var qno = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9];

var qno1 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
var choiceArr = [];
// var ansMc = []
var tweenMcArr1 = []
var tweenMcArr = [];
var choicePos = [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
var quesArr = []
var numArr = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
var qhHolder = []
//register key functions
var chX = [60, 270, 480, 690, 900, 1110];
//var chX = [1110,900,690,480,270,60];
///////////////////////////////////////////////////////////////////
window.onload = function (e) {
    checkBrowserSupport();
}
///////////////////////////////////////////////////////////////////
function init() {

    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);

    createLoader()
    createCanvasResize()

    stage.update();
    stage.enableMouseOver(40);
    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////

    /*Always specify the following terms as given in manifest array. 
         1. choice image name as "ChoiceImages1.png"
         2. question text image name as "questiontext.png"
     */

    assetsPath = "assets/";
    gameAssetsPath = "ShapeRace-Level1/";
    soundpath = "FA/"

    var success = createManifest();
    if (success == 1) {
        manifest.push(
            { id: "choice1", src: gameAssetsPath + "ChoiceImages1.png" },
            { id: "chHolder", src: gameAssetsPath + "chHolder.png" }
        )
        preloadAllAssets()
        stage.update();
    }
}
//=====================================================================//

function doneLoading1(event) {
    var event = assets[i];
    var id = event.item.id;
    console.log(" doneLoading ")
    loaderBar.visible = false;
    stage.update();


    if (id == "chHolder") {
        chHolder = new createjs.Bitmap(preload.getResult('chHolder'));
        container.parent.addChild(chHolder);
        chHolder.visible = false;
    }

    if (id == "choice1") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice1")],
            "frames": { "regX": 50, "height": 273, "count": 0, "regY": 50, "width": 274 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):

        });
        choice1 = new createjs.Sprite(spriteSheet1);
        choice1.visible = false;
        container.parent.addChild(choice1);

    };

}

function tick(e) {
    stage.update();
}

/////////////////////////////////////////////////////////////////=======GAME START========///////////////////////////////////////////////////////////////////

function handleClick(e) {
    qno = between(0, 9);;
    numArr = between(0, 9);
    CreateGameStart()
    if (gameType == 0) {
        CreateGameElements();
        getStartQuestion();
    }
    else {
        //for db
        getdomainpath();
        //end
    }
}

function CreateGameElements() {

    interval = setInterval(countTime, 1000);


    container.parent.addChild(chHolder);
    chHolder.visible = false;

    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i] = choice1.clone()
        container.parent.addChild(choiceArr[i])
        choiceArr[i].visible = false;
        if (i < 6) {
            choiceArr[i].x = chX[i];
        }
        else if (i < 12) {
            choiceArr[i].x = chX[i - 6];
        }
        else if (i < 18) {
            choiceArr[i].x = chX[i - 12];
        }
        else if (i < 24) {
            choiceArr[i].x = chX[i - 18];
        }
        else {
            choiceArr[i].x = chX[i - 18];
        }
        choiceArr[i].x = 60 + (210 * i)
        choiceArr[i].y = 320;

        choiceArr[i].name = i;
        choiceArr[i].scaleX = choiceArr[i].scaleY = .7;
        console.log(choiceArr[i].x);

    }
    qText = new createjs.Text("heloooooooooooooo", "40px Lato-bold", "white");
    qText.x = 630;
    qText.y = 100;
    qText.lineWidth = 600;
    qText.textAlign = "center";
    container.parent.addChild(qText);
    qText.visible = false;

    for (i = 0; i < 10; i++) {
        qno1.push(numArr[cnt]);
    }
    for (i = 0; i < 10; i++) {
        if (i < 3) {
            qno1.push(numArr[i + 1]);
        }
        else if (i < 6) {
            qno1.push(numArr[i + 1 - 8]);
        }
        else {
            qno1.push(numArr[i + 1 - 14]);
        }
    }
    qno1.sort(randomSort);


    if (isQuestionAllVariations) {


    }
    else {

    }
}

function helpDisable() {
    for (i = 1; i <= 8; i++) {
        choiceArr[i].mouseEnabled = false;
    }
}

function helpEnable() {
    for (i = 1; i <= 8; i++) {
        choiceArr[i].mouseEnabled = true;
    }
}
//=================================================================================================================================//
function pickques() {
    animCnt = -1;
    num = 0;
    pauseTimer();
    tx = 0;
    cnt++;
    quesCnt++;
    qscnt++;
    chpos = [];
    attemptCnt = 0;
    currentObj = [];
    panelVisibleFn();
    chposArr = [];
    // numArr = between(0, 9);

    container.parent.addChild(qText);
    qText.visible = false;
	
	if(lang=="EnglishQuestionText/")
	{
		 qText.text = "Select the  " + shape_arr[numArr[cnt]] + "  that passes through";
    }
    else if(lang=="TamilQuestionText/")
    {
        qText = new createjs.Text(" கடந்து செல்லும் " + shape4_arr[numArr[cnt]] + " தேர்ந்தெடுக்கவும் ", "30px Lato-bold", "white");
        container.parent.addChild(qText);
        qText.x = 630;
        qText.y = 100;
        qText.lineWidth = 600;
        qText.textAlign = "center";
        container.parent.addChild(qText);
        
          
    }
	else if(lang == "HindiQuestionText/")
	{
		qText.text = "उस  " + shape1_arr[numArr[cnt]] + "   का चयन करें जो कि उन मे से गुजरता है";
	}
	else if(lang=="GujaratiQuestionText/")
	{
		qText.text = "પસાર થતાં  "  +shape2_arr[numArr[cnt]]+"  ને પસંદ કરો";
	}
	else if(lang=="ArabicQuestionText/")
	{
		qText.text = "حدد "  +shape3_arr[numArr[cnt]]+" الذي يمر عبر";
	}
	
    ans = numArr[cnt];
    console.log("ans=" + ans)
    qText.visible = false;
  
    qno1.sort(randomSort);
    console.log("qno1" + qno1)

    if (qno1.indexOf(ans) !== -1) {
        console.log("Value exists!")
    } else {
        console.log("Value does not exists!")
        qno1[8] = ans;
    }
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].gotoAndStop(qno1[i]);
        choiceArr[i].name = qno1[i];
        choiceArr[i].visible = false;
    }

    createTween();
    enablechoices()
    createjs.Ticker.addEventListener("tick", animFn);
    stage.update();
}

function createTween() {

    qText.visible = true;
    qText.alpha = 0;
    qText.x = -500

    chHolder.visible = true;
    chHolder.alpha = 0;
    chHolder.x = -500
    createjs.Tween.get(qText).to({ x: 630, alpha: 1 }, 500);
    createjs.Tween.get(chHolder).to({ x: 0, alpha: 1 }, 500);

    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].visible = false
        choiceArr[i].alpha = 0
        createjs.Tween.get(choiceArr[i]).wait(600)
            .to({ alpha: 1 }, 500, createjs.Ease.bounceOut);
    }
    repTimeClearInterval = setTimeout(AddListenerFn, 1500)
}

function AddListenerFn() {
    clearTimeout(repTimeClearInterval)
    console.log("eventlisterneer")
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].addEventListener("click", answerSelected);
        choiceArr[i].mouseEnabled = true
        choiceArr[i].cursor = "pointer";
    }

    rst = 0;
    gameResponseTimerStart();
    restartTimer()
}


function animFn() {
    for (i = 0; i < choiceCnt; i++) {
        animCnt++;
        choiceArr[i].x = choiceArr[i].x + 15;
        if (choiceArr[i].x >= 4050) {
            choiceArr[i].x = -170;
        }
    }
}
function enablechoices() {
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].alpha = 1;
        choiceArr[i].mouseEnabled = true;
        choiceArr[i].visible = true;
        choiceArr[i].cursor = "pointer";
        choiceArr[i].addEventListener("click", answerSelected)
        choiceArr[i].id = i
    }

}

function disablechoices() {
        chHolder.visible = false;
        qText.visible = false;
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].mouseEnabled = false;
        choiceArr[i].visible = false;
        choiceArr[i].cursor = "default";
        choiceArr[i].removeEventListener("click", answerSelected)       
    }
}

function answerSelected(e) {
    e.preventDefault();
    uans = e.currentTarget.name;

    console.log(ans + " =correct= " + uans)
    gameResponseTimerStop();
    //pauseTimer();
    if (ans == uans) {
        e.currentTarget.removeEventListener("click", answerSelected)
        getValidation("correct");
        disablechoices();
    } else {
        getValidation("wrong");
        disablechoices();
    }
}

function disableMouse() {
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i].mouseEnabled = false
    }
}


function correct() {
    getValidation("correct");
    disablechoices();
}