(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.triangle6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#800000").s().p("AnfGfIHfs9IHgM9g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.triangle6, new cjs.Rectangle(-48,-41.5,96,83), null);


(lib.triangle4_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FFFF").s().p("AnfGfIHfs9IHgM9g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.triangle4_1, new cjs.Rectangle(-48,-41.5,96,83), null);


(lib.triangle3_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#800040").s().p("AnfGfIHfs9IHgM9g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.triangle3_1, new cjs.Rectangle(-48,-41.5,96,83), null);


(lib.triangle2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#800040").s().p("AnfGfIHfs9IHgM9g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.triangle2, new cjs.Rectangle(-48,-41.5,96,83), null);


(lib.triangle5_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().p("AnfGfIHfs9IHgM9g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.triangle5_1, new cjs.Rectangle(-48,-41.5,96,83), null);


(lib.triangle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AnfGfIHfs9IHgM9g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.triangle, new cjs.Rectangle(-48,-41.5,96,83), null);


(lib.square8_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FF00").s().p("AlHFIIAAqPIKPAAIAAKPg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.square8_2, new cjs.Rectangle(-32.7,-32.7,65.5,65.5), null);


(lib.square4_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FFFF").s().p("AlHFIIAAqPIKPAAIAAKPg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.square4_1, new cjs.Rectangle(-32.7,-32.7,65.5,65.5), null);


(lib.square3_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#800040").s().p("AlHFIIAAqPIKPAAIAAKPg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.square3_4, new cjs.Rectangle(-32.7,-32.7,65.5,65.5), null);


(lib.rectangle10_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0080").s().p("AnfFIIAAqPIO/AAIAAKPg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.rectangle10_3, new cjs.Rectangle(-48,-32.7,96.1,65.5), null);


(lib.rectangle6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#800000").s().p("AnfFIIAAqPIO/AAIAAKPg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.rectangle6, new cjs.Rectangle(-48,-32.7,96.1,65.5), null);


(lib.rectangle5_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().p("AnfFIIAAqPIO/AAIAAKPg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.rectangle5_4, new cjs.Rectangle(-48,-32.7,96.1,65.5), null);


(lib.rectangle4_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FFFF").s().p("AnfFIIAAqPIO/AAIAAKPg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.rectangle4_4, new cjs.Rectangle(-48,-32.7,96.1,65.5), null);


(lib.rectangle2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8000FF").s().p("AnfFIIAAqPIO/AAIAAKPg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.rectangle2, new cjs.Rectangle(-48,-32.7,96.1,65.5), null);


(lib.rectangle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AnfFIIAAqPIO/AAIAAKPg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.rectangle, new cjs.Rectangle(-48,-32.7,96.1,65.5), null);


(lib.pentagon9_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FFFF").s().p("AjtFoIiLm3IF7kYIF2EJIiHHGg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.pentagon9_1, new cjs.Rectangle(-37.7,-36,75.5,72), null);


(lib.pentagon8_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FF00").s().p("AjtFoIiLm3IF7kYIF2EJIiHHGg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.pentagon8_1, new cjs.Rectangle(-37.7,-36,75.5,72), null);


(lib.pentagon7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0080").s().p("AjtFoIiLm3IF7kYIF2EJIiHHGg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.pentagon7, new cjs.Rectangle(-37.7,-36,75.5,72), null);


(lib.pentagon2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0080").s().p("AjtFoIiLm3IF7kYIF2EJIiHHGg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.pentagon2, new cjs.Rectangle(-37.7,-36,75.5,72), null);


(lib.ovel_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666600").s().p("AldCxQiRhKAAhnQAAhmCRhKQCRhJDMAAQDNAACRBJQCRBKAABmQAABniRBKQiRBJjNAAQjMAAiRhJg");
	this.shape.setTransform(5,2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ovel_mc, new cjs.Rectangle(-44.5,-23,99,50), null);


(lib.octagon10_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0080").s().p("AiwGiIjxjrIAAljIDxj1IFhAAIDxD1IAAFjIjxDrg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.octagon10_3, new cjs.Rectangle(-41.7,-41.7,83.5,83.5), null);


(lib.octagon6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#800000").s().p("AiwGiIjxjrIAAljIDxj1IFhAAIDxD1IAAFjIjxDrg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.octagon6, new cjs.Rectangle(-41.7,-41.7,83.5,83.5), null);


(lib.hexagon10_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0080").s().p("AjxGkIjwmoIDwmfIHnAAIBHB5IAAAcIAPAAICWETIj6Gfg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.hexagon10_3, new cjs.Rectangle(-48.2,-42,96.5,84.1), null);


(lib.hexagon8_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FF00").s().p("AjxGkIjwmoIDwmfIHnAAIBHB5IAAAcIAPAAICWETIj6Gfg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.hexagon8_1, new cjs.Rectangle(-48.2,-42,96.5,84.1), null);


(lib.hexagon7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FF00").s().p("AjxGkIjwmoIDwmfIHnAAIBHB5IAAAcIAPAAICWETIj6Gfg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.hexagon7, new cjs.Rectangle(-48.2,-42,96.5,84.1), null);


(lib.hexagon2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FF00").s().p("AjxGkIjwmoIDwmfIHnAAIBHB5IAAAcIAPAAICWETIj6Gfg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.hexagon2, new cjs.Rectangle(-48.2,-42,96.5,84.1), null);


(lib.hexagon1_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FFFF").s().p("AjxGkIjwmoIDwmfIHnAAIBHB5IAAAcIAPAAICWETIj6Gfg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.hexagon1_4, new cjs.Rectangle(-48.2,-42,96.5,84.1), null);


(lib.heptagon9_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FFFF").s().p("AjAGkIjrkiIBVl7IFdiqIFaCqIBLFhIjnE8g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.heptagon9_1, new cjs.Rectangle(-42.7,-42,85.5,84), null);


(lib.heptagon7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#800040").s().p("AjAGkIjrkiIBVl7IFdiqIFaCqIBLFhIjnE8g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.heptagon7, new cjs.Rectangle(-42.7,-42,85.5,84), null);


(lib.heptagon6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#800000").s().p("AjAGkIjrkiIBVl7IFdiqIFaCqIBLFhIjnE8g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.heptagon6, new cjs.Rectangle(-42.7,-42,85.5,84), null);


(lib.heptagon5_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().p("AjAGkIjrkiIBVl7IFdiqIFaCqIBLFhIjnE8g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.heptagon5_1, new cjs.Rectangle(-42.7,-42,85.5,84), null);


(lib.heptagon3_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#800040").s().p("AjAGkIjrkiIBVl7IFdiqIFaCqIBLFhIjnE8g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.heptagon3_1, new cjs.Rectangle(-42.7,-42,85.5,84), null);


(lib.heptagon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AjAGkIjrkiIBVl7IFdiqIFaCqIBLFhIjnE8g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.heptagon, new cjs.Rectangle(-42.7,-42,85.5,84), null);


(lib.circle10_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0080").s().p("AkAEAQhqhqAAiWQAAiVBqhrQBrhqCVAAQCWAABqBqQBqBrABCVQgBCWhqBqQhqBqiWABQiVgBhrhqg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.circle10_1, new cjs.Rectangle(-36.2,-36.2,72.5,72.5), null);


(lib.circle9_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FFFF").s().p("AkAEAQhqhqAAiWQAAiVBqhrQBrhqCVAAQCWAABqBqQBqBrABCVQgBCWhqBqQhqBqiWABQiVgBhrhqg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.circle9_3, new cjs.Rectangle(-36.2,-36.2,72.5,72.5), null);


(lib.circle8_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FF00").s().p("AkAEAQhqhqAAiWQAAiVBqhrQBrhqCVAAQCWAABqBqQBqBrABCVQgBCWhqBqQhqBqiWABQiVgBhrhqg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.circle8_1, new cjs.Rectangle(-36.2,-36.2,72.5,72.5), null);


(lib.circle7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().p("AkAEAQhqhqAAiWQAAiVBqhrQBrhqCVAAQCWAABqBqQBqBrABCVQgBCWhqBqQhqBqiWABQiVgBhrhqg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.circle7, new cjs.Rectangle(-36.2,-36.2,72.5,72.5), null);


(lib.circle5_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().p("AkAEAQhqhqAAiWQAAiVBqhrQBrhqCVAAQCWAABqBqQBqBrABCVQgBCWhqBqQhqBqiWABQiVgBhrhqg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.circle5_4, new cjs.Rectangle(-36.2,-36.2,72.5,72.5), null);


(lib.circle3_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#800040").s().p("AkAEAQhqhqAAiWQAAiVBqhrQBrhqCVAAQCWAABqBqQBqBrABCVQgBCWhqBqQhqBqiWABQiVgBhrhqg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.circle3_4, new cjs.Rectangle(-36.2,-36.2,72.5,72.5), null);


(lib.circle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AkAEAQhqhqAAiWQAAiVBqhrQBrhqCVAAQCWAABqBqQBqBrABCVQgBCWhqBqQhqBqiWABQiVgBhrhqg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.circle, new cjs.Rectangle(-36.2,-36.2,72.5,72.5), null);


(lib.anim2_39 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 273
	this.instance = new lib.rectangle("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(14.2,31.7);
 

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[14.2,31.7,10,44.8,9.7,45.7,4.4,61.2,4.1,62,-0.1,71.8,-6.5,76.9,-14.7,83.4,-27.5,83.4,-42.3,83.4,-57.8,72.6,-73.8,61.4,-73.8,49.7,-73.8,45.1,-70.4,29.9,-68.8,22.2,-67.1,15.3,-67.1,4.5,-79.7,-0.3,-86.6,-2.8,-107.5,-5.7,-127.2,-8.3,-135.2,-12.1,-147.9,-18.1,-147.9,-30.8,-147.9,-39.2,-142.2,-49.2,-136.8,-58.6,-127.7,-67,-118.5,-75.5,-108.2,-80.6,-97.1,-85.9,-87.3,-85.9,-78.2,-85.9,-69.4,-81.3,-64.8,-78.9,-54.6,-71.1,-45,-63.9,-38.6,-61,-28.7,-56.4,-17.4,-56.4,-13.1,-56.4,-4.2,-60.4,0.7,-62.5,13.3,-69.1,37.8,-81.9,45.7,-81.9,59.9,-81.9,68.5,-72.4,76.6,-63.7,76.6,-51,76.6,-42.1,66.5,-29.1,60.3,-21.2,44.3,-5.1,27.9,11.1,22,18.5,17.3,24.4,14.8,29.4]}},79).wait(1));

	// Layer 272
	this.instance_1 = new lib.hexagon2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-74.4,16.2);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-74.3,16.3,-66.3,27.1,-59.3,32.7,-52.1,38.4,-44.1,44.3,-36,49.8,-23.9,62,-13.3,71.3,-1.9,71.3,13,71.3,20.9,62.7,27,56,27,47.1,27,40,23,34,20.2,29.9,14.1,24.8,6.8,18.6,5.2,16.9,1.2,12.4,1.2,7.8,1.2,1.4,10.8,-2.5,12.4,-3.2,31.9,-9,46.2,-13.3,53,-18.5,62.6,-26,62.6,-38.1,62.6,-50.2,49.2,-62.6,43.9,-67.5,38.3,-70.7,32.9,-73.7,30,-73.7,23.2,-73.7,14.8,-70.1,10.2,-68.1,-0.5,-62.1,-10.6,-56.4,-16.3,-54.1,-25.2,-50.4,-33,-50.4,-45.3,-50.4,-58.8,-58.4,-62.1,-60.4,-67.9,-63.9,-72.5,-66.4,-75.5,-66.4,-85,-66.4,-93.4,-57.8,-101.9,-49.1,-101.9,-38.7,-101.9,-28.6,-97.7,-20.5,-94.8,-14.9,-88.4,-8.2,-80.9,-0.3,-79.1,2.3,-75.3,7.9,-75,14.1]}},79).wait(1));

	// Layer 271
	this.instance_2 = new lib.ovel_mc();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-70.7,-57);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-70.6,-56.9,-70.3,-56.2,-70.6,-55,-71.2,-52.4,-71.6,-49.2,-72,-46.1,-72,-44.7,-72,-42,-66,-32.6,-59.9,-23.3,-59.9,-22.2,-59.9,-17.5,-66.8,-15.2,-70.9,-13.9,-81.9,-11.5,-91.9,-8.6,-97,-3.2,-103.9,4,-103.9,17.2,-103.9,29.4,-93.2,41,-88.8,45.7,-84,48.6,-79.2,51.5,-75.9,51.5,-68.4,51.5,-60.9,45.3,-56.4,41.7,-48,31.8,-39.7,21.9,-34.9,18.2,-27.2,12,-19.4,12,-15.4,12,2.4,22.2,20.3,32.5,25,32.5,42.6,32.5,52.9,23.3,62.8,14.4,62.8,0,62.8,-16.7,54.5,-23.1,48.9,-27.4,36.3,-28,29.7,-28.2,26.6,-28.5,21.3,-28.9,18.1,-30.1,9.8,-33.4,9.8,-44.7,9.8,-47.6,12.3,-60.5,14.7,-73.4,14.7,-78.3,14.7,-89.2,6.9,-95.9,-1.3,-103,-15.9,-103,-35.8,-103,-54.4,-89.6,-63.1,-83.4,-68.1,-75.9,-73.4,-68,-73.4,-60.2,-73.4,-60.2,-73.4,-60.2,-73.4,-59.2,-73,-58.5]}},79).wait(1));

	// Layer 270
	this.instance_3 = new lib.circle("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(16.1,-51);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[16.1,-50.9,24,-38.2,27.9,-31.6,31.4,-25.5,43.5,-7.7,53.4,6.9,57.6,15.4,63.7,27.9,63.7,38,63.7,56.6,27,74,13.6,80.3,-1,84.6,-14.1,88.6,-19.6,88.6,-30.6,88.6,-58.2,65.1,-65.1,59.3,-76.8,49,-85.4,41.7,-87.2,41.7,-96,41.7,-111,54.1,-114.7,57.2,-120.8,62.7,-125.4,66.5,-126.7,66.5,-135.9,66.5,-137.7,58.9,-138.3,56.4,-138.1,53.1,-137.7,49.8,-137.7,49.1,-137.7,31,-128,17,-117.8,2.5,-103.1,2.5,-94.6,2.5,-77.3,7.5,-60,12.3,-53.8,12.3,-43.1,12.3,-39.2,5,-36.8,0.4,-36.8,-8.4,-36.8,-21.4,-51.5,-33.5,-55.2,-36.7,-61.7,-41.4,-66.4,-45.2,-66.4,-47.6,-66.4,-57.4,-53.8,-63.6,-43.9,-68.5,-34.3,-68.5,-24.7,-68.5,-1.4,-59.1,5.4,-56.3,12.2,-53.4]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-122.6,-87.3,184.9,151.7);


(lib.anim2_38 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 265
	this.instance = new lib.square8_2("single",0);
	this.instance.parent = this;
	this.instance.setTransform(41.1,16);
 

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[41.1,16,38.1,21.8,34.2,24.9,30,28.1,27,35.1,23.4,42.2,18.6,45.7,5.4,55.3,-17.9,64.9,-39.5,73.8,-46.9,73.8,-52.5,73.8,-56.8,71,-62.8,67.1,-62.8,59.2,-62.8,56.7,-59.2,51,-57.7,48.5,-51.2,39.5,-39.7,23.2,-39.7,17.3,-39.7,9.5,-49.8,3.5,-55.6,0.1,-72.2,-5.8,-88.1,-11.5,-94.5,-15.6,-104.7,-22.1,-104.7,-30.9,-104.7,-38.2,-97.5,-45.5,-90.6,-52.7,-84.1,-52.7,-80.2,-52.7,-74.2,-49.6,-66.7,-45.2,-62.1,-42.8,-43.5,-32.9,-24.5,-32.9,-5.8,-32.9,17.6,-40.6,29.3,-44.4,38.4,-48.3,48.2,-48.3,53.2,-45.5,60.4,-41.7,60.4,-31.8,60.4,-23.1,51.3,-7.2,46.6,1,45.1,4.5,43.1,8.9,42.5,12.5]}},79).wait(1));

	// Layer 264
	this.instance_1 = new lib.octagon6("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-47.3,23.5);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-47.2,23.5,-42.9,24.5,-39.4,27.9,-33.1,34.2,-30.9,35.6,-26.3,38.4,-16.3,41.4,-6.2,44.4,-0.6,44.4,4.7,44.4,14,41.5,24.2,38.3,33.3,33.5,57.5,20.7,57.5,6,57.5,-10.3,34.7,-19.8,33.9,-20.1,16.9,-26,7.6,-29.4,4.8,-32.2,-2,-39.4,-6.9,-51.2,-9.7,-57.8,-14.3,-70.3,-18.6,-80.3,-25.1,-85,-33.3,-90.9,-47.4,-90.9,-69,-90.9,-80.7,-84.2,-91.6,-78.1,-91.6,-67.8,-91.6,-61,-88.2,-56.6,-86.2,-54.1,-80.6,-50.2,-75.2,-46.5,-73.1,-43.5,-69.7,-38.7,-69.7,-31.1,-69.7,-24.5,-72.2,-19.7,-73.9,-16.6,-77.7,-12.4,-82,-8.1,-83.4,-5.8,-85.9,-1.5,-85.9,4.1,-85.9,10.5,-80.9,13.6,-76.3,16.5,-66.1,17.3,-62,17.6,-56.5,20.1,-53.6,21.4,-51.6,22.3]}},79).wait(1));

	// Layer 263
	this.instance_2 = new lib.ovel_mc();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-43.5,-58.9);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-43.4,-58.8,-43.3,-58.8,-43.1,-58.8,-36,-58.8,-26.1,-62.9,-22.7,-64.3,-7.1,-72,5.5,-78.2,14.4,-81.1,27.1,-85.2,38.9,-85.2,48.5,-85.2,54.3,-82.2,60.5,-78.9,60.5,-73.4,60.5,-62.7,53.3,-53.3,48.5,-47,37.4,-38,25.2,-28.1,21.6,-24,14.4,-16,14.4,-7.9,14.4,1.1,21.8,6.8,25.9,10,38,15,49.6,19.7,54.3,23.7,61.7,30.2,61.7,40.3,61.7,49.4,53,59.8,44.9,69.6,39.2,69.6,31,69.6,22.4,64.4,17.6,61.5,7.7,53,-1.8,44.8,-7.5,41.6,-16.5,36.4,-25.5,36.4,-33.1,36.4,-42.9,40.7,-52.6,45,-58.9,45,-69.8,45,-82.9,37.6,-97.6,29.3,-97.6,19.4,-97.6,12,-89.6,6.8,-81.9,1.9,-71.2,1.9,-67.1,1.9,-59,2.8,-51,3.7,-47.8,3.7,-39.2,3.7,-34.9,1.9,-29.3,-0.5,-29.3,-6.1,-29.3,-13.6,-38.1,-20.5,-43.4,-24.6,-57.5,-31.8,-71.7,-39,-77,-43.1,-85.9,-50,-85.9,-57.6,-85.9,-63.7,-82.9,-66.3,-79.3,-69.3,-69.6,-69.3,-59.5,-69.3,-50.9,-64,-48.9,-62.7,-47,-61.1]}},79).wait(1));

	// Layer 262
	this.instance_3 = new lib.triangle();
	this.instance_3.parent = this;
	this.instance_3.setTransform(26.4,-53.9);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[26.4,-53.8,26.4,-53.8,26.4,-53.7,25.1,-47.3,25.1,-43.6,25.1,-34.8,31.5,-25.8,33.1,-23.7,45.6,-9.4,55.1,1.5,59.6,10.8,65.9,24,65.9,40,65.9,53.9,56.6,64.1,48.2,73.3,39,73.3,27.9,71.1,12.2,70.2,6.4,69.9,2.7,69.7,2.7,69.7,2.6,69.7,-4,70,-4.1,70,-17.5,72,-42.9,82.4,-61.4,89.9,-64.9,91.2,-75.6,95.2,-80.4,95.2,-100.6,95.2,-112.7,80.5,-123.8,66.8,-123.8,46.4,-123.8,30.4,-114.6,20.9,-108.2,14.3,-94.3,8.8,-86.9,6,-83.5,4.6,-77.5,2.3,-74.1,0.2,-64.8,-5.6,-64.8,-15.2,-64.8,-18.4,-72.1,-33.5,-79.4,-48.6,-79.4,-51,-79.4,-69,-53.6,-81.5,-40.7,-87.8,-27,-90.5,-20.4,-90.5,-10.2,-86.4,-0.2,-82.2,8.9,-75.9,18.7,-69,23.6,-62.2,24.6,-60.6,25.4,-59.2]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-89.1,-95.4,163.5,160.7);


(lib.anim2_37 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 257
	this.instance = new lib.pentagon2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(25.1,50.4);
 

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[25.1,50.4,25.3,52,25.6,54,26.3,59,26.3,60.7,26.3,72.5,19.1,80.7,11.5,89.3,0,89.3,-5.9,89.3,-14.7,82.7,-19.5,79.1,-21,78.2,-24.4,76.1,-26.9,76.1,-32.6,76.1,-37.8,78.7,-39.3,79.3,-46.9,84.2,-59.8,92.4,-76.2,92.4,-88.2,92.4,-95.2,86.5,-102.4,80.3,-102.4,69.6,-102.4,63.3,-96.7,59.3,-92.8,56.5,-84.1,53.9,-73.7,50.8,-71.5,49.8,-65.8,47.1,-65.8,43.1,-65.8,32.1,-75.7,24.5,-81.9,19.8,-97.4,13.7,-113.5,7.3,-119.1,3.4,-128.9,-3.3,-128.9,-13.1,-128.9,-22.7,-123.4,-26.7,-119.6,-29.4,-109.8,-30.8,-97.5,-32.6,-93,-34.1,-83.2,-37.4,-77.4,-45.2,-73.9,-49.9,-67.8,-60.3,-61.8,-70.4,-58.3,-75,-46.2,-90.7,-28.3,-90.7,-22.9,-90.7,-18.4,-85.9,-16.6,-84.1,-10.4,-74.9,-5,-67,0.1,-62.6,7.5,-56.3,17.6,-54.1,42.9,-48.4,58.5,-39.2,79,-27.1,79,-10.8,79,-4.9,70.3,4.3,65.3,9.7,50.9,22.4,36.5,34.9,30.5,41.5,28.3,43.9,26.5,46.1]}},79).wait(1));

	// Layer 256
	this.instance_1 = new lib.rectangle("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-89.3,45.8);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-89.2,45.8,-95.7,51.4,-92.7,60.5,-88.8,72.1,-80.4,81.7,-59.1,105.9,-21.8,105.9,-14.7,105.9,-7.2,93.9,0,82.1,0,71.9,0,65.8,-4.3,59.6,-7.2,55.6,-13.9,49.2,-21.1,42.3,-23.4,39.4,-27.8,33.9,-27.8,29.1,-27.8,21.7,-23,17,-18.2,12.2,-10.3,12.2,-5.2,12.2,1.8,20.2,4.8,23.7,14.9,37.8,23.5,49.9,29.2,55.3,37.6,63.3,45,63.3,50.8,63.3,59.7,45,68.1,27.8,68.1,20.7,68.1,11.6,60.5,7.1,55,3.9,43.8,2.5,31.7,1.4,27.1,0.5,23.3,-0.2,21.4,-1.5,19.5,-2.8,19.5,-4.7,19.5,-7.5,26.2,-12.5,30.2,-15.5,40.8,-22.9,62.1,-38.8,62.1,-53.4,62.1,-60.1,57.8,-67.7,53.5,-75.1,46.2,-81.5,29.6,-96,10.2,-96,-3.9,-96,-12.1,-90,-20.6,-83.7,-20.6,-72.3,-20.6,-71.5,-17.6,-57.8,-14.5,-44.2,-14.5,-40.7,-14.5,-29.9,-23,-24.2,-30.5,-19.4,-41.9,-19.4,-48.3,-19.4,-52.4,-25.8,-54.9,-29.7,-59.3,-40.1,-63.9,-49.6,-70.2,-54.3,-78.9,-60.8,-93.1,-60.8,-98.9,-60.8,-103.4,-55.9,-108.2,-50.6,-108.2,-42.5,-108.2,-36.1,-104.1,-25.8,-101.7,-19.9,-94.9,-6.2,-88.3,7,-85.7,13.7,-81.5,24.5,-81.5,31.5,-81.5,36.5,-82.9,40.6]}},79).wait(1));

	// Layer 255
	this.instance_2 = new lib.ovel_mc();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-49.2,-30.4);
 
	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-49.1,-30.2,-44.3,-31,-38.2,-35.5,-28.9,-43.2,-23.5,-47.6,-13.5,-55.8,-4.8,-59.8,7,-65.3,20,-65.3,31.6,-65.3,40.2,-58.5,48.7,-51.9,48.7,-43.4,48.7,-36.1,41.3,-27,36.8,-21.2,25.2,-10.6,13.3,0.4,9.1,5.4,1.7,14.2,1.7,20.9,1.7,23.7,8.8,26.7,13,28.5,24.4,32.4,34.8,36.2,39.9,39.9,47,44.9,47,51.1,47,59.1,38.5,62.1,33.8,63.8,26.8,63.8,21,63.8,-13.4,52.9,-47.6,41.9,-53.6,41.9,-69.4,41.9,-86,56.3,-90.2,59.9,-97.3,66.1,-103.1,70.6,-107.4,70.6,-119,70.6,-125.8,55.3,-130.8,43.9,-130.8,33.4,-130.8,17.6,-113.8,8.4,-99,0.4,-82.1,1.9,-70.9,2.7,-66.5,-0.2,-63.2,-2.5,-62.5,-8.4,-61.2,-19,-61.1,-19.5,-59.7,-24.7,-55.7,-28.3]}},79).wait(1));

	// Layer 254
	this.instance_3 = new lib.circle("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(27.1,4.2);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[27,4.3,31.4,17.7,31.4,25,31.4,32.5,29,42.3,26.3,52.6,22,61.5,11.3,83.4,-2.4,83.4,-7.9,83.4,-17.3,80.3,-26.7,77.2,-31.6,77.2,-39.1,77.2,-46.3,79.7,-50.5,81.1,-58.3,85,-66.1,88.9,-70.4,90.4,-77.5,92.8,-84.9,92.8,-104.7,92.8,-116.6,80.2,-127.5,68.5,-127.5,51,-127.5,43.8,-121.9,39,-119.8,37.2,-109.4,31.3,-100.9,26.4,-97,21.3,-91.3,13.8,-91.3,2.3,-91.3,-2.8,-98.3,-15.5,-105.3,-28.3,-105.3,-33.7,-105.3,-43.6,-99.2,-53.3,-93.1,-62.9,-87.3,-62.9,-82.4,-62.9,-78,-60,-75.5,-58.2,-70.9,-53.4,-66.3,-48.7,-63.5,-46.9,-58.9,-43.9,-53.5,-43.9,-42.7,-43.9,-32.6,-49.1,-25.4,-52.8,-16.7,-60.5,-4.2,-71.5,-3.7,-71.9,3.1,-77.1,8.6,-77.1,14.3,-77.1,20.5,-73.9,28.2,-69.9,28.2,-63.7,28.2,-57.9,24.8,-53.9,22.9,-51.8,17.2,-48,11.9,-44.4,9.6,-41.4,8.9,-40.4,8.3,-39.2,9.7,-35.5,11.9,-30.8,13.7,-26.9,15.3,-23.5,18.4,-17,20.3,-12.8,23.8,-5,26.2,1.6]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-137.3,-53.4,200.6,139.8);


(lib.anim2_36 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 249
	this.instance = new lib.rectangle("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(24.2,27.9);
 

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[24.5,27.8,25,28.8,25.3,29.6,26.6,32.4,28.1,36.1,36.2,55.1,36.2,59.6,36.2,66.9,31.9,70.5,26.7,74.8,14.5,74.8,5,74.8,-14,62.5,-24.5,55.7,-27.5,54,-34.4,50.2,-38.4,50.2,-48.7,50.2,-52.2,56.7,-54.2,60.7,-54.4,71.2,-54.5,81.8,-56.4,85.7,-59.6,92.2,-69.5,92.2,-80.8,92.2,-91.3,83.6,-102.9,74,-102.9,61,-102.9,58.5,-90.5,42.3,-78.2,26.1,-78.2,21.2,-78.2,10.8,-87.5,6.1,-92.9,3.4,-107.9,1,-122.6,-1.4,-128.4,-4.6,-137.7,-9.6,-137.7,-20.8,-137.7,-32.6,-126.1,-39.7,-116.7,-45.4,-105.8,-45.4,-101.6,-45.4,-89.9,-42.5,-78.2,-39.6,-73.1,-39.6,-47.5,-39.6,-34.3,-50.8,-25.6,-58.1,-18.9,-75.1,-14.5,-86.3,-13.6,-88.2,-10.4,-95.3,-6.7,-99.6,2.9,-110.7,22.4,-110.7,34,-110.7,40.6,-103.5,46.4,-97.1,46.4,-87.5,46.4,-80.3,41.8,-70.3,39.8,-65.9,31.9,-51.6,25,-39.1,21.9,-31.2,17.4,-19.4,17.4,-9.3,17.4,1.5,20.3,13.6,21.2,17.3,22.5,22.2]}},79).wait(1));

	// Layer 248
	this.instance_1 = new lib.pentagon2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(27.7,-53.2);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[27.2,-52.8,26,-54.7,24.4,-56.9,16.8,-67.1,13.1,-77.4,6.9,-94.5,1,-99.7,-4.7,-104.8,-17.4,-104.8,-53.9,-104.8,-80.9,-89.4,-93.2,-82.3,-100.1,-73.5,-107.2,-64.4,-107.2,-55,-107.2,-47.6,-101.1,-36.7,-97.4,-30.1,-97,-29.1,-95.1,-25.2,-95.1,-22.7,-95.1,-15.4,-101.4,-11,-105.1,-8.4,-115.2,-4.8,-125.3,-1.5,-129.2,1.4,-135.5,6,-135.5,13.6,-135.5,20.5,-131.2,31,-127,41.6,-120.2,51.4,-103.5,75.5,-86.9,75.5,-75.3,75.5,-68.9,68.1,-64.6,63.3,-60.8,52,-56.5,39.5,-54.1,35.8,-49.2,28.4,-40.4,28.4,-24.5,28.4,-18.9,39.2,-16.7,43.4,-15.5,50.2,-15.1,52.9,-14,62.9,-12.3,79.5,-7.1,86.6,0.8,97.3,20.6,97.3,22.9,97.3,27.6,93.2,32.3,89.2,37.1,83.2,49.1,68.3,49.1,58.5,49.1,34.9,32.7,23.2,29.1,20.6,21.5,16.9,16.4,14.5,16.4,13,16.4,6,21.7,1.4,24.6,-1.2,33.3,-5.3,41.6,-9.2,44.9,-12.5,50.2,-17.6,50.2,-25.5,50.2,-36.3,43.4,-42.4,39.4,-45.9,31,-49.4]}},79).wait(1));

	// Layer 247
	this.instance_2 = new lib.triangle();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-48.7,-20.6);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-48.6,-20.5,-48.4,-20.6,-48.3,-20.7,-46.7,-21.2,-44.3,-21.6,-40.1,-22.3,-35.1,-22.3,-33.3,-22.3,-29.4,-20.2,-24.8,-17.8,-20.8,-14.3,-9.6,-4.7,-9.6,6.4,-9.6,14.2,-22.5,20.8,-34.6,27.2,-47.1,27.2,-55.4,27.2,-66.4,20.8,-72.1,17.5,-74.7,16.3,-79.4,14.3,-83.9,14.3,-91.7,14.3,-100.5,20.8,-111.7,28.9,-111.7,41.3,-111.7,59.4,-92.6,70.1,-75.6,79.7,-51.9,79.7,-32.4,79.7,-15.8,57.9,-15.4,57.1,-4.1,40.7,2.2,31.6,6.4,28.8,9.7,26.6,20.2,23.8,33.8,20.5,38.8,18.7,62.2,10,62.2,-10.4,62.2,-16.7,34.4,-30.1,27.2,-33.7,13.9,-39.7,3.6,-44.5,1.6,-46.3,-3.8,-51.3,-8.7,-60.7,-11.5,-66,-16.7,-76.4,-21.6,-84.9,-27.5,-89,-35,-94.1,-46.3,-94.1,-50.9,-94.1,-57.2,-89.5,-63.1,-85.2,-68.7,-78.1,-81.5,-62.2,-81.5,-50.3,-81.5,-38.8,-69.4,-28.8,-69.3,-28.7,-69.2,-28.6,-66.8,-26.7,-64.5,-25.2,-60.2,-22.3,-55.9,-20.8]}},79).wait(1));

	// Layer 246
	this.instance_3 = new lib.ovel_mc();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-63,30.3);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[-63.3,30.4,-62.3,32.6,-61.4,35,-57.5,42.3,-56.1,46.5,-51.2,61.1,-40.6,61.1,-39.4,61.1,-31.7,58.8,-23.9,56.5,-16.9,56.5,-14.5,56.5,-8.3,58.6,-4.7,59.9,5.1,63.4,26.3,70.2,45.9,70.2,56.6,70.2,66,61.2,75.3,52.1,75.3,41.7,75.3,26.9,67.8,15.3,62.5,7,51.4,-1.9,36.1,-14,35,-15.1,27.5,-22.5,27.5,-30.2,27.5,-34.7,32.9,-42.5,38.3,-50.3,38.3,-53.2,38.3,-60.8,25.9,-66.3,15.5,-70.9,6.2,-70.9,-2,-70.9,-28.8,-63.9,-42.3,-60.4,-54.3,-56.9,-55.4,-56.9,-72.8,-66.2,-90.2,-75.5,-92.1,-75.5,-101.6,-75.5,-110.6,-67.8,-119.8,-59.9,-119.8,-50.9,-119.8,-33.6,-113.6,-23.2,-109.3,-15.9,-98.4,-7.9,-84,2.6,-79.3,7.3,-71.5,15,-65.9,25.4]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-107.5,-89.2,179.8,149.9);


(lib.anim2_35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 241
	this.instance = new lib.square8_2("single",0);
	this.instance.parent = this;
	this.instance.setTransform(-24.9,36.2);
 

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[-24.9,36.2,-24.3,36,-23.2,36,-18.8,35.7,-10.4,38.1,0.2,41.2,12.2,41.2,31.2,41.2,40.5,38.2,55,33.5,55,20.6,55,8.3,31.7,-18.1,25.9,-24.7,15.7,-36,8.4,-44.6,8.4,-47.7,8.4,-57.6,16.5,-66.6,20.9,-71.6,22,-73.1,24.5,-76.9,24.5,-81,24.5,-92.4,13.8,-100,3,-107.7,-13.4,-107.7,-18.6,-107.7,-27.6,-102.5,-38.4,-96.3,-41.1,-88.6,-42.4,-84.9,-43.4,-79.6,-44.4,-73.7,-44.9,-70.8,-47.1,-60.4,-52.6,-54.2,-56.8,-49.6,-66.9,-41.9,-72.7,-37.5,-84.9,-28.3,-106.9,-10.8,-106.9,0.7,-106.9,27.2,-63.1,34.7,-53.9,36.3,-41.4,36.2,-28.8,36.2,-28.2,36.2,-28,36.2,-27.1,36.2]}},79).wait(1));

	// Layer 240
	this.instance_1 = new lib.triangle("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-68.6,14.2);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-68.6,14.2,-61.3,20,-51.9,24.4,-40.5,29.7,-23.6,41.6,-0.4,57.9,2.1,59.5,15.4,67.8,23.1,67.8,28.7,67.8,33.2,60.3,37.6,53,37.6,45.1,37.6,35.9,33.1,28.1,30.1,22.9,23.1,15.9,15.3,8.1,13,4.7,8.5,-1.9,8.5,-9.1,8.5,-19.7,17.1,-27,22,-31.2,36,-38,49.5,-44.5,54.9,-49.5,63.5,-57.5,63.5,-69.3,63.5,-79.8,59.2,-84.9,53.7,-91.5,39.8,-91.5,29,-91.5,22.1,-84.7,17.7,-80.5,12.2,-69.9,6.6,-58.9,2.9,-55.1,-3.6,-48.3,-13.5,-48.3,-22.5,-48.3,-28.7,-52.2,-30.9,-53.6,-38.4,-60.7,-44.7,-66.5,-51.2,-69.2,-60.7,-73.1,-75.3,-73.1,-92.8,-73.1,-106.5,-64.5,-123.8,-53.8,-123.8,-34.3,-123.8,-21.8,-118.7,-14,-114.6,-7.8,-106.1,-3.1,-95.3,1.9,-89.6,4.6,-79.8,9.2,-70.2,13.2]}},79).wait(1));

	// Layer 239
	this.instance_2 = new lib.hexagon2("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(20.4,-52.8);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[20.4,-52.7,20.5,-52.3,20.7,-51.8,21.7,-49.5,24.5,-46,25.2,-45.2,25.9,-44.2,36.6,-31.9,42.7,-24.3,67,6.2,67,27,67,34.1,62.5,40.4,56.6,48.6,45.8,48.6,41.3,48.6,32.8,42.2,24.2,35.1,15.6,28,4.1,18.4,-4.2,13.8,-15.7,7.3,-25.3,7.3,-45.4,7.3,-58.8,17.6,-66.9,24.1,-77.6,40.4,-88.6,57.1,-95.6,63.1,-107.9,73.4,-126.5,73.4,-142.8,73.4,-149.4,61.5,-154.9,51.6,-154.9,30.3,-154.9,13.2,-140.4,-1.4,-134.9,-6.9,-128.8,-10.3,-123.2,-13.6,-120,-13.6,-109.6,-13.6,-97.7,-17.9,-83.9,-22.9,-74.1,-31.9,-65.6,-39.7,-54.4,-52,-41.5,-66.3,-38.1,-69.7,-29.3,-78.2,-22.1,-82.2,-13.3,-87.1,-3.7,-87.1,23,-87.1,23,-70.6,23,-66.7,20.7,-59.4,19.9,-56.9,20.1,-54.9]}},79).wait(1));

	// Layer 238
	this.instance_3 = new lib.square8_2("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-30.6,18.6);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[-30.5,18.6,-30.5,18.6,-30.5,18.6,-35.2,20.1,-43,21,-47.5,21.6,-57.3,22.5,-75.7,24.6,-84.1,30.1,-96.3,38.2,-96.3,56.4,-96.3,68.7,-87.5,76.9,-78.2,85.7,-63.1,85.7,-55,85.7,-46.2,80.7,-39.5,76.9,-28.9,68,-9.1,51,-9.1,50.9,4.1,40.4,16.5,33,30.2,24.9,45.1,23.3,53.4,22.4,65.9,22.8,75.1,22.5,78.5,17.4,82.8,11,82.8,-7.3,82.8,-42.8,69.6,-64.3,54.6,-88.6,26.2,-87.5,-11.3,-86.1,-29.2,-91.4,-39.8,-94.6,-48.1,-101.2,-51.3,-103.7,-53.6,-104.7,-56.9,-106,-62.2,-106,-86.5,-106,-102.1,-88.4,-116.7,-72,-116.7,-49.1,-116.7,-30.5,-107,-21.2,-96.7,-11.5,-75.4,-11.5,-69.8,-11.5,-60.3,-14.3]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-116.6,-94.8,185.3,163.8);


(lib.anim2_34 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 233
	this.instance = new lib.square8_2("single",0);
	this.instance.parent = this;
	this.instance.setTransform(-76.2,35.8);
	 

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[-75.9,35.8,-64.6,37.2,-39.9,39.3,-35.3,40.9,-27.7,44.5,-21.6,47.5,-18.3,48.6,-10,51.5,5.6,51.5,19.9,51.5,27.1,46.7,35.7,40.9,35.7,27.5,35.7,22.1,32,9.6,28.3,-2.8,28.3,-7.3,28.3,-13.1,31.8,-18.8,33.6,-21.9,39.3,-28.7,44.7,-35.1,47,-39.3,50.4,-45.9,50.4,-52.9,50.4,-70.1,32.1,-88.5,25.2,-95.3,17.9,-100.1,11.2,-104.4,8.4,-104.4,-12.1,-104.4,-17.2,-94.6,-19.2,-90.8,-19.5,-84.3,-19.5,-84,-19.5,-71.9,-19.5,-70.4,-18.3,-57.4,-17.2,-44.4,-17.2,-42.9,-17.2,-33.7,-29.6,-27.7,-35.4,-25.1,-57,-18.9,-76.1,-13.5,-84.6,-8.1,-97.1,0,-97.1,12.8,-97.1,28.9,-88.1,33.9,-86.9,34.5,-78.5,35.6]}},79).wait(1));

	// Layer 232
	this.instance_1 = new lib.rectangle("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(5.3,-47);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[5.3,-46.9,19.4,-33.2,31.5,-24.4,37.6,-19.9,53.8,-9.9,62.7,-4.4,65.5,0.2,68.9,5.8,68.9,17.8,68.9,29,55.3,36.9,42.7,44.2,27.5,44.2,23.2,44.2,0,40.6,-11.6,38.7,-22.7,36.9,-35.4,36.9,-44.3,43.4,-49.2,47.1,-57.5,57.8,-65.5,68.1,-71.8,72.2,-81.7,78.8,-96.5,78.8,-122.5,78.8,-132.7,54.1,-139,39.1,-139,15.3,-139,8.5,-130.7,5.9,-128.1,5,-121.7,3.8,-114.5,2.4,-110.7,1.4,-89.8,-4.2,-81.7,-7.5,-76.3,-9.8,-63.8,-17,-57.8,-20.6,-53,-30.5,-52.3,-32,-49.6,-38.1,-47.8,-42.3,-46.6,-44.1,-44.8,-46.8,-31.7,-49.9,-19.8,-52.7,-14.1,-52.7,-6.8,-52.7,0.7,-49.9,1.5,-49.6,3.3,-48.4]}},79).wait(1));

	// Layer 231
	this.instance_2 = new lib.heptagon("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-72,-36.8);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-71.9,-36.7,-72.4,-34,-72.5,-31.4,-74.3,-25.9,-78.2,-21.5,-82,-17.3,-94.3,-9.4,-105.8,-2.2,-110.6,4.3,-118,14.2,-118,29.3,-118,45.9,-103.2,51.6,-93.6,55.3,-71.3,55.3,-57.6,55.3,-46.7,53.4,-35.8,51.5,-31.3,51.5,-22,51.5,-12,55.4,-7.1,57.3,5.8,63.9,17.4,69.8,25.3,72.4,37,76.2,49.2,76.2,68.4,77.3,74.8,67.6,78.7,61.7,78.7,47.3,78.7,35.9,69.5,24.8,63.3,17.4,49.2,6.4,33.3,-5.8,28.9,-10.4,19.6,-19.8,19.6,-28.2,19.6,-32.5,21.4,-41.2,23.2,-49.9,23.2,-52.1,23.2,-60.2,15,-66.6,6.7,-72.9,-9.9,-77.4,-20.7,-80.4,-33.6,-82.2,-43,-83.5,-46.6,-83.5,-56.6,-83.5,-63.1,-76.2,-68.9,-69.7,-68.7,-62.6,-68.4,-56.3,-69.9,-47.5,-70.4,-44,-71.2,-40.8,-71.3,-40.2,-71.4,-39.6]}},79).wait(1));

	// Layer 230
	this.instance_3 = new lib.hexagon2("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(25.2,3.1);
	 

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[25.2,3.1,27.8,16.3,39.7,33.8,47.7,45.7,49.6,48.8,54.1,56.2,54.1,59.5,54.1,70.2,48.1,81.2,38.7,98.4,19.5,98.4,16.1,98.4,13.7,96.2,13,95.6,9.1,90.8,1.8,81.9,-8.7,77.2,-8.8,77.1,-9.1,77,-9.2,77,-9.3,77,-13.4,76,-39.8,80.8,-60.6,84.6,-78.6,88.5,-78.6,88.5,-78.6,88.5,-91.3,88.3,-94.5,78.7,-95.7,75.1,-95.9,69.5,-95.8,63.1,-95.8,60.1,-95.8,41.9,-89.7,31.1,-84.1,21,-66.3,6,-59.3,1.3,-66.3,-3.5,-75.6,-9.2,-89.1,-15.3,-105.6,-22.7,-108.4,-24.2,-117.5,-29,-121.6,-34.4,-126.6,-40.8,-126.6,-50.4,-126.6,-62.2,-119.2,-76.1,-110.8,-92.1,-100.2,-92.1,-94.5,-92.1,-89.1,-88.1,-82.8,-82.4,-78.9,-79.2,-63.4,-66.3,-38.6,-66.3,-29.8,-66.3,-13.9,-68.1,2.1,-69.9,8.6,-69.9,23.2,-69.9,28.3,-63.9,34.4,-56.8,34.4,-35.5,32.8,-13.3,30.8,-8.5,27.9,-2.4,26.2,1.4]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-114.8,-79.7,188.3,148.3);


(lib.anim2_33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 225
	this.instance = new lib.hexagon2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(51.4,17.1);
 

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[51.5,17.1,51.6,16.8,51.6,16.5,52.1,15,52.6,13.7,56.6,2.2,57.1,-0.2,61.4,-16.7,61.4,-36.4,61.4,-59.5,55.1,-70.6,48.1,-83.2,31.7,-83.2,22.5,-83.2,14.2,-79.1,10.3,-77.2,-0.1,-70.2,-9.2,-63.9,-16.1,-61.2,-26.4,-57.1,-38.8,-57.1,-41.2,-57.1,-61.6,-63.3,-81.8,-69.6,-86.9,-69.6,-102.3,-69.6,-112.3,-61.3,-123.8,-52,-123.8,-34.8,-123.8,-28.4,-122.7,-25.9,-121.4,-23,-117.5,-21.6,-114.3,-20.6,-105.3,-19.4,-88.1,-17.2,-83.2,-16.4,-67.4,-14.1,-57.3,-4.7,-48.6,3.3,-48.6,11.4,-48.6,14.6,-51.6,19,-53.3,21.7,-58.1,27.9,-67.6,41.3,-67.6,57.2,-67.6,71.4,-63.4,79.1,-58.2,88.5,-46.7,88.5,-20.6,88.5,-20.6,64.5,-20.6,64.1,-25.9,34.7,-25.9,26.7,-19.6,22.8,-14.5,19.6,-6.2,19.6,-1.6,19.6,2,21.9,3.7,23,8.1,27,11.9,30.5,15.2,32,20,34.3,26.6,34.3,37.3,34.3,44.3,27.7,45.8,26.2,47.1,24.5]}},79).wait(1));

	// Layer 224
	this.instance_1 = new lib.square8_2("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-29,51.7);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-28.9,51.8,-24.8,52,-24.4,52,-16.8,52,-8.7,54.9,-4.9,56.4,5.5,61.4,14.8,65.9,21.2,67.8,30.8,70.8,41.1,70.8,60.9,70.8,68.8,62.5,76,54.9,76,36.9,76,16.2,68.8,5.6,63.2,-2.6,50.8,-7.1,35.7,-11.3,27.8,-14.1,13.7,-19.3,5.1,-29,-1.8,-36.7,-3.9,-53,-4.6,-57.5,-5.6,-66.9,-6.6,-75.3,-8.2,-81.1,-10.3,-88.5,-25.4,-94,-38.2,-98.7,-47.8,-98.7,-61.9,-98.7,-70.6,-92.5,-79,-86.6,-79,-77.4,-79,-69.6,-71.7,-54.9,-64.4,-40.1,-64.4,-35.2,-64.4,-22,-74,-18.7,-79.3,-16.8,-95.1,-17.7,-110.2,-18.5,-116.3,-15.6,-125.9,-11.2,-125.9,4.1,-125.9,12.2,-118.6,21.8,-110.6,32.3,-102,32.3,-96.6,32.3,-86.2,30.8,-75.8,29.2,-71.8,29.2,-55.9,29.2,-43.4,39.6,-41.2,41.4,-34.5,47.9,-33.4,49,-32.4,49.9]}},79).wait(1));

	// Layer 223
	this.instance_2 = new lib.pentagon2("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(4.6,-27.2);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[4.5,-27.1,18,-18.4,28.2,-14.8,44.1,-9.1,49.2,-6.4,59.7,-0.9,64.8,7.6,70.8,18,70.8,35.2,70.8,42.7,58.3,50,53.7,52.7,48.7,54.5,44.3,56.2,42.5,56.2,37.5,56.2,28.4,52.9,24,51.3,10.7,45.7,-14.1,35.2,-24.9,35.2,-36.4,35.2,-43.7,45.9,-47.3,51.2,-54.7,69.6,-61.3,86.1,-67.6,93.2,-77.2,104,-92.6,104,-108.6,104,-118.6,87.4,-126.9,73.6,-126.9,58.3,-126.9,46.2,-120.8,39,-117.2,34.9,-107.1,29.1,-97.4,23.5,-93.5,18.7,-87.3,10.9,-87.3,-2,-87.3,-9.8,-92.9,-17.9,-96.2,-22.8,-105,-32.1,-113.9,-41.3,-117.2,-46.2,-122.8,-54.5,-122.8,-62.3,-122.8,-75.2,-114.4,-85.2,-105.7,-95.7,-93.6,-95.7,-85.2,-95.7,-71,-84.3,-65.6,-79.9,-43.8,-59.7,-26.2,-43.2,-15.6,-36.4,-7.4,-31.1,-0.5,-29.4]}},79).wait(1));

	// Layer 222
	this.instance_3 = new lib.triangle("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-86.5,-33.1);
 ;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[-86.5,-33,-82.1,-37.1,-77.9,-41.3,-62.6,-56.8,-54,-72.7,-46.5,-86.5,-32.8,-94.5,-18.6,-102.9,-0.7,-102.9,10.3,-102.9,15.3,-96.9,18.9,-92.5,20.5,-82.5,23.2,-65.8,23.4,-65,26,-55,32.2,-49.7,40.3,-42.9,52.5,-40,59.3,-38.4,72,-36.5,82.2,-34.3,86.8,-28.5,92.6,-21.1,92.6,-5.2,92.6,4.9,84.6,11.8,80,15.7,67.1,21.7,54.5,27.6,49.6,32,41.6,39.1,41.6,49.9,41.6,53.1,44.1,59.3,46.7,65.5,46.7,69.7,46.7,83.3,34.3,71.4,21.9,59.6,10,65.6,-1.8,71.7,-7.5,80.7,-13.1,89.8,-19.3,81.2,-26,72.1,-29.6,69,-36.2,63.5,-45.2,63.5,-52.7,63.5,-62.1,67.1,-71.6,70.7,-74.3,70.7,-91,70.7,-104,52,-109.3,44.2,-112.5,35.2,-115.5,26.6,-115.5,19.7,-115.5,6.9,-101.3,-10.3,-101,-10.6,-87.9,-30.9]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-134.5,-74.6,234.2,159.1);


(lib.anim2_32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 217
	this.instance = new lib.hexagon2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(50.5,7.7);
	 

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[50.5,7.7,50.4,13,50,27,49.4,46.3,47.2,57.6,39.6,97.1,6.1,97.1,-4.2,97.1,-8.7,87.6,-11,82.6,-13.7,66.4,-16.2,51.5,-20.1,45.2,-26.2,35.6,-39.2,35.6,-46.9,35.6,-54.5,39.3,-59.7,41.8,-67.2,47.4,-75.8,53.7,-78.6,55.4,-84.9,59.1,-90.3,59.1,-100,59.1,-109.3,52.8,-119.2,46.2,-119.2,38.1,-119.2,30.3,-111,23.5,-105,18.7,-92.7,13.1,-75,4.9,-74.5,4.7,-66.3,0.3,-66.3,-3.4,-66.3,-19.1,-76.8,-26.6,-82.7,-30.8,-100.1,-35.7,-116.6,-40.4,-123.4,-46.1,-133.9,-55,-133.9,-73,-133.9,-92.6,-108.2,-99.5,-94.8,-103.1,-71.3,-103.1,-60.8,-103.1,-53.9,-100.4,-48.6,-98.3,-42.3,-93,-34.9,-86.2,-29.6,-82.1,-20.2,-74.9,-8.5,-68.9,0.2,-64.4,14.3,-63.1,22.1,-62.4,36.6,-61.4,48.1,-59.8,53.5,-54,60.2,-46.9,60.2,-31.4,60.2,-19.7,55.5,-7.8,51.3,2.5,51,4]}},79).wait(1));

	// Layer 216
	this.instance_1 = new lib.rectangle("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-61.4,8.6);
	 

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-61.3,8.6,-61.5,0.2,-67.3,-11.9,-71.2,-20.1,-80.4,-35.1,-90.5,-51.4,-93.5,-57.3,-99.5,-68.8,-99.5,-75.5,-99.5,-84,-88.4,-90.8,-78.4,-97,-68.8,-97,-62.8,-97,-52,-90.7,-50.1,-89.5,-30.5,-76.7,-16.1,-67.3,-6.3,-62.8,7.6,-56.4,18.9,-56.4,22.4,-56.4,38.4,-62,46.4,-64.7,54.1,-67.5,66.9,-67.5,73.8,-60.1,80,-53.3,80,-42.2,80,-31.8,69.1,-24.6,63.4,-20.9,44.9,-13.6,28,-7,20.8,-1.2,9.8,7.7,9.8,20.9,9.8,24.5,14.8,36.8,19.7,49.1,19.7,54.7,19.7,64.5,14.7,71.3,10.2,77.5,4.8,77.5,-9.2,77.5,-39.8,43.3,-49.6,32.4,-60.5,12]}},79).wait(1));

	// Layer 215
	this.instance_2 = new lib.octagon6("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-68.5,-58.1);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-68.4,-58,-64.2,-62.7,-58,-70.5,-46.6,-85,-41.2,-90.9,-18.7,-115.5,3.5,-115.5,17.1,-115.5,22,-108.2,25.7,-102.6,25.7,-89.1,25.7,-81.3,20.2,-72.7,16.3,-66.6,8,-58,-2.5,-47.1,-4.3,-45,-9.8,-38.3,-9.8,-33.7,-9.8,-25.5,-2.3,-19.6,5.5,-13.4,17.1,-13.4,25.5,-13.4,36.4,-15.8,47.3,-18.3,52.1,-18.3,57.7,-18.3,67.7,-12.2,78.7,-5.3,78.7,1.1,78.7,16.6,57.5,27,49.9,30.8,35.8,35.6,19.5,41.1,11,44.2,1.7,47.6,-4.6,55,-7,57.9,-13.4,68.4,-18.3,76.5,-23.1,80,-29.9,84.8,-41.2,84.8,-56.1,84.8,-67.2,73.7,-71.6,69.3,-78.1,60.5,-86.1,49.5,-91,43,-94.6,38.2,-101.7,34.1,-104.8,32.3,-114.7,27.8,-122.4,24.2,-125.6,21.7,-130.2,17.9,-130.2,13.4,-130.2,-3.1,-123.8,-14.4,-118.6,-23.3,-108.2,-30.5,-105.7,-32.2,-89.2,-41.6,-77.8,-48,-72.4,-54,-71.5,-54.8,-70.4,-55.9]}},79).wait(1));

	// Layer 214
	this.instance_3 = new lib.square8_2("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(34.4,-26.5);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:34.1,y:-27.7},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-110.2,-99.8,209,149.6);


(lib.anim2_31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 208
	this.instance = new lib.hexagon2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(17.1,-46.5);
 

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[17.1,-46.4,19.1,-42.9,19.5,-41.8,19.6,-41.1,19.8,-40.3,19.8,-40.3,19.9,-40.2,19.9,-40.2,19.9,-40.1,21.9,-33.3,26.3,-27,32.9,-17.8,48.2,-6.7,67.2,7.3,70.8,10.8,81.3,20.8,81.3,31.3,81.3,57.7,71.4,68.4,61.4,79.2,51,90.4,40.5,101.5,31.4,98.2,22.4,94.9,3.4,81.7,-14.9,69.1,-26.2,62.5,-43.6,52.3,-57.7,48,-91.1,37.6,-107.3,19.5,-130.2,-6,-130.2,-54.1,-130.2,-92.4,-115.5,-108.2,-101.8,-122.8,-70.6,-122.8,-46.6,-122.8,-33.8,-107.2,-28.8,-101,-23.8,-90.3,-17.9,-77.1,-14.6,-69.9,-11.5,-62.9,-2.8,-58.3,7.2,-54.1,12.8,-50.5,14.4,-49.4,15.7,-48.2]}},79).wait(1));

	// Layer 207
	this.instance_1 = new lib.square8_2("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-67,6.9);
	 

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-66.8,6.9,-63.9,9,-57.7,19,-51.5,29.1,-48.6,42.3,-45.4,55.5,-42.7,71.2,-39.9,86.9,-36.9,94.9,-33.9,102.9,-24.7,91.7,-15.5,80.4,-3.4,87.7,8.7,95,17.8,93.2,22.4,92.3,24.7,86.9,27,81.6,27.1,71.9,27.1,60.5,21.4,49.4,17.8,42.1,9.2,31,-0.2,18.8,-3,14.1,-8.6,4.5,-8.6,-4.1,-8.6,-16.1,4.1,-24.5,10.4,-28.7,32.1,-37.5,51.5,-45.4,59.8,-52.3,72.5,-62.9,72.5,-78.6,72.5,-87.6,61.5,-95.8,49.7,-104.4,35.7,-104.4,24.2,-104.4,13.5,-98.6,7.3,-95.2,-4.2,-85.9,-15.5,-76.8,-22.1,-73.3,-32.8,-67.5,-44.6,-67.5,-44.9,-67.5,-71.1,-72.4,-97.4,-77.4,-97.6,-77.4,-109.1,-77.4,-120.6,-68.7,-132.7,-59.4,-132.7,-48.4,-132.7,-36.7,-127,-29.7,-122.6,-24.2,-111.6,-18.8,-97.4,-12.4,-88.9,-7.9,-83.9,-5.2,-79.3,-2.3,-77.1,-0.9,-74.9,0.5,-71.3,2.5,-68.2,5]}},79).wait(1));

	// Layer 206
	this.instance_2 = new lib.heptagon("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-71.1,-61.8);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-71,-61.8,-58.3,-61,-46.1,-74.9,-39.8,-82.2,-33.7,-91.6,-5.5,-119.8,17.8,-119.8,29.7,-119.8,40.6,-113.7,52.9,-106.8,52.9,-96.8,52.9,-92.2,41.8,-74,30.8,-55.9,30.8,-51,30.8,-42.7,38.1,-35.5,40.7,-32.9,54.1,-22.9,65.1,-14.9,70.2,-7.8,77.5,2.5,77.5,15.9,77.5,27.9,68.3,35.1,60.5,41.2,50.7,41.2,47.7,41.2,36.7,38.8,25.6,36.3,16.3,36.3,-3.9,36.3,-17.2,45.2,-24.5,50.1,-36.9,64.9,-48.7,78.8,-58.7,84.5,-74.3,93.5,-81.8,83.3,-89.4,73.2,-112.2,67.8,-135.1,62.4,-137.9,44.8,-140.8,27.3,-130.9,15.9,-121.9,5.5,-110.3,5.5,-103.6,5.5,-88.2,8,-72.7,10.5,-66,10.5,-49.8,10.5,-38.6,2.4,-27.6,-5.6,-27.6,-17.1,-27.6,-27.9,-36.4,-33,-42.3,-36.5,-55.8,-38.4,-71.3,-40.6,-75.3,-42,-84.2,-45.2,-84.2,-52.8,-84.2,-58.4,-78.3,-61.9,-74.5,-64.2,-72.7,-62.6]}},79).wait(1));

	// Layer 205
	this.instance_3 = new lib.circle("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-38.9,48);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[-38.9,48,-54.7,40.4,-60.1,42.4,-65.5,44.4,-72.7,47.2,-83.7,51.5,-94.6,51.5,-102.3,51.5,-111.7,41.7,-120.4,32.7,-120.4,28.2,-120.4,19.4,-113.1,14.7,-109.6,12.4,-97,8.2,-85.8,4.5,-81,0.1,-73.7,-6.5,-73.7,-18.3,-73.7,-28.4,-81,-36.8,-85.9,-42.5,-97,-50,-109.7,-58.6,-113.1,-61.7,-120.4,-68.4,-120.4,-75.5,-120.4,-85.6,-106.9,-94.6,-94.3,-103.2,-82.4,-103.2,-72.7,-103.2,-60.9,-98.4,-53.4,-95.3,-40.3,-87.8,-26.1,-79.8,-20.5,-77.2,-9.8,-72.4,-1.8,-72.4,7.7,-72.4,20.2,-82.2,23.3,-84.7,28.2,-89,31.9,-92.1,33.1,-92.1,47.2,-92.1,60.3,-72.4,65,-65.4,68.3,-57.7,71.3,-50.9,71.3,-48.5,71.3,-39.2,67,-32.1,64.3,-27.6,57.8,-21.2,50.8,-14.5,48.5,-10.9,44.2,-4.6,44.2,3.5,44.2,8.9,47.3,16.4,49.1,20.8,54.1,30.1,59,39.4,60.8,43.9,63.9,51.5,63.9,57,63.9,66.7,57.9,76.2,50.9,87.3,41.1,87.3,38.9,87.3,20.2,80.8,10.6,77.5,0,73.7,-6.3,71.2,-14.4,65.6,-16.6,64.1,-27.9,55.5,-33.1,51.6,-37.4,49.1]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-113.9,-103.8,179.3,188.1);


(lib.anim1_41 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 199
	this.instance = new lib.rectangle("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(48.7,4.6);
 

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[48.7,4.5,56.9,17.7,61.6,22.2,80.5,40.4,80.5,53.4,80.5,74.9,49.8,86.7,25.6,96,-4.4,96,-40.9,96,-62.3,81.4,-82.3,67.7,-82.3,46.5,-82.3,34.3,-70.7,23.6,-62.7,16.2,-45.3,7.1,-23.6,-4.5,-20.1,-6.8,-8.5,-14.4,-8.5,-21.5,-8.5,-29.6,-13.2,-33,-18.4,-36.8,-31.6,-36.8,-38.6,-36.8,-58,-29.1,-77.3,-21.4,-85.8,-21.4,-99.8,-21.4,-114.6,-37.6,-120.7,-44.3,-124.6,-51.5,-128.4,-58.6,-128.4,-63.4,-128.4,-78.1,-116.1,-87.5,-105.2,-96,-91.2,-96,-84.6,-96,-63.5,-84.8,-42.3,-73.7,-35.8,-73.7,-19.2,-73.7,-8.8,-79.7,-1.8,-83.7,5.4,-92.9,13.5,-103.2,17.4,-106.1,25.4,-112.1,37.8,-112.1,43.6,-112.1,49.2,-107,55.8,-100.8,59.8,-89.2,63.9,-78,66.7,-69.7,72.1,-53.8,72.1,-49.9,72.1,-35.5,63.6,-21.3,58.2,-12.7,55.2,-7.8,52,-2.5,49.3,2.7]}},79).wait(1));

	// Layer 198
	this.instance_1 = new lib.rectangle("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-30.8,54.9);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-30.8,55.5,-24.5,56.2,-14.7,57.3,9.6,60,19.8,60,47.6,60,63.6,49.3,80.6,38,80.6,17.6,80.6,4.9,73.1,-3.7,70.1,-6.9,65.2,-10.6,59.4,-14.8,56.4,-17.1,44.9,-25.5,39.7,-34.5,32.1,-47.7,32.1,-68.3,32.1,-74.4,28.4,-82.6,24.4,-91.6,17.5,-99.1,-0.2,-118.3,-25.8,-118.3,-34.5,-118.3,-54.4,-108.7,-59.9,-106.2,-70.7,-100.9,-79.9,-96.5,-85.4,-94.5,-95.1,-91,-106.6,-76.4,-117.7,-62.2,-117.7,-54.4,-117.7,-43.4,-102.3,-31.4,-93.2,-24.3,-86.2,-9.1,-83.8,-3.9,-81.6,11.3,-79.7,24,-75.4,28.4,-63.8,40.2,-52.1,46.6,-50.2,47.6,-35.1,54.2]}},79).wait(1));

	// Layer 197
	this.instance_2 = new lib.triangle("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-60.1,-55.3);
	 

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:-61.9},79).wait(1));

	// Layer 196
	this.instance_3 = new lib.heptagon("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(22.8,-51.5);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[23,-51.6,27.7,-46.5,27.9,-46.3,28.8,-45.2,29.8,-44.1,31,-43,32.3,-41.5,38.2,-35,47.3,-20.8,61.3,1.3,61.3,9.9,61.3,16.4,60.6,18.3,58.7,23.7,50.5,29.1,54.1,32.7,57.3,37.1,62.9,44.9,62.9,50,62.9,71.3,38,84.6,28.2,89.8,16.1,92.7,5.3,95.4,-3.9,95.4,-10.5,95.4,-16.9,90.8,-23.1,86.3,-23.1,82.2,-19.6,74.6,-16.1,66,-9.2,48.6,-9.2,40,-9.2,33.2,-13.8,26,-18.6,18.5,-23.9,18.5,-30.3,18.5,-34.4,29.3,-36.8,35.8,-42.1,53.1,-48,68.7,-57.1,76.8,-69.3,87.6,-89.3,87.6,-110.1,87.6,-123,70.8,-135.4,54.5,-135.4,29.9,-135.4,21,-128.1,16.3,-124.9,14.2,-111.9,9.7,-100.5,5.8,-95.2,0.9,-87.2,-6.4,-86.2,-19.8,-83.9,-47.5,-74.4,-63.4,-60.9,-85.9,-33.2,-85.9,-14.1,-85.9,9.9,-64.5,15.9,-59.2,21.3,-53.5]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.1,-96.8,204.9,184.4);


(lib.anim1_40 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 313
	this.instance = new lib.ovel_mc();
	this.instance.parent = this;
	this.instance.setTransform(-61.2,-36.6);
 

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[-61.1,-36.6,-63,-31.9,-63.3,-31.2,-64.6,-28.1,-64.6,-25.3,-64.6,-14.7,-57.1,-9.3,-53.4,-6.9,-52,-5.8,-49.6,-3.8,-49.6,-1.2,-49.6,4.8,-54.3,8.4,-55.6,9.4,-64.6,13.9,-71.7,17.4,-75,21.9,-79.7,28.1,-79.7,38.7,-79.7,48.5,-75.1,57.8,-70,68.3,-62.9,68.3,-59.9,68.3,-55,63.7,-48.8,57.4,-45,53.8,-30,39.2,-15.5,39.2,-7.5,39.2,1.6,47.7,7.2,53.1,17.4,66.5,28,80.3,33,85.2,41.7,93.7,49,93.7,62.7,93.7,73.9,70.6,84.4,49.1,84.4,27.7,84.4,-1.5,73.9,-13.7,65,-24.2,46.7,-24.2,43.3,-24.2,35.3,-22.4,27.2,-20.6,23,-20.6,11.9,-20.6,5.8,-33.4,1.3,-43,1.3,-53.1,1.3,-70.6,1.3,-71.3,0.9,-82.1,-1,-88.9,-6.3,-107.4,-25.9,-107.4,-30.9,-107.4,-36.9,-102.5,-43.2,-97.5,-48.4,-88.9,-61.1,-68.4,-61.1,-42.2,-61.1,-41.3,-60.9,-39.3]}},79).wait(1));

	// Layer 314
	this.instance_1 = new lib.pentagon2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(45.8,4.2);
 

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[45.8,4.2,44.3,20.6,47.8,25.1,51.4,29.5,51.4,34.1,51.4,40.5,49.1,44.6,46.4,49.2,41.6,49.2,36.4,49.2,32,42,29.7,38.2,24.7,26.1,20.1,14.8,16.7,10.1,11.5,2.9,5.1,2.9,-3.1,2.9,-11,13,-14,16.8,-24.8,35.3,-33.8,50.6,-41.2,57.6,-51.9,67.7,-65,67.7,-78.6,67.7,-90.1,57.2,-102.8,45.6,-102.8,28.6,-102.8,12.9,-91.9,5.1,-83.1,-1.3,-69.3,-1.7,-52.6,-2.1,-38.7,-16,-24.1,-30.4,-24.1,-49.3,-24.1,-55.6,-26.1,-69.1,-28.2,-82.6,-28.2,-85.4,-28.2,-95,-21.8,-98.7,-16,-102.2,-1.1,-102.2,8.1,-102.2,19.2,-96.2,30.2,-90.2,39.9,-80.3,50,-69.8,55.9,-57.7,62.4,-44.4,62.4,-31.7,62.4,-25,53.2,-9.4,49.4,-3,47.2,1.5]}},79).wait(1));

	// Layer 315
	this.instance_2 = new lib.heptagon("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(33.7,-71.8);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 160, 0, 102, 0)];
	this.instance_2.cache(-45,-44,90,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[33.7,-71.7,28.1,-65.8,26.3,-62.2,24.4,-58.5,24.4,-55,24.4,-41.9,35.9,-30.6,44.1,-22.7,61.2,-13.4,84.5,-0.8,86.5,0.5,98,8,98,14.9,98,27.5,89.9,35.5,83.2,42.2,76.2,42.2,71.2,42.2,52.1,36.1,32.9,29.9,21.6,29.9,5,29.9,-6,37.8,-13.9,43.4,-21.1,55.2,-23.1,58.3,-26.6,64.4,-29.7,69.6,-32,72.5,-38.4,80.3,-47,80.3,-55.3,80.3,-64.7,75.1,-73.8,70,-81.7,61.3,-89.8,52.5,-94.4,42.2,-99.5,31.2,-99.5,21,-99.5,4.2,-87.2,-6.6,-82.9,-10.4,-78,-12.8,-74,-14.7,-72.1,-14.7,-70.5,-14.7,-66.1,-13.4,-61.7,-12,-60,-12,-49.2,-12,-40.7,-16.3,-31.3,-21.1,-31.3,-28.5,-31.3,-34.1,-35.3,-42.1,-39.4,-50.1,-39.4,-55.7,-39.4,-69.7,-21.7,-81.7,-14.4,-86.6,-6.1,-89.6,1.9,-92.4,8.1,-92.4,21.5,-92.4,28.5,-85.7,33.5,-80.9,34,-74.6]}},79).wait(1));

	// Layer 312
	this.instance_3 = new lib.octagon6("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-55.4,27.8);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 160, 0, 102, 0)];
	this.instance_3.cache(-44,-44,88,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[-55.3,27.8,-34.4,22.6,-26.7,30.6,-22.1,35.2,-13.6,49.2,-5.7,62.4,0.5,67.8,10.2,76.3,23.8,76.3,39,76.3,54.1,65.2,60.1,60.8,63.9,56,67.6,51.3,67.6,48.5,67.6,43.3,63.9,30.8,60.1,18.4,60.1,12.2,60.1,1.7,68,-9.4,73.9,-17.5,85.4,-27.7,91.7,-33.2,102.8,-42.6,110.7,-49.9,110.7,-53.9,110.7,-59.5,99.9,-68.3,87.9,-77.9,68.9,-85.9,55,-91.8,43.2,-94.7,33.8,-97,28.1,-97,24.9,-97,22.3,-94.1,19.5,-90.1,17.7,-87.8,10.6,-78.6,-3.1,-78.6,-17,-78.6,-32.4,-83.5,-47.8,-88.4,-61.4,-88.4,-77.1,-88.4,-81.1,-85.9,-84.7,-83.9,-84.7,-75.6,-84.7,-67.7,-79.3,-62.9,-75.8,-59.7,-67.4,-56.4,-58.5,-52.7,-55.6,-50.7,-50.2,-46.5,-50.2,-39.9,-50.2,-33.1,-55.8,-27.5,-58.7,-24.6,-68,-18.5,-76.7,-12.8,-80.3,-8.7,-85.9,-2.2,-85.9,6.1,-85.9,16.1,-78.6,23.3,-72.2,29.6,-65.6,29.6,-61.5,29.6,-57.9,28.3]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-105.7,-113.8,189.3,183.4);


(lib.anim1_39 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 305
	this.instance = new lib.ovel_mc();
	this.instance.parent = this;
	this.instance.setTransform(-57.5,-43);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 102, 102, 0)];
	this.instance.cache(-46,-25,103,54);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[-57.5,-42.9,-53.8,-34.6,-49.4,-31.9,-44.9,-29.1,-41.8,-25.9,-29.8,-13.5,-29.8,-5.1,-29.8,-1.4,-33.4,6.9,-37,15.2,-37,18.2,-37,24.3,-28.7,31.7,-19.5,40.1,-8.5,40.1,-0.4,40.1,4.4,34.1,7.1,30.6,10.8,20.9,14.4,11.2,17.4,7.4,22.4,1,31.1,0.5,40,-0.2,57.1,-0.9,71.4,-2,79.7,-4.4,90.3,-7.5,95.6,-14.1,101.6,-21.5,101.6,-34.1,101.6,-43.1,95.4,-46.9,88.8,-51.1,72.6,-51.1,65.9,-51.1,60.3,-47.4,57.4,-45.5,51.1,-39.2,45.2,-33.4,40.9,-31,34.3,-27.2,26,-27.2,17.3,-27.2,11,-36.3,6.9,-42.2,1.6,-56.1,-4,-71.3,-6.9,-76.1,-12.3,-85.2,-19.4,-85.2,-34.4,-85.2,-46.7,-68.6,-51.5,-62,-54.6,-54.5,-56.4,-50.1,-57.2,-46.6]}},79).wait(1));

	// Layer 306
	this.instance_1 = new lib.hexagon2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(50,-31.7);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 102, 102, 0)];
	this.instance_1.cache(-50,-44,101,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:52,y:-34.1},79).wait(1));

	// Layer 307
	this.instance_2 = new lib.square8_2("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-41,12.4);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 102, 102, 0)];
	this.instance_2.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-41.1,12.6,-34.8,16,-35.3,20.5,-36.1,26,-38.8,32.7,-41.5,39.6,-41.5,41.5,-41.5,46.8,-38.4,52.5,-34.1,60.1,-26.6,60.1,-23.2,60.1,-12.4,55.1,-1.6,50.3,6.8,50.3,14.8,50.3,24.5,56.3,29.7,59.6,31.5,60.4,35.4,62.3,38.8,62.3,50.2,62.3,59.6,51.4,68.4,41.3,68.4,31,68.4,21.2,63.9,15.2,60.8,11.1,53.7,7.2,45.5,2.8,43.6,1,38.9,-3.1,38.9,-9.7,38.9,-18.1,45.2,-24.5,49.4,-28.7,59.2,-34.2,69.7,-40.2,73.1,-43.2,79.4,-48.7,79.4,-55.4,79.4,-64.6,70.6,-71.8,62.5,-78.3,54.2,-78.3,43.1,-78.3,34.2,-73.3,28.2,-70,20.6,-62.4,11.9,-53.8,8.7,-51.6,1.7,-46.6,-6,-46.6,-11.8,-46.6,-18.8,-51.1,-22.5,-53.4,-31.5,-60.8,-39.9,-67.6,-44.9,-70.4,-52.6,-74.9,-59.6,-74.9,-69.7,-74.9,-77.5,-66.2,-86.1,-56.7,-86.1,-41.7,-86.1,-18.9,-64.7,-2.6,-61.6,-0.3,-47.9,8.6,-47.3,9.1,-46.6,9.5]}},79).wait(1));

	// Layer 304
	this.instance_3 = new lib.rectangle("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(20.9,-81);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 102, 102, 0)];
	this.instance_3.cache(-50,-35,100,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[20.8,-80.9,21.1,-58.6,29.9,-49.2,38.8,-39.6,59.5,-24.8,84.4,-7.1,90.1,-2,104.1,10.9,104.1,23.1,104.1,35.1,99.4,42.3,95.3,48.5,86.8,52.2,81.1,54.7,69.1,57.4,54.5,60.8,48.8,62.6,41.4,65,24.9,67.3,7,69.8,2.4,70.9,-2,71.9,-15.1,80.2,-27.6,88.1,-29.6,88.1,-52.7,88.1,-63.8,73.2,-72,62.1,-72,46.5,-72,40.6,-67.8,35.1,-62.8,28.5,-55.1,28.5,-49.6,28.5,-39.3,31.7,-28.9,34.9,-20.2,34.9,-10.8,34.9,-6.1,32.8,0.3,30,0.3,23.1,0.3,19.4,-9.7,13.3,-15.7,9.6,-31.7,0.1,-63.7,-20.4,-63.7,-44.5,-63.7,-50,-57.3,-54.2,-51.4,-58.2,-45.4,-58.2,-44.6,-58.2,-36.2,-54,-27.8,-49.9,-23.1,-49.9,-17.4,-49.9,-14.2,-57.2,-13,-60,-9.7,-73.2,-7,-84.3,-3.6,-89.3,1.5,-96.6,10.4,-96.6,18.9,-96.6,20.6,-87.5,20.8,-86.3,20.9,-84.6]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-102,-113.7,200.3,158.9);


(lib.anim1_38 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 299
	this.instance = new lib.square8_2("single",0);
	this.instance.parent = this;
	this.instance.setTransform(47.8,34.9);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 255, 153, 0)];
	this.instance.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[47.9,34.9,42.9,40.1,39.1,46,36.1,50.7,30.7,60.4,25.8,68.6,21.7,72.3,16.2,77.3,9.3,77.3,7,77.3,3.9,73.6,0.1,69.1,0.1,63.1,0.1,61.6,1.3,55.6,2.6,49.7,2.6,48.1,2.6,41.5,-6.2,37.6,-14.5,33.8,-28,33.8,-36.1,33.8,-53.9,40,-71.6,46.3,-74.9,46.3,-76.2,46.3,-77.3,43.8,-78.4,41.4,-78.4,38.8,-78.4,27.1,-68.5,17.8,-61.5,11.2,-46.6,3.8,-27.1,-6,-24.8,-7.4,-14.9,-13.5,-14.9,-19.9,-14.9,-30.7,-21.7,-37.4,-26.3,-41.9,-36.7,-46.3,-48.5,-51.3,-51.8,-53.7,-58.6,-58.6,-58.6,-66.6,-58.6,-68,-56.5,-72.7,-53.7,-78.5,-49.9,-83.5,-38.4,-98.4,-23,-98.4,-11.5,-98.4,-4.5,-95.4,1.3,-92.8,5.9,-87.1,6.6,-86.4,14.2,-75.2,19.9,-66.8,26.1,-60.9,33.7,-53.9,42.5,-47.4,51.9,-40.4,53.3,-39.2,57.6,-35.3,59.3,-30.6,61.1,-25.5,61.1,-16.1,61.1,-4,54.9,14.8,50.8,27.1,50.6,27.8,50,29.6,49.6,31.2]}},79).wait(1));

	// Layer 298
	this.instance_1 = new lib.heptagon("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(82.3,-77.2);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 255, 153, 0)];
	this.instance_1.cache(-45,-44,90,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[81.9,-77.1,82,-73.4,84.9,-63.3,87.9,-53,87.9,-49.4,87.9,-34.2,81.2,-25.8,75.9,-19.2,65.1,-15.7,52,-12.5,45.6,-10.8,34.2,-7.7,28.7,-2.6,26.6,-0.7,23.4,10.4,19.2,25.3,16.4,32.2,3.9,61.6,-21.8,61.6,-33.2,61.6,-43.8,52.4,-54.8,42.9,-54.8,32,-54.8,17.2,-45.8,8.6,-39.4,2.4,-26.1,-1.8,-11.8,-5.7,-6.4,-8.1,2.5,-12.1,2.5,-18.9,2.5,-24.7,-4.1,-29.4,-8.1,-32.3,-18.5,-36.8,-29.2,-41.4,-33,-43.9,-39.6,-48.4,-39.6,-53.7,-39.6,-92,-9.9,-92,-4.3,-92,1.1,-89,3.8,-87.5,10.4,-82.3,16.4,-77.6,20.5,-75.6,26.9,-72.6,34.2,-72.6,42.6,-72.6,46.8,-75.7,49.6,-77.8,51.7,-82.7,54,-88,55.8,-89.7,59.1,-92.9,65.9,-92.9,73.8,-92.9,79.8,-82.3,79.9,-82.2,80,-82]}},79).wait(1));

	// Layer 297
	this.instance_2 = new lib.triangle();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-41.2,-49);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 255, 153, 0)];
	this.instance_2.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-41.1,-48.6,-41,-48.6,-40.9,-48.6,-39.9,-48.6,-38.9,-48.7,-31.3,-49.7,-25.2,-58.5,-21.9,-63.1,-13.9,-80.1,-6.8,-95.2,-0.8,-101.8,8.1,-111.6,20.1,-111.6,31.1,-111.6,45.7,-85.6,49.7,-78.5,56,-65.6,61.4,-54.4,63,-52.1,65.3,-48.8,72.1,-44.9,76,-42.9,84.8,-38.1,100.9,-28.3,100.9,-13.1,100.9,-8.5,89.1,-2.4,82.1,1.2,62.6,9,43.1,16.8,35,20.9,21.9,27.7,20.1,33.3,18.4,38.4,18,49.6,16.6,59.6,9.4,65.5,3,70.9,-12.1,76.7,-29.6,83.3,-42.7,83.3,-54.1,83.3,-68.8,70.1,-75,64.4,-78.9,58.6,-83,52.4,-83,48.1,-83,40.8,-76.3,34.6,-71.7,30.2,-61.6,24.8,-49.4,18,-47,16.3,-40.3,11.6,-40.3,7,-40.3,3.4,-44,0.5,-45.5,-0.7,-52.2,-4.5,-57.8,-7.7,-60.4,-10.5,-64.1,-14.6,-64.1,-20.2,-64.1,-31.3,-58.5,-39,-53.7,-45.6,-45.2,-48.3]}},79).wait(1));

	// Layer 296
	this.instance_3 = new lib.heptagon("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(81.9,-77.2);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 255, 153, 0)];
	this.instance_3.cache(-45,-44,90,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[81.8,-77.1,81.9,-77.6,81.9,-77.9,81.9,-90.5,74.2,-95.4,68,-99.3,54.6,-99.3,39.4,-99.3,27.8,-94.4,19.8,-91,10.9,-83.7,-0.2,-74.5,-2.7,-73,-10.4,-68.1,-19.4,-68.1,-24.2,-68.1,-38.2,-71,-52.1,-74,-53.5,-74,-64.3,-74,-77.9,-60.3,-91.6,-46.7,-91.6,-35.9,-91.6,-31,-86.4,-27.3,-83.6,-25.4,-75,-21.5,-66.9,-17.9,-63.6,-15.1,-58.4,-10.8,-58.4,-4.8,-58.4,-0.3,-61.5,4.7,-63.3,7.7,-68.2,13.6,-73,19.4,-74.9,22.4,-77.9,27.5,-77.9,32.2,-77.9,39.5,-76,42.9,-73.7,46.8,-68.2,46.8,-66.3,46.8,-58.5,42,-50.9,37.3,-48.8,37.1]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-89.2,-119.2,214.3,186.9);


(lib.anim1_37 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 291
	this.instance = new lib.ovel_mc();
	this.instance.parent = this;
	this.instance.setTransform(-67.1,10.7);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 211, 102, 153, 0)];
	this.instance.cache(-46,-25,103,54);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-70.1,y:15.5},79).wait(1));

	// Layer 290
	this.instance_1 = new lib.pentagon2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(65.7,-99.5);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 211, 102, 153, 0)];
	this.instance_1.cache(-40,-38,80,76);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[65.8,-99.4,59.6,-93.5,50.1,-89.7,35.9,-83.9,31.6,-83.9,18.4,-83.9,5.2,-88.3,-4,-91.5,-16.5,-98.2,-32.3,-106.6,-35.3,-108,-45.3,-112.4,-52.9,-112.4,-72.8,-112.4,-86.1,-103.8,-100.4,-94.8,-100.4,-79.8,-100.4,-67.8,-86.4,-59.9,-78.1,-55.2,-55.6,-48.5,-33.3,-41.9,-24.8,-36.9,-10.8,-28.9,-10.8,-16.6,-10.8,-9.4,-20.2,-2,-25.4,2.2,-40.7,10.9,-55.4,19.2,-61.3,24.2,-70.6,32.2,-70.6,40.3,-70.6,47,-66.2,50.9,-61.6,55.1,-53.4,55.1,-34.2,55.1,-11.6,43.8,-0.9,38.1,3.6,35.9,11.2,32.4,15.9,32.4,18.5,32.4,30.1,38.8,41.8,45.2,45,45.2,60.3,45.2,65.7,38.2,70.1,32.4,70.1,17.3,70.1,-4.5,57.9,-18.6,54.1,-23.1,46.8,-29,38.4,-35.9,35.9,-38.4,36.5,-41.7,40.1,-44.3,42.5,-46.1,48.4,-48.9,62.4,-55.4,67.3,-61.2,69.9,-64.2,74.7,-75.5,80,-88,80,-93.3,80,-98.5,78.4,-101,76.7,-103.8,72.9,-103.8,72.4,-103.8,69.6,-102.6]}},79).wait(1));

	// Layer 289
	this.instance_2 = new lib.circle("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-28.7,-78.6);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 211, 102, 153, 0)];
	this.instance_2.cache(-38,-38,77,77);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-29.5,-79.2,-27.5,-81.6,-27.2,-82,-21.6,-88.7,-15.9,-96.6,-10.1,-104.6,-0.4,-118.1,7.5,-128.3,15.5,-132.8,25.1,-138.2,38.7,-138.2,52.1,-138.2,61.1,-130.1,70.5,-121.6,70.5,-107.8,70.5,-100.6,67.5,-93.7,65.7,-89.4,61,-82.2,56.2,-74.7,54.5,-71,51.6,-64.4,51.6,-57.9,51.6,-43.6,59.6,-42.4,62.3,-42,68.2,-42.8,75.4,-43.7,78.6,-43.7,91.3,-43.7,97.5,-37,104.2,-29.7,104.2,-13.4,104.2,1,98.8,10.2,93.3,19.6,84,19.6,79.7,19.6,61.9,15.6,44.1,11.5,37.4,11.5,-4.6,11.5,-26.4,19.1,-42.7,24.8,-49.6,35.8,-51.5,39,-53.8,44.7,-56.1,50.3,-57.5,52.5,-62.4,60.1,-75.9,60.1,-86.2,60.1,-95.5,50.7,-104.9,41,-104.9,29.7,-104.9,8.9,-91.4,2,-83.5,-2,-65.1,-2,-53.6,-2,-45.5,-6.1,-37.4,-10.2,-37.4,-16.1,-37.4,-25.1,-51.6,-41.4,-55.1,-45.5,-61.3,-52.6,-65.8,-57.9,-65.8,-59.9,-65.8,-67.4,-60.4,-73.4,-55.5,-78.8,-50.9,-78.8,-48.2,-78.8,-42.7,-76.8,-37.2,-74.8,-36.1,-74.8,-36,-74.8,-35.9,-74.8]}},79).wait(1));

	// Layer 288
	this.instance_3 = new lib.square8_2("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(75.6,-20.6);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 211, 102, 153, 0)];
	this.instance_3.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[75.4,-20.5,75.7,-25.9,76.1,-33,77.6,-56.5,77.6,-57.3,77.6,-89.4,64.3,-104.6,52.6,-117.9,30.8,-117.9,28.5,-117.9,-2.9,-109.9,-34.2,-101.9,-37.6,-101.9,-41.1,-101.9,-49,-103.9,-57,-105.9,-60.9,-105.9,-68.4,-105.9,-77.4,-97.2,-85.3,-89.5,-92.9,-76.6,-99.9,-64.7,-104.5,-52.5,-109,-40.2,-109,-33.2,-109,-13.4,-95.6,-6.2,-85.9,-0.8,-64.2,-0.8,-45.2,-0.8,-34.2,3.3,-19.5,8.7,-19.5,21.2,-19.5,24.5,-26.1,32.7,-29.9,37.4,-40.8,49.2,-51.3,60.6,-55.6,65.9,-62.2,74.4,-62.2,78,-62.2,86.3,-58.2,91.5,-54.2,96.6,-47.5,96.6,-18.9,96.6,0.4,80.8,8.5,74.1,13.1,65.8,17.5,57.9,17.5,50.5,17.5,48.9,16.2,41.2,14.8,33.5,14.8,31.8,14.8,23.1,17.6,18,20.5,12.6,26.1,12.6,34.2,12.6,39,19.7,42,24,45.6,35.3,49.3,46.7,52.2,50.9,56.9,58,64.8,58,80.3,58,89.6,51.2,98.9,44.4,98.9,33.2,98.9,10.6,87.6,-2.8,86.3,-4.3,80.3,-10.3]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-111.6,-135.5,219.9,173.2);


(lib.anim1_36 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 283
	this.instance = new lib.heptagon("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-38.4,26.5);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 175, 0, 0)];
	this.instance.cache(-45,-44,90,88);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[-38.1,26.5,-23.2,37.8,-8.6,58.7,6.1,79.6,14.7,79.6,23.6,79.6,40.4,63.8,54.9,50.2,72.2,28,87.9,7.7,99.2,-10.7,110.6,-29.4,110.6,-35.2,110.6,-51.7,100.3,-63.1,91.1,-73.4,80.3,-73.4,78.5,-73.4,66.3,-72,54,-70.5,52.2,-70.5,33.9,-70.5,9,-85.3,2.7,-89,-8,-95.5,-16.4,-100.1,-21.1,-100.1,-41.1,-100.1,-51.3,-95.6,-63.1,-90.3,-63.1,-78.7,-63.1,-78.1,-60.9,-69.2,-58.8,-60.2,-58.8,-58,-58.8,-53.2,-63.2,-47.5,-66,-43.9,-72.8,-37.4,-80.1,-30.6,-82.5,-27.7,-86.9,-22.3,-86.9,-18.2,-86.9,-11.9,-76.9,-3,-68,5,-57.3,10.2,-48.2,14.6,-42.2,21.6,-41.1,23.1,-40,24.6]}},79).wait(1));

	// Layer 282
	this.instance_1 = new lib.rectangle("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(68.8,-37.1);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 175, 0, 0)];
	this.instance_1.cache(-50,-35,100,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[68.7,-37,72.3,-30.8,74.1,-28,76.8,-20,80.8,-12.3,85.5,-3.5,94.9,9.8,104.5,23.3,107.4,28.8,112.8,38.9,112.8,47.8,112.8,60.4,106.1,68.4,99.3,76.3,88.8,76.3,76.9,76.3,62.9,68.8,54.7,64.4,38.1,52.4,21.8,40.5,13.1,35.9,-1.1,28.4,-13.5,28.4,-21,28.4,-35.9,31.3,-50.8,34.2,-55.6,34.2,-66.8,34.2,-78.1,29.9,-89.8,25.3,-101,12.5,-112.2,-0.4,-104.6,-21.1,-97.1,-41.9,-100.1,-54.5,-103.2,-67.2,-93.3,-67.2,-86,-67.2,-68.7,-61.4,-51.4,-55.7,-46,-55.7,-34.3,-55.7,-24.6,-62.1,-19.8,-65.3,-8.7,-76.2,1.3,-86.1,8.9,-90.4,20.6,-96.8,35.8,-96.8,47.7,-96.8,58.1,-92.2,69.6,-87,69.6,-79.7,69.6,-75.9,66.7,-65.4,63.8,-54.8,63.8,-53.5,63.8,-49.4,67.7,-40.5]}},79).wait(1));

	// Layer 281
	this.instance_2 = new lib.ovel_mc();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-35.4,-58.6);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 175, 0, 0)];
	this.instance_2.cache(-46,-25,103,54);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-35.3,-58.5,-42.4,-42.3,-40.1,-33.3,-37.7,-24.2,-37.7,-19.7,-37.7,-9.5,-50.2,-2.8,-55.9,0.3,-77.4,7.5,-96.4,13.8,-104.8,20,-117.3,29.2,-117.3,43.6,-117.3,58.1,-111.6,68.2,-104.6,80.5,-91.6,80.5,-79.9,80.5,-61,65.1,-53.2,58.7,-47.5,52.2,-41.7,45.6,-40.6,41.7,-29.8,5.7,1,5.7,10.3,5.7,33.1,11.8,56,17.9,66.8,17.9,82.5,17.9,90.1,9.5,96.6,2.2,96.6,-10.4,96.6,-25.6,85.8,-30.2,79.3,-33,62,-32.6,44.7,-32.1,38.3,-34.8,27.5,-39.2,27.5,-54.4,27.5,-65.2,32.2,-75.3,34.7,-80.6,35.5,-83.1,37,-87.9,37,-93.7,37,-102.2,28.4,-108.7,21,-114.4,14.2,-114.4,-14.1,-114.4,-26.3,-89.2,-30,-81.4,-33,-69.3,-34.2,-64.2,-35,-60.9]}},79).wait(1));

	// Layer 280
	this.instance_3 = new lib.triangle();
	this.instance_3.parent = this;
	this.instance_3.setTransform(4.4,-23.7);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 175, 0, 0)];
	this.instance_3.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[4.4,-23.6,3.6,-29.1,0,-32.5,-4.7,-37.1,-13.8,-37.1,-17.8,-37.1,-22.5,-33.4,-28.4,-28.3,-32.3,-25.4,-48.1,-13.9,-73.2,-13.9,-84.3,-13.9,-89.6,-17.4,-95.3,-21.1,-95.3,-29.6,-95.3,-41.2,-68.4,-57.6,-57.7,-64.2,-47,-68.7,-36.3,-73.1,-31.2,-73.2,-14.8,-73.4,-7.2,-80.2,-2.5,-84.3,1.2,-95,5.1,-105.7,9.4,-109.6,16.7,-116.3,32.5,-116.3,53.8,-116.3,68.6,-101.2,82.7,-86.9,82.7,-68.6,82.7,-55.8,75.7,-40.9,71.7,-32.5,70.8,-30.1,68.6,-24.3,68.6,-19.1,68.6,-14,72.5,-6.7,73.9,-4,80.9,7.2,86.7,16.5,89.3,22.8,93.2,31.9,93.2,40.1,93.2,47.3,88.1,56.7,83,66.1,77,68.1,71.1,70.2,58.7,69.5,46.3,68.9,27.4,76.3,17.9,80,11.9,80.1,6,80.2,3.6,76.8,-1.2,69.9,-5.1,52.2,-9,34.5,-1.9,11.9,5,-10.3,4.2,-21.2]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-81.1,-81.6,198,150.1);


(lib.anim1_35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 275
	this.instance = new lib.hexagon2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(34.2,-2.5);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 178, 204, 0)];
	this.instance.cache(-50,-44,101,88);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[34.2,-2.5,36.5,-3.4,40.8,-4.4,46.6,-5.8,48.6,-7,48.7,-7.1,48.7,-7.1,50.6,-8.3,52.8,-9.5,66.8,-17.2,68.3,-18.2,77,-23.8,81.4,-30.9,86.9,-39.8,86.9,-52.5,86.9,-57.8,80.5,-65.6,74.8,-72.5,65.3,-79.8,56.4,-86.8,47.7,-91.3,38.6,-96,33.8,-96,28.9,-96,24.5,-89.4,19.9,-81,17.6,-77.6,14.2,-72.7,5.7,-69.8,-1.6,-67.3,-10.7,-66.8,-14.1,-66.6,-22,-64.3,-30.2,-61.9,-38.2,-58.5,-59.2,-49.7,-59.2,-42.9,-59.2,-41.6,-57.4,-40.4,-55.5,-39.1,-51.9,-38,-41.8,-35.6,-36,-34.2,-25.4,-31.5,-20.2,-28.2,-12.9,-23.8,-12.9,-17.2,-12.9,-8.3,-22.1,-1.1,-26.5,2.4,-42.2,10.8,-56.2,18.2,-62.3,24.2,-71.4,33.3,-71.4,45.4,-71.4,52.3,-66.9,55.4,-62.4,58.5,-53,58.5,-36.5,58.5,-11.7,37.6,-4.3,31.4,5.3,21.9,14.1,13.3,15.3,12.3,15.8,11.9,23.7,5.3,29.3,0.7,31.6,-1]}},79).wait(1));

	// Layer 274
	this.instance_1 = new lib.triangle("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(43.4,-55.6);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 178, 204, 0)];
	this.instance_1.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[43.4,-55.5,43.4,-55.9,43.3,-56.2,43.2,-57.3,43.3,-58.4,43,-63.9,41.3,-68.4,35.3,-84.5,13.1,-84.5,1,-84.5,-11.2,-80.1,-23.7,-75.7,-32.8,-68.1,-42.6,-60,-46.1,-50.2,-49.8,-39.5,-45.2,-28.4,-48.6,-16.4,-58.1,-7.6,-61.7,-4.3,-76.1,5.8,-87.3,13.6,-92.1,20.7,-99.1,30.9,-99.1,46.1,-99.1,63.4,-86.8,70.1,-78.3,74.6,-62.2,74.6,-55.5,74.6,-45.3,67.4,-32.6,57.3,-25.3,51.6,-11.8,40.9,-1.3,35.7,13.4,28.5,27.7,28.5,32.8,28.5,48.3,32.7,63.7,36.9,71.1,36.9,80.4,36.9,87.6,27.7,94.6,19,94.6,9.6,94.6,-1.5,87.3,-8.3,83.8,-11.6,70.7,-18.9,58.9,-25.4,53.2,-32.1,46.6,-40,44.2,-51.5,43.9,-52.1,43.8,-52.6]}},79).wait(1));

	// Layer 273
	this.instance_2 = new lib.triangle("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-10.1,-56.1);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 178, 204, 0)];
	this.instance_2.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-10,-56,-9.5,-56.1,-9,-56.3,2.1,-59.5,8.8,-64.4,15.1,-68.7,19.8,-76.9,24.4,-85.1,27.9,-87.6,34.2,-92.1,48.2,-92.1,60.6,-92.1,69.2,-87.6,80,-82.1,80,-70.7,80,-67.1,75.9,-61.7,74.9,-60.2,66.9,-51,53.7,-35.7,53.7,-25.3,53.7,-20.9,59.7,-16.3,60.8,-15.5,73,-8.1,81.9,-2.6,86.2,2.3,92.2,9.2,92.2,17.6,92.2,32.9,82.9,44.5,71.9,58.3,52.9,58.3,49.2,58.3,43.5,55.9,36.3,52.5,32.1,50.6,15.3,43,0.6,43,-12.9,43,-39.6,53.7,-46.3,56.4,-57.6,61.1,-66.1,64.5,-69,64.5,-75,64.5,-82.1,60.7,-89.1,57,-95.2,50.7,-109.1,36.5,-109.1,21.5,-109.1,16,-101.9,12.5,-97.6,10.4,-86,7.5,-74.5,4.6,-70.1,2.4,-62.8,-1.2,-62.8,-7,-62.8,-11.3,-72,-22.2,-81.2,-33.2,-81.2,-37.5,-81.2,-48.3,-72.1,-53.9,-64.9,-58.2,-54.5,-58.2,-46.5,-58.2,-35.7,-54.5,-24.9,-50.7,-20.6,-50.7,-17,-50.7,-14.4,-52.9,-13.9,-53.5,-13.3,-54.1]}},79).wait(1));

	// Layer 272
	this.instance_3 = new lib.square8_2("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-41.8,1.1);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 178, 204, 0)];
	this.instance_3.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[-41.7,1.1,-29,7.9,-22.3,21.4,-18,30,-13,52.7,-8.7,72.5,-2.8,80.3,6.1,92.2,25.2,92.2,42.9,92.2,56.8,76.9,62.5,70.5,65.9,63.1,69.2,55.9,69.2,50,69.2,43.1,56.1,24.3,48.6,13.5,47.1,11.2,43,4.7,43,2.1,43,-5,54.8,-9.5,59.1,-11.2,66.9,-13.2,71.3,-14.3,80.7,-16.7,98.2,-21.3,106.6,-27.4,118.4,-35.8,118.4,-49.8,118.4,-72,100,-83,87.3,-90.5,72.9,-90.5,66.2,-90.5,60.2,-86.7,56.2,-84.1,50.4,-78.2,44.1,-71.7,41.5,-69.8,36.4,-65.9,31.4,-65.9,25,-65.9,18,-69.1,15.8,-70,5.2,-76,-3.3,-80.7,-10.1,-82.9,-19.8,-86.1,-30.7,-86.1,-43.3,-86.1,-53.7,-83,-67.5,-78.9,-67.5,-71.3,-67.5,-70.8,-61.3,-64.4,-55.1,-58,-55.1,-57.6,-55.1,-51.9,-61.8,-44.3,-65.9,-39.8,-76.7,-30.6,-87.5,-21.3,-91.5,-16.8,-98.3,-9.3,-98.3,-3.7,-98.3,-1.6,-95.2,0.4,-92.1,2.5,-85.9,4.4,-76,7.6,-72.1,7.6,-64.1,7.6,-57.2,4.5,-56.4,4.1,-44.6,0.3]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74.6,-97.6,166,137.1);


(lib.anim1_34 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 267
	this.instance = new lib.square8_2("single",0);
	this.instance.parent = this;
	this.instance.setTransform(-19.5,43.4);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 153, 0, 102, 0)];
	this.instance.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[-19.5,43.4,-16.5,43.9,-14.4,44.3,-12.2,44.7,-9.8,45.3,-2,48.1,8.8,53,18.2,56.6,28.7,56.6,40.5,56.6,48,51.6,55.3,46.7,55.3,39.2,55.3,28.9,47.6,22.2,42.5,17.7,30.7,12.6,17.7,7.1,13.7,4.4,6,-1.1,6,-9.2,6,-17.3,16,-24.2,20.9,-27.7,38,-35.9,53.4,-43.3,60,-48.9,70,-57.5,70,-68.2,70,-99.6,36.9,-118.1,23.8,-125.4,7.5,-129.3,-7,-132.9,-19.7,-132.9,-28.7,-132.9,-40.4,-128.5,-52.1,-124.1,-62.5,-116.8,-73.7,-109,-80.1,-100.1,-87.2,-90.1,-87.2,-80.5,-87.2,-74.4,-82.8,-70,-79.8,-67,-73.1,-63.6,-65.3,-59.8,-63.4,-58.4,-59,-55.1,-59,-51,-59,-45.2,-67.6,-39.1,-72.8,-35.6,-86.6,-27.5,-99.3,-19.4,-105.6,-10.7,-114.3,1,-114.3,16.6,-114.3,23.7,-98.3,34.4,-92.3,38.5,-86.3,41.4,-80.6,44.2,-78.7,44.2,-67.9,42.9,-57.5,41.7,-46.8,40.6,-36.3,40.9,-36,40.9,-35.7,41,-27.2,42.2,-21.9,43]}},79).wait(1));

	// Layer 266
	this.instance_1 = new lib.heptagon("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-69.3,-45.6);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 153, 0, 102, 0)];
	this.instance_1.cache(-45,-44,90,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-69.2,-45.5,-59.8,-49,-49.3,-57.8,-44.2,-62,-26.5,-79.4,-12.3,-93.4,-2.9,-99.4,10.7,-108.1,23.9,-108.1,31.4,-108.1,36.8,-104.4,43,-100.4,43,-93.4,43,-89.1,28.2,-63.9,13.4,-38.7,13.4,-32.6,13.4,-21.5,25.7,-15.5,30.4,-13.2,38.3,-10.8,43,-9.5,52.8,-6.9,71.4,-1.6,79.8,5,92.2,14.7,92.2,31.8,92.2,40.2,87.3,44.2,82.8,47.9,73.7,47.9,65.3,47.9,57.4,43.5,52.6,40.9,44.2,33.8,35.7,26.7,31,24,23.1,19.6,14.6,19.6,2.6,19.6,-9.8,28.1,-18.7,34.1,-30.6,46.7,-46.4,63.4,-48.6,65.4,-57.9,73.8,-64.4,73.8,-73.2,73.8,-81.2,66.5,-88.5,59.8,-88.5,54.1,-88.5,49,-83.5,45.2,-81.3,43.5,-72.5,39,-64.9,35.1,-61.5,31.6,-56.5,26.4,-56.5,19,-56.5,13.2,-68.8,-8,-81.2,-29.1,-81.2,-33.8,-81.2,-38.5,-77.5,-41.6,-74.7,-43.9,-72.3,-44]}},79).wait(1));

	// Layer 265
	this.instance_2 = new lib.hexagon2("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(27.7,-78.5);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 153, 0, 102, 0)];
	this.instance_2.cache(-50,-44,101,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[27.7,-78.4,31.7,-75,35.3,-73.6,39.4,-72,41.9,-72,44.4,-71.9,45.2,-73.5,49.9,-76.1,52.8,-76.1,70.7,-76.1,81.3,-71.1,98.4,-63.1,98.4,-42.4,98.4,-26.7,88.1,-16.6,79.9,-8.6,63.9,-3.3,59.6,-1.8,36.4,4.2,21.2,8.2,15.9,12.2,13.5,14.1,10.9,26.1,6.9,43.7,4.9,49.9,-5.6,82.6,-31.3,82.6,-41.5,82.6,-49.1,76.3,-57.7,69.3,-57.7,57.9,-57.7,51.7,-55.2,39.2,-52.7,26.8,-52.7,24,-52.7,15.3,-59.2,5.1,-61.5,1.5,-73.6,-13.9,-83.4,-26.5,-88,-36,-94.5,-49.5,-94.5,-63.8,-94.5,-78.3,-89.7,-87.2,-83.7,-98.3,-71.3,-98.3,-62.3,-98.3,-50,-87.8,-43.1,-81.9,-41.2,-80.6,-36.6,-77.4,-33,-77.4,-22.2,-77.4,-6.5,-84.8,1.8,-88.7,4.8,-89.9,11.2,-92.2,16.4,-92.2,21.4,-92.2,24.2,-84.5,24.9,-82.5,26,-80.8]}},79).wait(1));

	// Layer 264
	this.instance_3 = new lib.square8_2("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(49.9,3.4);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 153, 0, 102, 0)];
	this.instance_3.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({y:1.7},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-112,-120.5,194.7,196.7);


(lib.anim1_33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 259
	this.instance = new lib.hexagon2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(32.4,15.9);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 204, 204, 0)];
	this.instance.cache(-50,-44,101,88);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[32.5,15.9,33.7,14.7,34.9,13.7,36.5,12.2,38.1,10.8,46.5,2.8,52.7,-5.7,71.8,-31.7,71.8,-63.4,71.8,-81.2,66.8,-91.7,61.3,-103.1,51,-103.1,47.4,-103.1,41.2,-101.3,41,-101.2,29,-97.3,11.3,-91.6,-1,-91.6,-16,-91.6,-41.2,-97.9,-47.6,-99.4,-57.9,-102.2,-65.5,-104.1,-67.5,-104.1,-86,-104.1,-100.9,-91.6,-116.5,-78.5,-116.5,-60.3,-116.5,-46.2,-103.8,-40.2,-96.6,-36.8,-75.8,-33.9,-55.9,-31,-47.9,-26.7,-35.2,-19.9,-35.2,-4.2,-35.2,0.4,-37.5,6,-38.7,8.9,-42.5,16,-49.8,29.5,-49.8,38.1,-49.8,49,-44.6,53.2,-39.5,57.2,-26.4,57.2,-6.9,57.2,3.9,47.1,11.2,40.2,16.1,26,17.3,22.4,18.6,20.9,19.9,19.3,21.3,19.8,24,20.7,28.2,19.6,28.3,19.5,28.4,19.5,29,19.3,29.6,19]}},79).wait(1));

	// Layer 258
	this.instance_1 = new lib.hexagon2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(57.8,-43.6);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 204, 204, 0)];
	this.instance_1.cache(-50,-44,101,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[57.7,-43.5,47.8,-42.4,44.3,-25.7,42.9,-19.2,42.1,-7.5,41.2,6.4,40.6,13.6,38.4,40.3,31.9,52.9,22.8,70.8,2.4,70.8,-11.7,70.8,-30.4,60.6,-47.9,51.1,-64.5,35.4,-81.1,19.6,-91.2,3,-102,-14.9,-102,-28.5,-102,-50.9,-91.7,-63.4,-80.6,-76.9,-59.2,-76.9,-50.5,-76.9,-44.7,-73.8,-40.8,-71.8,-36.6,-67,-31.8,-61.7,-29.8,-60.2,-25.4,-57.1,-19.2,-57.1,-6,-57.1,4.3,-65.6,10.2,-70.4,21.1,-84.2,31.4,-97.5,38.7,-102.9,50.1,-111.3,64.9,-111.3,75.4,-111.3,82.2,-108.4,90.5,-104.8,90.5,-97.8,90.5,-96.6,87.4,-89.1,84.3,-81.6,84.3,-79,84.3,-74.2,86.6,-71.3,88.1,-69.4,91.6,-67.5,95.6,-65.4,96.6,-64.4,98.9,-62.3,98.9,-58.7,98.9,-50.3,94,-46.7,90.3,-43.9,82.3,-43.4,72.6,-43.3,67.9,-42.9,65.8,-42.8,63.4,-43.2]}},79).wait(1));

	// Layer 257
	this.instance_2 = new lib.triangle("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-45.7,-40.2);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 204, 204, 0)];
	this.instance_2.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-45.7,-40.5,-40.3,-40.9,-34.7,-44.3,-26.8,-48.8,-18.4,-59,-10.5,-68.6,-3,-81.1,7.6,-94.1,17,-100.3,27.4,-107.3,38.4,-107.3,49.1,-107.3,59.3,-97.8,68.7,-89,68.7,-81.7,68.7,-73.5,62.9,-67.7,60.3,-65.2,50,-58.7,41,-53.1,37,-47.7,31.2,-39.8,31.2,-28,31.2,-17.3,39,-7.7,43.9,-1.6,56.2,7.9,69,18,73.4,22.9,81.2,31.6,81.2,41.1,81.2,48.3,71.8,58.3,61.9,68.8,53,68.8,46.9,68.8,35.9,62.9,33.8,61.7,14.1,50,-0.5,41.3,-10.4,37.1,-24.5,31.2,-35.9,31.2,-49,31.2,-60.4,38.5,-63.2,40.4,-67.9,43.5,-71.6,45.8,-74.3,45.8,-82.5,45.8,-88.5,37.6,-94.7,29.1,-94.7,16.6,-94.7,-21.9,-68,-34,-61.4,-37,-48.1,-40.5]}},79).wait(1));

	// Layer 256
	this.instance_3 = new lib.square8_2("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-70.3,-1.1);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 204, 204, 0)];
	this.instance_3.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:-71.4,y:-2},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-103.1,-85.6,209.1,143.6);


(lib.anim1_32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 251
	this.instance = new lib.octagon6("single",0);
	this.instance.parent = this;
	this.instance.setTransform(-38.7,10.7);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 242, 248, 16, 0)];
	this.instance.cache(-44,-44,88,88);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[-38.6,10.7,-31.9,17.7,-28.1,28.3,-24.2,40.7,-19.1,52.2,-8.9,75,-1.6,75,6,75,10.8,68.3,13.3,64.8,18.1,53.3,22.6,42.6,26.7,37.8,33,30.5,43,29.5,75,26.5,86.7,19.9,100.9,11.9,100.9,-7.9,100.9,-26.4,80.5,-33.4,68.3,-37.6,38.1,-39.2,22.2,-40.1,14.8,-51.1,10.6,-57.3,6.5,-74.7,2.4,-91.2,-2.8,-97.7,-11.1,-108.1,-28.8,-108.1,-37.8,-108.1,-47.4,-104.2,-57.1,-100.3,-65.1,-93.3,-83.4,-77.2,-83.4,-55.2,-83.4,-39.4,-79.1,-31.3,-76.1,-25.5,-68.3,-20.6,-57.3,-13.7,-54,-10.7,-46.7,-4,-41.3,6.8]}},79).wait(1));

	// Layer 250
	this.instance_1 = new lib.hexagon2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(45.8,2.7);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 242, 248, 16, 0)];
	this.instance_1.cache(-50,-44,101,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[45.7,2.7,54.4,-4.9,58.8,-10.1,73.7,-27.6,73.7,-43.4,73.7,-68.9,56.5,-85.9,39.2,-103.1,12.8,-103.1,-8.8,-103.1,-18.5,-89.6,-25.1,-80.4,-28.2,-59.5,-30.6,-43.8,-30.7,-43.5,-32.3,-34.8,-34.6,-29.5,-40.6,-15.9,-55.8,-15.9,-60.7,-15.9,-74.6,-19.5,-88.6,-23.2,-89.7,-23.2,-92.7,-23.2,-98.4,-21.7,-105,-19.9,-110.8,-17.1,-126.6,-9.3,-126.6,1.2,-126.6,14.2,-116.8,28.3,-106.6,42.9,-96,42.9,-92.2,42.9,-70.9,32.5,-49.6,22.1,-42.4,22.1,-25.7,22.1,-17.5,33.8,-11.9,42.1,-9,59.7,-8.3,64.4,-6.9,73.4,-5.6,81,-4,85.4,0.1,97.1,10.3,97.1,30.2,97.1,41.7,89.9,55.3,81.1,55.3,63.2,55.3,46.5,48.5,30.6,45.1,23.1,43.8,19.9,41.7,14.7,41.7,11,41.7,9.7,44,4.5]}},79).wait(1));

	// Layer 249
	this.instance_2 = new lib.triangle("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-26.3,-71.9);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 242, 248, 16, 0)];
	this.instance_2.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-26.2,-71.8,-22.6,-72.9,-18.7,-74.6,-11.5,-77.7,2.9,-85.8,17.3,-94,24.5,-97,36.3,-102.1,45.3,-102.1,56.1,-102.1,62.2,-97.2,67.7,-92.9,67.7,-86.5,67.7,-73.9,61.2,-64.4,57,-58.2,46.7,-49.9,35.9,-40.9,32.3,-36.4,25.8,-28,25.8,-17.5,25.8,-6.2,35.2,0.6,42.6,6.1,50.4,6.1,57.7,6.1,72.1,-0.6,86.3,-7.3,88,-7.3,92.5,-7.3,94.9,-3.1,96.7,0.1,96.7,3.6,96.7,9.3,92.5,16.6,88.1,24.2,80.6,30.7,62.6,46.7,39.6,46.7,30.9,46.7,21.2,43.4,15.7,41.6,3.8,36.2,-7.4,31.1,-14,29,-24.5,25.8,-34.4,25.8,-45,25.8,-49.1,30.7,-52.8,35.1,-52.8,45.1,-52.8,46.6,-51.6,63.9,-51.6,75.8,-55.9,83.1,-60.2,90.4,-67.3,90.4,-74.6,90.4,-82.1,83.6,-89.2,77.3,-95.3,66.5,-101.1,56,-104.6,44.1,-108.2,31.8,-108.2,21.5,-108.2,2.1,-100.8,-1.2,-97.9,-2.5,-92.3,-2.3,-85.1,-1.8,-81.1,-1.8,-70.1,-1.8,-64.2,-4.3,-58.6,-6.4,-55.9,-11.5,-53.7,-15.6,-52.3,-24,-51.5,-29.1,-49.6,-41.8,-47.4,-54.8,-34.2,-65.9,-33.6,-66.4,-28.1,-70.7]}},79).wait(1));

	// Layer 248
	this.instance_3 = new lib.square8_2("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(25.9,-74.2);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 242, 248, 16, 0)];
	this.instance_3.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[25.9,-74.2,27.3,-72.2,28.1,-71.5,33.1,-66.8,41.8,-63.7,42.1,-63.5,57.7,-59,67.2,-56.1,72.5,-52.7,81.5,-46.8,90.5,-27.3,99.7,-7.2,99.7,7.8,99.7,15.9,96.1,27.8,92.8,39.2,87.3,50.3,81.8,61.7,76.1,68.7,69.9,76.2,65.2,76.2,59.6,76.2,55.3,74.3,53.5,73.5,48.3,70.1,38.9,63.9,25.2,63.9,17.4,63.9,8,67.1,2,69.2,-8.7,74.3,-20,79.7,-24.9,81.5,-33.7,84.8,-40.5,84.8,-49.2,84.8,-65.8,82.1,-82.1,79.5,-87.2,77.5,-91.9,75.6,-100.8,58.4,-109.4,41.8,-109.4,36.8,-109.4,27.8,-100.8,20.8,-93.2,14.6,-85.9,14.6,-82.9,14.6,-76.7,17.1,-70.4,19.6,-69.4,19.6,-59.5,19.6,-50.3,9.8,-41.6,0.4,-41.6,-8.5,-41.6,-16.6,-57.6,-30.2,-66.8,-38.1,-68.6,-39.8,-73.6,-44.8,-73.6,-47.9,-73.6,-58.3,-63.8,-59,-60.8,-59.2,-55.4,-58.5,-49.4,-57.7,-47.8,-57.7,-42.2,-57.7,-37.2,-62.5,-34.4,-65.2,-28.8,-73.1,-23.5,-80.6,-19.9,-83.7,-14.4,-88.5,-7.8,-88.5,-3.4,-88.5,11.3,-82.3,19.2,-79,23.3,-76.9]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-80.5,-113.4,174.5,165.9);


(lib.anim1_31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 243
	this.instance = new lib.hexagon2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(37.6,0.6);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 51, 0, 0, 0)];
	this.instance.cache(-50,-44,101,88);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[37.6,0.6,37.1,-0.3,36.2,-1.5,33.5,-4.8,31.9,-6.9,25.8,-15.5,25.8,-24.2,25.8,-32.6,36.3,-42.1,47.6,-52.3,61.5,-54.1,75.5,-55.8,92.6,-66.9,110.1,-78.3,110.1,-86.4,110.1,-101.3,82.4,-110.1,73,-113.1,61.9,-114.9,53.3,-116.2,49.2,-116.2,35.6,-116.2,25.9,-111.1,14.7,-105.3,7.4,-92.2,-2.8,-74.2,-7.5,-67.3,-15.5,-55.3,-24.5,-47.3,-31.8,-40.8,-45.4,-35,-63.4,-27.3,-67.1,-25.2,-78.5,-18.6,-84.1,-8.4,-91,4.2,-91,24.9,-91,56,-78.1,68.3,-68.4,77.5,-48.9,77.5,-35.3,77.5,-21.6,67.6,-11.2,60.1,2,44.4,16.5,26.1,23.7,17.8,27.3,13.5,30.7,10.1,31.7,8.9,32.8,7.9,35.1,5.6,37.7,2]}},79).wait(1));

	// Layer 242
	this.instance_1 = new lib.heptagon("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(17.2,-69.2);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 51, 0, 0, 0)];
	this.instance_1.cache(-45,-44,90,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[17.2,-69.2,17.2,-69.2,17.4,-69.1,19.1,-68.1,21,-67.1,39.9,-57,63.3,-53.5,85.6,-50.1,98.2,-44.9,116.8,-37.1,116.8,-24.5,116.8,-13.4,108.3,-3.6,98.7,7.3,84.9,7.3,66.6,6.1,65.1,6.1,50,6.1,41.7,7.1,32,8.2,25.4,11.2,18.6,14.2,12.6,20.3,7.2,25.8,0.1,36.3,-6.1,45.3,-21.8,55.3,-39.2,66.4,-51,66.4,-61,66.4,-70.6,61.5,-80.3,56.5,-87.9,47.4,-105.1,26.7,-105.1,-5.2,-105.1,-25.9,-88.5,-34.4,-76.6,-40.6,-55,-40.6,-38,-40.6,-28.7,-45.6,-22,-49.2,-17.9,-56.5,-17.7,-57,-15,-62.4,-13.4,-65.7,-12,-67.5,-8,-72.5,0.1,-72.5,5.8,-72.5,10,-71.7,13.3,-71.1,15.3,-70.4]}},79).wait(1));

	// Layer 241
	this.instance_2 = new lib.octagon6("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-64.5,-37.6);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 51, 0, 0, 0)];
	this.instance_2.cache(-44,-44,88,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-64.4,-37.6,-59.5,-44.9,-53.6,-57.3,-42.9,-79.9,-42.9,-86.7,-42.9,-88.7,-45.1,-95.6,-47.3,-102.5,-47.3,-104.2,-47.3,-111.4,-38.1,-114.4,-32.3,-116.2,-24,-116.2,-10.5,-116.2,-4.8,-111.4,0,-107.2,0,-98.1,0,-95.9,-1.2,-84,-2.4,-72.1,-2.4,-67.6,-2.4,-57,2.5,-49.7,7,-43,12.5,-43,16.8,-43,29.8,-50.7,42.8,-58.4,47.6,-58.4,50.7,-58.4,55.9,-55.3,60.9,-52.2,60.9,-50.7,60.9,-45.2,53.2,-41,49.3,-38.9,36.2,-34.2,24.4,-30,19.3,-26.6,11.6,-21.4,11.6,-14.3,11.6,-10.2,17.2,-4.9,24.2,1.8,34.5,1.8,37.9,1.8,57.4,0,76.9,-1.8,81.7,-1.8,87.7,-1.8,92.2,3.1,98.4,9.5,98.4,22.1,98.4,29.7,94.9,40.8,91.1,52.9,84.9,63.5,69,90.5,48.9,90.5,37.3,90.5,21.7,81.1,7.8,72.7,0.6,63.5,-2.6,59.2,-4.5,53.7,-5.2,51.5,-6.8,44.7,-7.9,40,-9.2,38,-11,35.4,-14.7,35.1,-16.9,34.9,-35.2,34.5,-48.4,34.3,-56,32.5,-78.7,27.3,-78.7,3.9,-78.7,-8.7,-75.4,-16.6,-72,-23.9,-69.9,-27.1,-67.7,-30.3,-65.9,-36.3]}},79).wait(1));

	// Layer 240
	this.instance_3 = new lib.square8_2("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-14.8,49.8);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 51, 0, 0, 0)];
	this.instance_3.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[-14.7,49.8,13.8,54.1,22.6,55.5,38.6,57.9,47.2,57.9,63.6,57.9,72.5,55.4,86.1,51.7,86.1,41.9,86.1,30.2,72.1,15.6,63,6.1,62.7,5.8,58.6,0.8,58.9,-2.3,59.6,-3,59.4,-4.1,58.9,-6.2,58.9,-7.3,58.9,-14.4,65.9,-20.8,70.1,-24.6,81.1,-31.3,92.3,-37.9,96.3,-41.7,103.3,-47.8,103.3,-54.5,103.3,-68.1,91,-76.1,81.4,-82.4,71.9,-82.4,68.9,-82.4,65,-79.9,60.2,-76.3,57.5,-74.3,46.6,-66.3,36.1,-66.3,25.7,-66.3,17.9,-71.6,12.8,-75.1,6,-83.5,-1.4,-92.4,-5.1,-95.3,-12,-100.8,-20.8,-100.8,-38.2,-100.8,-43.3,-93.8,-45.2,-91.2,-45.9,-86.7,-46,-86.1,-46.4,-78.6,-47.2,-67.9,-53.1,-63.4,-61.9,-56.4,-85.9,-56.4,-98.6,-56.4,-108.2,-51.4,-108.4,-51.4,-108.6,-51.2,-114.3,-48.2,-116.6,-44.2,-118,-41.9,-118,-39.2,-118,-37.4,-116.6,-35.4,-115.4,-33.7,-113.2,-31.8,-112.4,-31.3,-108.6,-28.4,-106.2,-26.8,-102.6,-24.2,-95.4,-19.1,-92,-15.2,-87.2,-9.6,-87.2,-3.8,-87.2,-1.4,-92.7,6,-98.3,13.4,-98.3,17.8,-98.3,26.8,-92.2,32.1,-86.5,36.8,-77.4,36.8,-74.2,36.8,-68,32.6,-61.9,28.2,-59.5,28.2,-58,28.2,-52.1,31.6,-40.3,38.4,-38.4,39.4,-27.4,45.3,-17.2,49]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-106.3,-111.2,192.1,193.8);


(lib.anim1_30 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 234
	this.instance = new lib.octagon6("single",0);
	this.instance.parent = this;
	this.instance.setTransform(-32.4,33.3);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 202, 11, 11, 0)];
	this.instance.cache(-44,-44,88,88);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[-32.3,33.4,-29.1,38.3,-27.4,40.4,-20.1,49.2,-12.9,51.6,-7.3,53.5,-1.4,57.1,2,59.1,8.2,63.1,19.6,70.1,32.3,70.1,34.7,70.1,39.1,68.8,44.6,67.3,49.2,64.7,62.3,57.2,62.3,45,62.3,32.7,54.2,26.1,50.2,23.2,48.7,21.7,46.1,19.1,46.1,15.8,46.1,11.5,56.9,3.9,62.4,0,64.3,-1.8,67.7,-5,67.7,-7.6,67.7,-16.1,57.6,-22.8,47.2,-29.9,32.7,-29.9,28.7,-29.9,16.3,-22.9,3.9,-16,-3,-16,-8.5,-16,-13.2,-27.3,-16,-34.1,-22.2,-52.2,-28.6,-68.7,-36.4,-77.1,-46.9,-88.4,-62.2,-88.4,-72.3,-88.4,-81.3,-80.6,-91.4,-72.1,-91.4,-60.2,-91.4,-51.5,-84.6,-41,-80.3,-34.5,-68.3,-20.6,-55.2,-5.5,-49,3.3,-40.8,14.7,-35.7,26.1,-34.7,28.3,-33.8,30.6]}},79).wait(1));

	// Layer 233
	this.instance_1 = new lib.heptagon("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(46.2,-57.1);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 202, 11, 11, 0)];
	this.instance_1.cache(-45,-44,90,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[46.2,-57,54.1,-51.3,59.1,-47.6,71.5,-38.4,77.6,-30.7,86,-19.9,86,-8.3,86,2.8,73.8,11.5,61.8,20,47.6,20,45.6,20,34.7,18.9,23.9,17.7,18.8,17.7,-1.7,17.7,-12.9,25.8,-15.8,28,-22.4,34.2,-28.7,40.3,-33.7,43.8,-35.5,45.1,-43.9,52.2,-52.8,59.7,-59,64.3,-80.1,80,-92.6,80,-113.9,80,-126.9,56.2,-132.1,46.7,-134.9,35,-137.5,24.4,-137.5,15.3,-137.5,-11.5,-124.5,-26,-112.8,-39,-93.7,-39,-87.6,-39,-73.8,-34.8,-60.1,-30.6,-52.6,-30.6,-36.1,-30.6,-26.9,-36.4,-20.4,-40.5,-16,-49.1,-14.8,-51.4,-12.6,-55.8,-10.7,-59.6,-9,-61.8,-4.3,-67.5,4.5,-67.5,10.6,-67.5,25,-64.1,34.4,-61.8,44.6,-58.4]}},79).wait(1));

	// Layer 232
	this.instance_2 = new lib.triangle("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-32.7,-48.7);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 202, 11, 11, 0)];
	this.instance_2.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-32.6,-48.6,-53.3,-50,-57.3,-45.9,-61.2,-41.9,-69.8,-41.9,-77,-41.6,-81.2,-39.8,-90.7,-35.7,-95.7,-32.5,-101.8,-28.6,-105.2,-23.7,-112,-13.9,-112,9.3,-112,16.1,-109.8,25.7,-107.3,36.8,-103,46.1,-91.5,70.7,-73.7,70.7,-65.3,70.7,-57.8,67.1,-54.9,65.7,-44.9,59.2,-36.5,53.7,-29.4,51.2,-19.1,47.6,-6.2,47.6,5.2,47.6,13.6,54.1,18.6,57.9,26.7,68.4,34.7,78.6,40.3,82.6,49.3,89.1,56.4,73.8,63.6,58.5,77.8,61.4,91.9,64.2,92.9,51.4,93.8,38.5,81,28.2,71.7,20.6,53,17.7,32.6,15.7,25,13.9,12.2,10.9,12.2,2.1,12.2,-6.8,21.4,-17.8,27.7,-25.4,41.5,-37.1,58.4,-51.5,61.6,-54.6,70.7,-63.6,70.7,-69.1,70.7,-73.6,61.4,-78.3,52.6,-82.8,45.9,-82.8,33.9,-82.8,24,-77.6,18.8,-74.8,8,-66,-2,-57.8,-9.5,-54.4,-18.4,-50.3,-29.5,-49.4]}},79).wait(1));

	// Layer 231
	this.instance_3 = new lib.square8_2("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(48.9,11.2);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 202, 11, 11, 0)];
	this.instance_3.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[49.4,11.2,49.5,22.2,48.9,29.5,47.5,45.8,40.9,59.8,32.7,77.3,17.9,87.3,0.1,99.3,-25.8,99.3,-47.2,99.3,-53.3,74.8,-54.8,68.5,-56.3,54.8,-57.6,43,-59.2,39.2,-63.3,28.9,-73,21.3,-77.2,17.9,-91.2,9.8,-102.3,3.3,-107,-2.1,-113.7,-10,-113.7,-21.4,-113.7,-39.2,-102.3,-47.4,-95.2,-52.4,-77.2,-56.2,-58.6,-60.1,-52.1,-64.3,-40.7,-71.6,-40.7,-88,-40.7,-89.3,-42.6,-98,-44.5,-106.7,-44.5,-107.2,-44.5,-112.6,-36,-116.1,-28.6,-119.2,-19.6,-119.2,1.3,-119.2,15,-110.2,31.1,-99.6,26.8,-81.4,24.2,-70.5,28.5,-60.2,32.2,-51.1,39.9,-45.3,46.7,-40.1,49.3,-31.3,51.4,-23.9,51.4,-10.3,51.4,-2.7,49.9,4.6,49.7,5.3,49.6,6]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-80.7,-99.1,169.7,174.1);


(lib.anim1_29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 226
	this.instance = new lib.hexagon2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(37.3,-8.2);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 142, 146, 97, 0)];
	this.instance.cache(-50,-44,101,88);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[37.3,-8.2,30.8,4.7,23.6,8.8,16.4,13,12.1,14.9,7.9,16.9,0.5,16.9,-27.6,16.9,-50.3,-12.4,-54.6,-17.9,-61.8,-22.8,-65.9,-25.6,-73.9,-30.2,-80.4,-34.4,-83.4,-38.4,-87.2,-43.7,-87.2,-51.1,-87.2,-62.5,-76.5,-69.9,-65.3,-77.6,-46.8,-77.6,-41.2,-77.6,-34.5,-76.4,-27.9,-75.3,-21.8,-75.3,-8.2,-75.3,4.5,-82.9,13.3,-88.1,25.1,-99.5,39.5,-113.4,43.1,-116.2,52.9,-123.8,61.4,-123.8,68.5,-123.8,77,-120,85.4,-116.2,92.7,-109.9,109.5,-95.2,109.5,-78.8,109.5,-74.1,105.9,-67.3,101.1,-59.3,98.9,-55.2,95.6,-49.4,89,-44.4,84.2,-40.8,76.5,-36.9,63.8,-30.3,45.8,-15.9,42,-12.9,39,-10.3]}},79).wait(1));

	// Layer 225
	this.instance_1 = new lib.pentagon2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-38.7,28);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 142, 146, 97, 0)];
	this.instance_1.cache(-40,-38,80,76);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-38.5,28,-52.1,30.4,-55.7,24.3,-59.4,17.9,-60.4,16.9,-63.2,13.5,-69.6,11.1,-73.2,9.8,-80.8,7.3,-87.1,4.9,-90.2,1.3,-94.1,-3.4,-94.1,-11.2,-94.1,-18.6,-86.4,-24.4,-83,-26.9,-69.5,-33.8,-57.7,-39.7,-52.5,-44.9,-44.8,-52.6,-44.8,-63.4,-44.8,-65.3,-46.8,-75.6,-48.8,-85.8,-48.8,-88.7,-48.8,-103.5,-32.5,-113,-18.2,-121.4,-0.4,-121.4,28.9,-121.4,48.1,-110.7,69.6,-98.6,69.6,-76.8,69.6,-58.7,62.6,-48.3,59.2,-43.7,57.8,-41.8,55.7,-38.4,55.7,-35,55.7,-31.5,59,-25.3,61.1,-21.6,66.5,-12.9,77.2,5.4,77.2,19.5,77.2,29,66.5,33,58.1,36.1,41.9,36.1,41.8,36.1,15.8,30.7,-9.9,25.3,-19.1,25.3,-27.2,25.3,-35.4,27.6]}},79).wait(1));

	// Layer 224
	this.instance_2 = new lib.octagon6("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-44,-65.6);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 142, 146, 97, 0)];
	this.instance_2.cache(-44,-44,88,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-43.9,-65.5,-43.5,-66.5,-43.1,-67.5,-40,-75,-34.3,-88.9,-28.8,-99.9,-21,-105,-11.3,-111.4,5.1,-111.4,12.1,-104.4,23.1,-97.5,44.9,-83.7,65.6,-83.7,85.6,-83.7,98.5,-64.1,110.3,-46.1,110.3,-22.3,110.3,-7,102.6,2.2,94.8,11.3,81.7,11.3,77.8,11.3,74,9.2,72.5,8.3,67.4,4.5,58.2,-2.4,48.7,-2.4,38.6,-2.4,27.6,13.2,23.4,19.1,17.6,29.2,14.3,35.1,7.3,47.6,-5.9,71,-18.5,83.5,-31.1,96.1,-33.6,79,-36.1,62,-53.5,73.3,-70.9,84.6,-70.9,73.7,-70.9,64.3,-58.6,50.3,-52.4,43.5,-50.1,40.7,-46.3,36.1,-46.3,33.8,-46.3,27.4,-54.2,20.2,-58.9,16,-71.6,7.6,-84.2,-0.8,-89.1,-5.3,-97,-12.5,-97,-19.2,-97,-30.3,-87.9,-36.9,-82,-41.2,-66.6,-45.3,-52.1,-49.1,-46.3,-61.6]}},79).wait(1));

	// Layer 223
	this.instance_3 = new lib.circle("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(26.4,-88);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 142, 146, 97, 0)];
	this.instance_3.cache(-38,-38,77,77);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[26.4,-87.9,52.8,-68.2,58.2,-68.6,63.8,-68.9,70,-67.1,76.3,-65.3,82.4,-61.8,97.9,-52.8,97.9,-43,97.9,-40.4,91.9,-32.9,89.2,-29.5,78.7,-17.7,59.4,3.9,59.4,9.8,59.4,11.1,64,20.6,68.7,30.1,68.7,32,68.7,38.1,62.5,42.1,57.7,45.2,54.1,45.2,51,45.2,43.2,42.9,35.5,40.6,32.4,40.6,18.2,40.6,14.7,48.3,13.4,51.4,13.2,56.7,13.1,59.8,13.2,66.7,13.2,70,8.8,73,4.3,76,-1,76,-8.2,76,-20.7,70.3,-32.8,64.8,-44.8,56.1,-57.7,46.9,-65.4,37.6,-74,27.2,-74,19.1,-74,8.7,-56.4,-2,-47.6,-7.1,-44.3,-9.3,-38.8,-13,-38.8,-15.6,-38.8,-18.5,-45.3,-23.5,-49.1,-26.5,-59.5,-33.9,-80.2,-49.4,-80.2,-62.9,-80.2,-70.7,-69.4,-79.1,-59.4,-86.8,-52.5,-86.8,-50.6,-86.8,-45.6,-85.2,-40.7,-83.7,-38.8,-83.7,-30.8,-83.7,-18.5,-96,-11.3,-103.2,-9.9,-104.5,-5.4,-108.3,-2.5,-108.3,4.1,-108.3,22.7,-91.2]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-85.7,-124.2,171.3,188.3);


(lib.anim1_28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 218
	this.instance = new lib.pentagon2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(60.8,20.2);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 102, 102, 0)];
	this.instance.cache(-40,-38,80,76);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[60.8,20.2,62.5,17.5,64.1,13.8,68.6,3.3,68.6,-6,68.6,-7,67.7,-12.2,66.9,-17.4,66.9,-18.5,66.9,-29.3,71.6,-37.2,74.5,-42,82.1,-49.2,89.7,-56.5,92.5,-61.2,97.3,-69.1,97.3,-80,97.3,-96.2,74.4,-108.3,65.6,-113,55.3,-115.8,45.9,-118.4,39.5,-118.4,32.8,-118.4,27.6,-115.9,24.8,-114.5,19.4,-110.4,14.2,-106.5,10.5,-104.9,4.7,-102.4,-3,-102.4,-9.7,-102.4,-28.5,-108.7,-47.2,-115.1,-51.1,-115.1,-55,-115.1,-61.6,-112.3,-69.1,-109.1,-75.6,-104,-93.2,-90.3,-93.2,-71.2,-93.2,-63.1,-89.9,-48.8,-86.5,-34.5,-86.5,-27,-86.5,-16.7,-91.1,-10.3,-93.7,-6.9,-94.3,-5.4,-95.8,-2.2,-95.8,2.5,-95.8,8.7,-93.3,16.8,-90.5,25.8,-85.7,33.3,-73.4,52.7,-55,52.7,-43.9,52.7,-1.8,40.6,37.2,29.4,56.2,22.7]}},79).wait(1));

	// Layer 217
	this.instance_1 = new lib.hexagon2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-34.7,33.5);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 102, 102, 0)];
	this.instance_1.cache(-50,-44,101,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-34.7,33.5,-33.7,33.9,-32.7,34.4,-28.6,37.1,-20.8,39.3,-4.6,44,11.2,44.3,27.1,44.6,36.6,47.9,43.3,50.3,45.1,54.4,45.5,55.5,46,57.6,46.5,59.3,47.5,60.2,50.2,62.7,60.6,62.7,95.3,62.7,105.8,41.7,109.6,34,110.5,22.9,110.9,18.9,110.9,5.3,110.9,-0.5,105.5,-8.4,101.9,-13.5,93.6,-22.5,84.4,-32.3,81.6,-35.9,76.2,-43,76.2,-47.6,76.2,-51.3,81.7,-62.3,87.2,-73.4,87.2,-77.6,87.2,-89.3,73.7,-100,60.9,-110,48.7,-110,37.4,-110,32.5,-107.3,29.1,-105.4,25.2,-99.2,19.9,-90.7,15,-85.5,6,-75.8,-9.7,-66.1,-34.4,-51,-54.4,-50.1,-79,-49.1,-83.6,-47.9,-87.9,-46.7,-89.7,-44.3,-91.6,-41.8,-91.6,-37.1,-91.6,-28.2,-86.2,-17.1,-80.9,-6.1,-71.7,4.6,-55.9,22.8,-37,32.3]}},79).wait(1));

	// Layer 216
	this.instance_2 = new lib.hexagon2("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(27.7,-67.1);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 102, 102, 0)];
	this.instance_2.cache(-50,-44,101,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[27.5,-67.1,26.6,-44.4,27.5,-41.8,29.8,-35.4,32.9,-29.4,41.8,-12.3,51.8,-9.8,64.8,-6.4,76.3,0.9,93.1,11.6,93.1,24.4,93.1,45,71.2,57.8,51.2,69.5,23.5,69.5,17.3,69.5,3.8,63.2,-9.6,56.9,-16.9,56.9,-26.4,56.9,-48.6,66.2,-60.3,71.1,-64.5,72.6,-72.8,75.5,-77.6,75.5,-86.1,75.5,-99.9,55.2,-105.7,46.8,-109.5,38.7,-113.4,30.2,-113.4,25.6,-113.4,12.1,-105.9,3.9,-100.4,-2.1,-89.4,-6.5,-77.3,-10.4,-72.8,-12.7,-65.3,-16.4,-65.3,-22.2,-65.3,-28.5,-70.4,-39.4,-75.5,-50.4,-75.5,-59,-75.5,-72,-64.5,-80.5,-53.5,-89,-36.7,-89,-30.6,-89,-9.4,-83.1,12,-77.2,18.9,-78.4,24.5,-79.5,26.7,-72.1]}},79).wait(1));

	// Layer 215
	this.instance_3 = new lib.octagon6("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-26.9,-77.8);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 102, 102, 0)];
	this.instance_3.cache(-44,-44,88,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[-26.8,-77.7,-24.1,-79.6,-13.6,-86.7,6.8,-100.7,20.1,-100.7,32.8,-100.7,43.3,-93.1,55,-84.6,55,-71.7,55,-67.1,53,-53.3,50.9,-39.5,50.9,-38.3,50.9,-17.8,58.9,-9.4,64.9,-3.3,76.6,-3.2,79.8,-3.2,86,-3.7,91.9,-4.2,94.3,-4.2,102.3,-3.9,102.3,2.8,102.3,7.9,97.8,16.5,93.3,25,86.3,33.2,69.2,53.5,55,53.5,49.8,53.5,44.6,50.7,41.6,49.1,35.7,44.7,30,40.2,26.6,38.5,21.1,35.8,15.4,35.8,5.6,35.8,-1.5,43.2,-5.9,47.7,-12.3,59.5,-18.7,71.4,-22.8,75.7,-29.7,83.1,-39.2,83.1,-56.4,83.1,-69.6,65.4,-82.2,48.3,-82.2,27.7,-82.2,9.9,-75,0.2,-69.7,-6.9,-59,-10.8,-47.5,-14.4,-43.1,-16.7,-39.5,-18.6,-38,-20.4,-36.6,-22.2,-37.2,-23.9,-38.6,-27.3,-42,-39.6,-45.3,-51.9,-28.6,-76.2]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-83,-119.6,181.6,195.1);


(lib.anim1_27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 210
	this.instance = new lib.hexagon2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(61.1,-1.2);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 102, 255, 204, 0)];
	this.instance.cache(-50,-44,101,88);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[61.1,-1.2,62.7,-4.5,65.6,-8.8,67.9,-12.2,73,-19.8,82.3,-34.7,82.3,-51.8,82.3,-72.9,56.9,-82.9,39.3,-89.9,17.3,-89.9,-1,-89.9,-11.1,-85.4,-26.6,-78.4,-32.9,-59.1,-32.3,-52,-37.4,-47.2,-40.3,-44.3,-49.1,-40,-57.8,-35.7,-61.2,-32.4,-66.8,-27.1,-66.8,-19.2,-66.8,-15.1,-60.3,-2.5,-54.1,9.5,-49.9,14.5,-44.7,20.6,-30,24.8,-17.6,28.4,-8.3,28.4,7.3,28.4,18,25.8,27.4,23.5,35.8,18.4,40.7,15.5,51.5,7.3,55.5,4.2,59.2,1.5]}},79).wait(1));

	// Layer 209
	this.instance_1 = new lib.hexagon2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-48.6,63.3);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 102, 255, 204, 0)];
	this.instance_1.cache(-50,-44,101,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-48.5,63.2,-44.9,61.6,-36.7,60.2,-24.8,58.1,-17.5,59.2,-10.1,60.4,0.7,58.3,12.9,55.5,19.1,54.5,66,46.9,66,17.2,66,8,61.2,0,58.4,-4.7,50.3,-13.6,41.9,-22.7,38.2,-28.7,32,-38.6,30,-50.7,25.8,-75.3,14.3,-92.7,3.4,-109.2,-6.9,-109.2,-12.2,-109.2,-20.5,-106.6,-29.6,-103.8,-37.6,-99.2,-58.4,-87.2,-58.4,-71.5,-58.4,-66,-53.8,-56.8,-49.1,-47.5,-49.1,-43.4,-49.1,-32.7,-55.5,-27.3,-58.3,-24.9,-69.5,-20.2,-79.2,-16,-83.5,-10.4,-89.9,-2.1,-89.9,13.4,-89.9,35.7,-75.3,50.7,-69.2,56.9,-61.8,60.4,-55.8,63.3,-50.3,63.7]}},79).wait(1));

	// Layer 208
	this.instance_2 = new lib.heptagon("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-20.1,-83.1);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 102, 255, 204, 0)];
	this.instance_2.cache(-45,-44,90,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-20.1,-83.1,-12.5,-76.9,2.5,-74.1,10.5,-72.5,41.4,-70.1,65.8,-68.1,76.4,-63.8,91.5,-57.6,91.5,-43.4,91.5,-28.9,79.8,-18,67.9,-7.1,49.2,-4.5,35.2,-4.9,26.9,-2.5,11.5,1.8,11.5,19.1,11.5,25.2,16.2,32,19.4,36.8,26.5,43.7,35.2,52.2,36.8,54,41.5,59.4,41.5,63.1,41.5,65.9,39.2,67.7,37.1,69.3,34.2,69.3,21.1,69.3,10.1,60.6,2.2,54.5,-6.9,41.5,-19,24.2,-20.5,22.4,-28,13.8,-35,13.8,-44.1,13.8,-53.2,19.3,-58.6,22.7,-68.4,31.5,-78.3,40.4,-83.6,43.7,-92.5,49.2,-101.4,49.2,-111.1,49.2,-119.1,39.2,-126.8,29.6,-126.8,19.2,-126.8,-16.4,-111.6,-33,-98.6,-47.3,-71.4,-49.9,-61.7,-50.8,-55.3,-56.7,-50.9,-60.7,-46.5,-69.1,-41.4,-78.7,-39.6,-80.9,-35.3,-86.2,-29.2,-86.2,-25.8,-85.3,-22.3,-84.4]}},79).wait(1));

	// Layer 207
	this.instance_3 = new lib.triangle("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-76.5,-25.2);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 102, 255, 204, 0)];
	this.instance_3.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[-76.4,-25.2,-74.7,-25.9,-73.9,-26.6,-73.2,-27.4,-73.5,-28.1,-74.1,-29.7,-76.4,-33.2,-80.7,-39.9,-80.7,-48,-80.7,-59.9,-73,-65.3,-67.6,-69.2,-59.9,-69.2,-52.6,-69.2,-40,-66.9,-27.3,-64.6,-11.8,-64.6,8.5,-64.6,18.7,-71.3,25.2,-75.6,30.4,-86.1,35.9,-97.3,40.1,-100.9,48.2,-107.6,65,-107.6,75.9,-107.6,82.2,-99.9,87.7,-93.3,87.7,-84.6,87.7,-75,78.7,-63.1,73.2,-56,58.9,-41.8,44.4,-27.6,39,-20.5,30,-8.8,30,0.7,30,8.7,37.6,14.4,39.3,15.7,54.2,23.8,65.5,29.9,70.8,36.7,78.4,46.3,78.4,61.1,78.4,72.9,70.8,80,62.4,87.7,46.4,87.7,29.2,87.7,17.7,81.7,9.8,77.5,1.9,68.5,-7.6,57.4,-10.4,55.2,-18.1,49.2,-28.7,49.2,-30.4,49.2,-47,52.2,-55.3,53.8,-63.4,55.3,-76.9,55.3,-86.8,44.6,-96.8,34,-96.8,19.8,-96.8,9,-88.2,-5.9,-82.7,-15.4,-78.7,-24.5]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-124.5,-125.1,233.9,230.5);


(lib.anim1_26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 202
	this.instance = new lib.triangle("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(47.8,26.9);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 206, 56, 0)];
	this.instance.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[47.8,26.9,50.2,23.7,52,21.2,58.5,12,60,4.5,61,-0.5,65.7,-6.9,66.3,-7.7,75.4,-18.5,81.6,-25.8,84.5,-31.3,88.5,-38.8,88.5,-46.4,88.5,-62.3,70.7,-76.8,63.5,-82.7,55.5,-86.4,47.7,-89.9,42.2,-89.9,41.3,-89.9,33.9,-89.1,26.6,-88.4,25.6,-88.4,20.2,-88.4,14.3,-92.6,10.7,-95.1,3,-101.9,-4.5,-108.1,-11.4,-111.2,-21,-115.4,-32.6,-115.4,-53.4,-115.4,-70,-106.1,-89.2,-95.4,-89.2,-77.6,-89.2,-67.1,-78.7,-58.1,-72.2,-52.5,-55.7,-43.7,-38.7,-34.6,-32.7,-29.7,-22.2,-21.1,-22.2,-11.5,-22.2,-5.2,-29.6,-1.4,-32.8,0.4,-45.7,4.3,-56.9,7.6,-61.8,11.4,-69.2,16.9,-69.2,26.1,-69.2,37.6,-58.4,40.8,-51,43.1,-25.3,43.1,5.7,43.1,16.3,41.1,21.4,40.1,28.9,37.8,32.2,36.8,46.6,28.3]}},79).wait(1));

	// Layer 201
	this.instance_1 = new lib.triangle("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(19.5,-26.9);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 206, 56, 0)];
	this.instance_1.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:19,y:-28.3},79).wait(1));

	// Layer 200
	this.instance_2 = new lib.hexagon2("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-45.4,-40.5);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 206, 56, 0)];
	this.instance_2.cache(-50,-44,101,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-45.2,-40.4,-12.4,-46.6,-3.4,-49.9,-1.1,-50.7,15.7,-58.3,28.2,-64.1,39.7,-66.7,56,-70.6,77,-70.6,84.3,-70.6,92.3,-59.7,100,-49.2,100,-40.5,100,-25,90.8,-17.5,84.8,-12.5,70,-8.6,53.4,-4.3,47.6,-1,36.5,5.4,33.8,18.4,33.2,21,32.8,28.3,32.3,35.7,31.6,39.9,28.7,54.2,16.9,59.9,7.6,64.3,-9.6,74.8,-24.5,83.1,-35.1,83.1,-57.3,83.1,-69.1,72.3,-78.3,63.9,-78.3,53.1,-78.3,46.1,-74.7,40.2,-69.7,33.5,-66.8,29.5,-61.5,22.1,-58.9,13.7,-55.2,2.2,-53.3,-21,-52.4,-31.4,-47.2,-37.5]}},79).wait(1));

	// Layer 199
	this.instance_3 = new lib.triangle("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-24.1,22.4);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 206, 56, 0)];
	this.instance_3.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[-23.9,22.5,-17.3,29.6,-13.5,35.5,-9,42.5,-0.7,56.8,7,68.7,14.8,74.3,25.2,81.6,39.8,81.6,63,81.6,75.4,73.9,89.2,65.4,89.2,47.6,89.2,37.7,76.1,14.1,69.6,2.7,67.1,-1.7,63,-9,63,-10.7,63,-16.5,66.6,-22.4,67.6,-24,74.6,-33.1,79.9,-40.2,82.5,-46.2,86.1,-54.8,86.1,-65.1,86.1,-84.9,77,-93.7,67.5,-102.9,45.2,-102.9,36.6,-102.9,30.8,-101.5,27.3,-100.6,22.2,-98.3,17.2,-95.9,13.7,-95.1,7.9,-93.6,-0.7,-93.6,-9.3,-93.6,-15.1,-95.1,-18.6,-95.9,-23.6,-98.3,-28.7,-100.6,-32.2,-101.5,-38.1,-102.9,-46.7,-102.9,-53.8,-102.9,-65.3,-99.7,-77.6,-96.4,-84.5,-92.1,-92.1,-87.4,-93.1,-78.9,-93.3,-73.9,-93.5,-71.3,-93.9,-66.4,-95.2,-62.8,-98.9,-52.9,-105.2,-46.3,-108.2,-43.2,-116.3,-37.4,-122.8,-32.7,-125.4,-28.6,-129.1,-22.7,-129.1,-12.8,-129.1,0.8,-119.9,7.6,-111.4,13.8,-96,13.8,-90.1,13.8,-72.8,9.1,-55.6,4.4,-51.4,4.4,-44.7,4.4,-39.7,9.1,-35.8,12.8,-25.6,21.4]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-93.6,-82.5,189.5,151);


(lib.anim1_25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 194
	this.instance = new lib.square8_2("single",0);
	this.instance.parent = this;
	this.instance.setTransform(-24.9,36.2);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 60, 51, 89, 0)];
	this.instance.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[-24.9,36.2,-18.8,37.9,-18,37.9,-10.3,37.9,-6.4,38.9,-3.6,39.7,-0.6,41.9,8.1,48.5,21.1,52.4,32.5,55.8,37.2,56.8,45.8,58.6,55.3,58.6,68,58.6,76.5,54.8,93.4,47.1,93.4,26.3,93.4,14,89.9,6.1,87.7,1.2,82.2,-5.2,76.6,-11.8,74.6,-16.2,71.1,-23.7,71.1,-35.1,71.1,-38.2,73.4,-51.5,75.7,-64.7,75.7,-70.9,75.7,-92.2,64.1,-107.4,50.7,-125.1,27.2,-125.1,21.4,-125.1,7.4,-119.7,0.4,-116.9,-7.9,-113.6,-16.6,-111.4,-22.8,-110.6,-29.5,-109.6,-36.4,-109.8,-44.2,-110,-50.5,-108.1,-57.1,-106.1,-64.1,-101.2,-68.8,-98,-76.7,-88,-84.9,-77.6,-84.9,-74.3,-84.9,-70.1,-80.9,-64.6,-78.5,-61.3,-72.2,-54.7,-65.8,-48.1,-63.4,-45,-59.5,-39.6,-59.5,-35.5,-59.5,-33.4,-61.4,-24.9,-63.3,-16.3,-63.3,-12.1,-63.3,-5.4,-59.3,0.9,-56.1,5.8,-49.1,12.4,-40.4,20,-35.9,24.4,-30.2,29.8,-26,34.9]}},79).wait(1));

	// Layer 193
	this.instance_1 = new lib.square8_2("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(40.3,-70.2);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 60, 51, 89, 0)];
	this.instance_1.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[40.2,-70.1,42.9,-67.8,45.8,-65.7,51.5,-61.5,62.5,-54.4,75.4,-45.3,79.7,-40.9,87.9,-32.5,87.9,-23.5,87.9,-12,82.7,-8,79.3,-5.3,70,-4.6,58.8,-3.7,53.9,-1.8,44.6,1.8,38.7,11.7,37.1,14.4,35.6,24.5,34.3,33.3,29.5,38.6,25.4,43.2,16.4,53.6,8.4,61.7,2.3,61.7,-1.5,61.7,-7,59.5,-9.1,58.7,-17.3,54.7,-31.9,47.8,-41.5,47.8,-53.9,47.8,-69.4,56.7,-73.2,58.9,-79.5,62.8,-84.3,65.5,-86.5,65.5,-92.9,65.5,-96.7,61.4,-99,59,-104.9,48.6,-107.6,43.8,-108.3,39,-108.8,35.4,-108.8,26.2,-108.8,-2.1,-95.2,-14.8,-89.3,-20.3,-79.2,-25,-73.8,-27.5,-58,-33.5,-52,-35.8,-42.6,-46,-39.6,-49.4,-28,-63.5,-21.8,-71.1,-11.2,-76.6,-0.8,-82,7.3,-82,12.1,-82,23.1,-77.3,32.9,-73.1,38.9,-71.2]}},79).wait(1));

	// Layer 192
	this.instance_2 = new lib.octagon6("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-47.2,-13.5);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 60, 51, 89, 0)];
	this.instance_2.cache(-44,-44,88,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-47.1,-13.4,-40.4,-22.7,-32.9,-39.2,-28.6,-48.5,-20.7,-66.9,-13.9,-82.1,-8.2,-89.1,-0.9,-98.1,7.3,-98.1,16,-98.1,25.7,-92.8,36.5,-86.9,36.5,-79.7,36.5,-78.9,26.9,-67.1,17.2,-55.3,17.2,-51.6,17.2,-43.3,25.3,-34.6,30.7,-28.9,43,-20.1,56.9,-10.3,60.8,-6.8,68.8,0.5,68.8,6.7,68.8,19.6,58,25.5,51.1,29.4,42.6,29.4,38.5,29.4,26.8,27.5,15.1,25.5,12.2,25.5,-1.9,25.5,-1.9,38.6,-1.9,44.8,3.1,57.3,8.1,69.8,8.1,73.2,8.1,82.5,-6.6,86.4,-15,88.6,-25.3,88.6,-33.8,88.6,-46.6,83.2,-59.1,77.9,-71,69.4,-83.7,60.5,-91.2,51,-99.5,40.5,-99.5,31.7,-99.5,23.7,-92.7,17.6,-86.9,12.4,-74.9,7.9,-61.5,3.1,-58.3,1.3,-49.7,-3.3,-48,-10.4]}},79).wait(1));

	// Layer 191
	this.instance_3 = new lib.square8_2("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(47.7,18.6);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 60, 51, 89, 0)];
	this.instance_3.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[47.8,18.7,48.8,20.3,49.9,22.2,58.1,35.3,60.3,39.3,65,47.8,65,51,65,63.1,58.8,69.4,52.6,75.6,41.2,75.6,35.6,75.6,31.6,70.8,29,67.5,26.2,60.2,22.8,51.5,21.8,49.6,19.1,44.8,15.6,44.8,5.9,44.8,-2.4,50.9,-8.5,55.3,-15.5,64.4,-25.5,77.4,-26.1,77.9,-31.6,84.1,-36.4,84.1,-44.9,84.1,-49.6,77.9,-54.1,71.7,-54.1,60.2,-54.1,52,-47.9,39,-41.7,26,-41.7,18.6,-41.7,12.8,-45.3,6.9,-47.4,3.5,-53.3,-3.5,-59,-10.2,-61.3,-14.2,-64.9,-20.6,-64.9,-27,-64.9,-31.1,-59.5,-35.9,-51.8,-42.7,-51.8,-42.8,-50.2,-44.9,-49.4,-53.6,-48.8,-59.5,-48.8,-63.5,-48.8,-77.8,-42.6,-82.8,-37,-87.4,-21.8,-87.4,-19.5,-87.4,-16,-85.9,-14.6,-85.4,-13.6,-84.9,-12.4,-84.2,-12.3,-83.2,-8.9,-79.5,-2.2,-76.5,13.7,-70.6,21.8,-65.8,33.3,-59.3,36.9,-52.8,40.4,-46.7,40.4,-34.3,40.4,-29.6,37.7,-22,34.9,-14.4,34.9,-8.9,34.9,-2.7,46.8,17.2]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-88.9,-102.9,169.4,171.9);


(lib.anim1_24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 185
	this.instance = new lib.square8_2("single",0);
	this.instance.parent = this;
	this.instance.setTransform(-12.8,7.4);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 128, 255, 0)];
	this.instance.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[-12.7,7.4,-11.3,8.6,-5.3,16.7,1.6,26,6.8,31.7,25.2,51.7,41.8,51.7,49.6,51.7,54.2,43.7,57.9,37.4,57.9,30.5,57.9,29,56.6,1.6,56.6,-12.1,62.4,-22.8,66.3,-30.2,74.9,-38.9,85.3,-49.6,87.4,-52.3,92.9,-60.1,92.9,-68.4,92.9,-83.5,81.2,-93.5,71.1,-102,59.7,-102,55.9,-102,46.1,-96.6,33.5,-89,25.9,-84.6,-4.4,-67.3,-24.5,-67.5,-45.3,-67.8,-49.9,-67.6,-65,-67.2,-74.9,-64.9,-101.4,-58.7,-101.4,-36.1,-101.4,-18.2,-83.6,-4.9,-66.4,8,-44.8,8,-40.5,8,-29.7,7,-19.3,6,-17.7,6.8,-16.4,6.7,-15.2,6.6]}},79).wait(1));

	// Layer 184
	this.instance_1 = new lib.circle("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(75.7,-31.6);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 128, 255, 0)];
	this.instance_1.cache(-38,-38,77,77);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[75.7,-31.5,76.6,-31.4,77.5,-31.3,80.2,-31.1,85.7,-31.1,90.3,-30.8,92.5,-28.7,95.3,-26,95.3,-19.7,95.3,-14.9,91.8,-8.4,88.1,-1.7,81.9,4.2,66.5,18.9,46.6,18.9,43.9,18.9,36.3,17.1,28.7,15.3,25.8,15.3,16.3,15.3,11.7,25.3,9,31.3,4.4,47.4,-1,62,-11,69.4,-24.7,79.4,-49.7,79.4,-65.4,79.4,-77.9,75.6,-96.4,70.1,-96.4,58.3,-96.4,54.9,-93.2,50.9,-92.8,50.4,-85.9,43.3,-75.5,32.4,-75.5,21.4,-75.5,15.4,-82.3,0.6,-89.1,-14.1,-89.1,-21,-89.1,-31.7,-71.8,-37.4,-60.3,-41.1,-50.3,-41.1,-43.9,-41.1,-35.4,-38.6,-27.1,-36.1,-20.2,-36.1,-11.6,-36.1,-3,-44.9,1.9,-50.1,11.7,-64.4,21.3,-78.5,26.8,-84,35.8,-92.9,44.9,-92.9,57.9,-92.9,67.1,-78,75.7,-64.2,75.7,-47.4,75.7,-42.2,73.2,-34.4]}},79).wait(1));

	// Layer 183
	this.instance_2 = new lib.triangle("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-37.3,-57.1);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 128, 255, 0)];
	this.instance_2.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-37.2,-57.1,-36.2,-57.4,-35.1,-57.8,-27.4,-60.7,-20.5,-65.3,-19.2,-66.1,-8.6,-74.2,-2.1,-79.2,3.3,-81.3,10.7,-84.3,20.3,-84.3,30.3,-84.3,38.7,-79.3,49.8,-72.8,49.8,-60.8,49.8,-59.5,44.9,-45.7,40,-31.8,40,-27.1,40,-21.1,50.2,-15.9,56.3,-12.8,72.6,-6.6,87.5,-0.1,94.9,7.1,105.1,17.1,105.1,31.3,105.1,44.5,99.1,49.7,93.4,54.7,79.4,54.7,69.5,54.7,59.4,46.4,53.7,41.8,42,28.2,30.7,15.2,23.9,10,13.1,1.7,2,1.7,-7.1,1.7,-12.3,12.5,-14.3,16.4,-16.5,23.6,-17.7,27.6,-20.3,36.3,-25.5,52.3,-32.5,60,-42.4,70.8,-59.4,70.8,-65.5,70.8,-70.5,65.8,-75.5,60.8,-75.5,54.7,-75.5,51.3,-73.8,48.8,-72.8,47.3,-70,44.9,-64.4,40.1,-64.4,34.4,-64.4,23.9,-71.2,12.9,-72.9,10.2,-75.9,5.4,-78,1.5,-78,-1.4,-78,-8.7,-67.6,-15.2,-64.6,-17.1,-59.4,-19.6,-54.4,-22,-53.3,-22.7,-45.4,-28.1,-43.8,-38,-43.8,-38.1,-42.8,-46.7,-42.2,-51.9,-41.1,-55.5]}},79).wait(1));

	// Layer 182
	this.instance_3 = new lib.rectangle("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(28.9,-63.4);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 128, 255, 0)];
	this.instance_3.cache(-50,-35,100,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[29,-63.3,32.1,-65.4,44.3,-64.4,58.1,-63.2,71.1,-58.6,87.1,-52.9,96.5,-43.5,107.7,-32.2,107.7,-16.7,107.7,-13,105.8,-9.6,105.6,-9.3,101.2,-3.1,94,7.3,91.8,22.6,90.4,32.1,74.4,40.7,60.2,48.5,50.2,48.5,36.8,48.5,19.7,41.1,11.5,37.5,8,36,2,33.7,-1.6,33.7,-6.4,33.7,-12.7,37.4,-14.3,38.4,-24.7,45.5,-41.8,57.2,-55.9,57.2,-76.6,57.2,-92.8,42.4,-99,36.6,-102.8,30.1,-106.3,24.1,-106.3,20.1,-106.3,9.7,-97.3,4.4,-92.5,1.6,-77.3,-2.3,-63.3,-6,-57.4,-10.2,-48.4,-16.8,-48.4,-29.4,-48.4,-33.7,-50.9,-43.6,-53.4,-53.5,-53.4,-57.2,-53.4,-65.7,-46,-70.7,-39,-75.5,-27.6,-75.5,-17.1,-75.5,-1.7,-70.8,20,-64.2,24,-63.3]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-85.3,-98.6,197.3,138.8);


(lib.anim1_23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 177
	this.instance = new lib.triangle("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(46.7,36.8);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 7, 169, 124, 0)];
	this.instance.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[46.8,36.7,47.3,29.2,52.7,18.6,55.7,13,64.5,-1.2,72.6,-14.2,76,-21.3,81.1,-32.3,81.1,-40.5,81.1,-50.9,75.1,-59,69.6,-66.3,64,-66.3,63.5,-66.3,-1.8,-57.7,-15.1,-57.7,-24.2,-64.3,-29,-67.7,-38.1,-78.6,-46.6,-88.8,-53.9,-93,-65,-99.6,-81.7,-99.6,-95.5,-99.6,-100.8,-93.5,-105.6,-88,-105.6,-74.3,-105.6,-57.1,-98.5,-45.6,-93.7,-37.8,-82.9,-29.5,-70.4,-19.9,-67.3,-16.2,-60.1,-7.7,-60.1,4.2,-60.1,11.8,-63.6,19,-65.9,23.9,-71.3,30.9,-77.2,38.8,-78.9,41.7,-82.4,47.8,-82.4,53.4,-82.3,65.5,-68.6,56.2,-54.8,46.9,-43.2,46.7,-31.6,46.5,-17.1,58.6,-2.7,70.8,9.9,61.4,16.7,57.6,23.3,54.8,29.9,52.1,35.6,48.7,41.3,45.3,44.9,37.4]}},79).wait(1));

	// Layer 176
	this.instance_1 = new lib.square8_2("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(16.3,-42.4);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 7, 169, 124, 0)];
	this.instance_1.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[16.3,-42.4,25,-33.9,30.3,-29.7,35.5,-25.4,47.4,-19.6,51.8,-17.4,62,-12.9,69.3,-9.7,72.4,-7.8,76.7,-5,78.5,-1.4,80.6,2.7,80.6,9.2,80.6,18.7,73.7,28.2,65.2,40,51,41.8,44.6,42.6,25.7,43.4,9.3,44,2.4,45.5,-2.5,46.6,-11.6,55.1,-16.9,60.2,-29.4,72.9,-41,84.5,-49.1,87,-57.1,89.4,-72.1,87.4,-87.2,85.4,-100,76.6,-112.8,67.7,-107.1,59.4,-101.5,51,-92.8,35.6,-86.6,24.6,-73.7,13.2,-66.8,7.3,-63.6,4.5,-57.9,-0.4,-54.7,-3.9,-46,-13.4,-46,-23.9,-46,-28.1,-53.5,-33.9,-56.2,-36,-70,-44.8,-81.3,-52.1,-86.5,-57.1,-94,-64.5,-94,-71.3,-94,-84.9,-77.4,-95.9,-60.8,-107,-40.2,-107,-13.7,-107,0.4,-80,4.1,-72.8,9,-59,13,-47.7,15.1,-44.5]}},79).wait(1));

	// Layer 175
	this.instance_2 = new lib.triangle("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-50.6,-70.1);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 7, 169, 124, 0)];
	this.instance_2.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-50.5,-70,-38.6,-61.7,-28.5,-67.4,-8.4,-78.6,-4.8,-78.6,-3.2,-78.6,-0.9,-79.9,1.4,-81.1,3,-81.1,24.9,-81.1,30.8,-49.1,32.9,-37.7,33.2,-20.7,33.4,-11.1,33.1,5.5,33.1,9.8,28.3,13.7,26.9,14.9,17.7,20.5,10.5,25,7.1,29,2.3,34.8,2.3,42.3,2.3,46.7,5.5,56.7,8.6,66.7,8.3,74.1,8,81.5,-2.6,76.5,-13.3,71.6,-29.8,78,-46.3,84.4,-57.2,80,-68.1,75.6,-69.6,65.9,-71.1,56.1,-68.7,42.4,-66.3,28.6,-66.3,25.2,-66.3,10.3,-74.4,2.8,-79.7,-2,-92.1,-5.7,-105.8,-9.7,-109.9,-12.5,-118,-17.9,-118,-29.4,-118,-49.7,-95.8,-62.5,-87.5,-67.2,-77.8,-70,-69.4,-72.4,-63.8,-72.4,-60.3,-72.4,-53,-70]}},79).wait(1));

	// Layer 174
	this.instance_3 = new lib.octagon6("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-54.6,36.2);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 7, 169, 124, 0)];
	this.instance_3.cache(-44,-44,88,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[-54.5,36.2,-49.1,41.6,-49.1,46.1,-49.1,47.7,-50.3,51,-51.5,54.4,-51.5,55.9,-51.5,73.4,-38.3,79.2,-25,85,-8.1,84.8,8.8,84.7,21.6,84.5,34.3,84.2,36.9,71.4,39.5,58.6,54.2,58.6,68.9,58.5,68.9,50.9,68.9,45.9,65.8,34.9,62.6,23.8,62.6,20.8,62.6,13.8,66.3,2.7,70,-8.4,70,-9.2,70,-23.3,56.6,-35.5,43,-47.8,27,-47.8,11.7,-47.8,7.7,-58.8,5.1,-65.7,6.5,-82.9,8,-100.8,6.2,-107,3.1,-118,-10.5,-118,-23.5,-118,-36.8,-108.2,-51.5,-97.3,-51.5,-83.6,-51.5,-82,-50.3,-75,-49.1,-68,-49.1,-66.4,-49.1,-60.9,-56.8,-55.1,-61.4,-51.6,-73.7,-44.3,-85.1,-37,-90.6,-30.2,-98.3,-20.8,-100.3,-6.1,-102.3,8.7,-92.2,14.2,-82.1,19.7,-79.9,19.7,-79.8,19.7,-79.8,19.7,-71.5,23.6,-63.5,29,-61.2,30.6,-59.2,32.1]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-98.6,-111.6,193.3,189.9);


(lib.anim1_22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 169
	this.instance = new lib.pentagon2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-31.6,48.7);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 63, 124, 124, 0)];
	this.instance.cache(-40,-38,80,76);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[-31.5,48.6,-30.6,48.5,-30.5,48.5,-28.7,48,-26,48,-17.7,48,-7.6,52.3,2.6,56.6,9.8,56.6,21.1,56.6,27.9,54.7,35.4,52.7,40.2,47.7,49,38.5,54.2,9.8,56.6,-4,61,-13,63.8,-18.8,68.7,-24.4,73.7,-30.3,75,-32.9,77.6,-38.1,77.6,-46.4,77.6,-57,68.9,-68.2,59.8,-79.9,49.8,-79.9,45.9,-79.9,29.6,-75.9,13.2,-71.9,8.6,-71.9,-1.5,-71.9,-9.2,-75.9,-14.5,-78.7,-20.4,-84.8,-27.9,-92.6,-29.3,-93.7,-34.4,-97.7,-40.1,-97.7,-43.4,-97.7,-49.7,-95.8,-56.9,-93.7,-63.2,-90.4,-80.5,-81.5,-80.5,-70.4,-80.5,-59.8,-73.1,-46.4,-68.9,-38.8,-68,-36.8,-65.7,-31.6,-65.7,-27.3,-65.7,-15.7,-70.5,-8.3,-74,-2.9,-81.1,1.3,-84.9,3.6,-91.7,7.5,-96.5,11.1,-96.5,16.3,-96.5,19.4,-93.2,24.3,-89.8,29.7,-84.2,34.5,-69.8,46.8,-52.4,46.8,-48.8,46.8,-44.3,46,-40.9,45.5,-35,48.3]}},79).wait(1));

	// Layer 168
	this.instance_1 = new lib.triangle("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(46.2,-49.8);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 63, 124, 124, 0)];
	this.instance_1.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[46.2,-49.7,48.8,-43.3,50.6,-38.7,54.1,-29.4,54.1,-23.7,54.1,-7.4,40.1,5.4,35.6,9.5,27.3,15.2,16.9,22.3,14.7,24,10.7,27.1,2.8,37.7,-4.5,47.5,-10.5,51,-17.8,55.5,-27.9,59.5,-40.7,64.6,-48.6,64.6,-57.3,64.6,-62.8,61.1,-67.8,57.9,-71.6,50.9,-74.1,46.5,-78.8,34.9,-84.1,21.8,-87.9,14.1,-90.1,9.5,-104,-14.2,-116.7,-36.6,-116.7,-41.5,-116.7,-52.6,-104.1,-62.3,-101.5,-64.4,-93.1,-70,-86.1,-74.6,-83,-77.5,-80.1,-80.1,-76,-86.4,-71.1,-93.8,-68.6,-96.8,-58.2,-108.9,-41.8,-108.9,-23.1,-108.9,-9.5,-94.6,-5.5,-90.4,-0.7,-83.5,3.8,-76.9,4.9,-75.7,9.7,-71,16.4,-68.5,16.9,-68.2,27.6,-65.2,30.8,-64.3,37.5,-58.9,42.6,-54.7,45.3,-51.8]}},79).wait(1));

	// Layer 167
	this.instance_2 = new lib.octagon6("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-40.9,-73.7);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 63, 124, 124, 0)];
	this.instance_2.cache(-44,-44,88,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-40.8,-73.6,-27.2,-80.2,-15.7,-86.6,-3.4,-93.5,23.4,-93.5,46.3,-93.5,54.5,-75.5,57.5,-68.7,59.2,-57.7,59.3,-57.4,61.6,-38,62.7,-28.1,64.8,-21.5,66.8,-15.1,70.8,-8.5,72.5,-5.8,79.4,5.1,85.5,16.6,85.5,26.7,85.5,45,72,55.4,61.5,63.4,49.7,63.4,43.6,63.4,28.2,60.3,12.8,57.2,2.1,57.2,-6.5,57.2,-25.7,68.6,-36.4,74.9,-39.2,76.4,-46.2,80,-49.8,80,-60.8,80,-74.2,58.4,-77.1,53.9,-83.5,42.4,-88.1,34.2,-89.7,32.6,-95.3,27.2,-102.3,22.6,-106.1,20.1,-112.4,16.2,-117.2,13.1,-119.2,10.1,-121.7,6.4,-121.7,0.9,-121.7,-9.3,-109.5,-18.5,-101.2,-24.9,-82.1,-33.6,-64.7,-41.6,-43.5,-71.2]}},79).wait(1));

	// Layer 166
	this.instance_3 = new lib.octagon6("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(51,32.3);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 63, 124, 124, 0)];
	this.instance_3.cache(-44,-44,88,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[50.3,35.1,50.3,35.1,50.3,35.1]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-82.6,-115.5,176.9,200.2);


(lib.anim1_21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 161
	this.instance = new lib.rectangle("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-61.8,14.9);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 31, 64, 118, 0)];
	this.instance.cache(-50,-35,100,70);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[-61.7,14.9,-59.3,15.8,-56.1,21.2,-51.8,28.7,-51.5,28.9,-48.3,31.3,-43.1,33.2,-37.3,35.1,-31.3,35.6,-21.1,35.7,-13.7,36.4,0.4,37.6,6.1,41.8,15.3,48.3,26.3,52.2,36.9,56,45.6,56,51.1,56,57.6,53.5,64.4,50.8,70.3,46.1,84.4,34.7,84.4,18.4,84.4,9.9,78.9,1.5,75,-4.6,66.2,-13.3,52.2,-27,51.3,-28,43.1,-36.9,39.3,-44.8,37.8,-48,36.6,-54.6,35.8,-58.4,34.3,-66.9,31.1,-83,25.2,-88.5,22.1,-91.4,10.1,-96.6,-2.7,-102.1,-8.2,-102.1,-19.1,-102.1,-26.2,-90.6,-29.6,-84.5,-31.4,-81.9,-34.5,-77.5,-38.1,-76.2,-41.3,-75.1,-54.8,-70.7,-64.2,-67.6,-68.9,-65.5,-82.4,-59.5,-82.4,-50.4,-82.4,-43.8,-79.8,-36.4,-78.8,-33.5,-74,-22.8,-65.8,-4,-63.7,13.3]}},79).wait(1));

	// Layer 160
	this.instance_1 = new lib.hexagon2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(41.7,-68.4);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 31, 64, 118, 0)];
	this.instance_1.cache(-50,-44,101,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[41.7,-68.4,45.3,-63.2,49.1,-58.9,54.6,-52.8,65.7,-41.4,75,-31.4,79.2,-24.7,84.8,-15.7,84.8,-7.7,84.8,2.2,76.3,8.4,69.9,13.2,57.1,16.6,42.5,19.9,36.3,21.6,25.8,24.4,23.2,28.1,20.9,31.4,20.2,35.3,19.8,37.6,19.5,42.2,18.4,51,9.8,58.9,6.4,62,-7.4,67.9,-21,73.7,-24.4,73.7,-28.9,73.7,-37.4,75.5,-46,77.3,-49.1,77.3,-55.1,77.3,-57.7,76.2,-62.6,74.2,-62.6,68.1,-58.6,63.3,-54.6,57,-46.6,44.4,-46.6,36.1,-46.6,27.6,-53.7,23.1,-57.5,20.8,-69.3,17.3,-80.4,14.2,-85,10.6,-92.1,5.1,-92.1,-5.2,-92.1,-14.6,-67.5,-33,-55.2,-42,-50.6,-45.6,-42.9,-51.7,-42.9,-54.1,-42.9,-58,-44.8,-61.7,-45.9,-63.8,-49,-68.2,-55.2,-76.6,-55.2,-83.6,-55.2,-90.7,-42.9,-98.5,-31.3,-105.8,-23.3,-105.8,-7.1,-105.8,9.8,-97.9,26.7,-89.9,34.3,-78.8,36.8,-74.4,40.3,-69.8]}},79).wait(1));

	// Layer 159
	this.instance_2 = new lib.octagon6("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-38.5,-64.7);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 31, 64, 118, 0)];
	this.instance_2.cache(-44,-44,88,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-38.4,-64.6,-26.9,-69.1,-21.5,-71.1,-11,-75,-4.4,-75,9.9,-75,17.1,-70,25.8,-64,25.8,-50.4,25.8,-48.9,24.5,-40.6,23.3,-32.4,23.3,-30.8,23.3,-25,26.1,-19.4,27.5,-16.9,32.6,-9.6,37,-3.3,39,1.6,41.9,8.7,41.9,17.1,41.9,18.6,43.1,23.2,44.2,27.8,44.2,29.4,44.2,32.7,43,35.5,41.3,39.3,38.1,39.3,35.2,39.3,31.7,34.9,29.6,32.3,25.3,25.1,21,18.1,18.8,15.4,15.2,11,12.1,11,8.7,11,6,14.3,3.3,17.7,1.2,24.4,-1.2,32.5,-5.9,54,-11.1,73.7,-19.2,83.6,-30,97.1,-48.5,97.1,-61.9,97.1,-76.1,84.9,-82.2,79.7,-85.9,74.1,-89.7,68.3,-89.7,63.9,-89.7,50.8,-83.9,41.8,-79.8,35.2,-71.2,29.3,-62,23.5,-58.5,20.5,-52.7,15.7,-52.7,9.8,-52.7,7.9,-56,4.6,-58,2.6,-63.2,-2.4,-73.7,-13.4,-73.7,-26,-73.7,-32.1,-71.6,-40.8,-69.2,-50.9,-65.3,-58,-55.3,-76.3,-40.3,-63.9]}},79).wait(1));

	// Layer 158
	this.instance_3 = new lib.rectangle("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(68.9,-4.8);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 31, 64, 118, 0)];
	this.instance_3.cache(-50,-35,100,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[68.9,-4.8,70.4,6.3,73.6,12.2,76.3,17.4,77.1,19.6,78.8,24,78.8,28.7,78.8,38.5,76.3,45.5,72.7,55.3,65.2,55.3,57.8,55.3,42.8,44.8,32.9,37.8,32.5,37.5,27.4,34.2,25.2,34.2,20.3,34.2,16,39.2,12.3,43.5,12.3,46.5,12.3,51.8,17.8,59.1,23.3,66.4,23.3,69.4,23.2,77,9.7,84,-3.8,91,-15.6,82.3,-27.5,73.7,-48.7,75.8,-69.9,77.8,-69.9,58.9,-69.9,45.4,-62.8,37.3,-57.5,31.3,-47.2,27.6,-35.8,24.4,-31.5,22.9,-24.4,20.4,-24.4,16.4,-24.4,6.7,-36.3,-0.1,-43.8,-4.4,-62.5,-10.1,-82,-16.1,-88.8,-19.7,-100.7,-26,-100.7,-34.6,-100.7,-44,-91.5,-47.9,-84.9,-50.6,-70.9,-51.1,-49.6,-51.9,-48.8,-52,-37.9,-53.1,-35.5,-57.8,-34.7,-59.5,-30.8,-69.8,-27.1,-79.7,-23.9,-85.8,-13.3,-105.8,1.3,-105.8,7.1,-105.8,11.2,-103.3,15.5,-100,18.9,-98.8,26.6,-88.7,40.3,-73.9,55.6,-57.2,62.7,-44.2,67.1,-36,68.5,-24.7,69.3,-17.1,68.9,-6.3]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109.8,-110.4,226.8,158.1);


(lib.anim1_20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 153
	this.instance = new lib.rectangle("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-41.4,17.8);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 153, 204, 153, 0)];
	this.instance.cache(-50,-35,100,70);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[-41.3,17.9,-27.5,39.1,-17.1,58.2,-12.4,66.7,-4.2,84.6,1,96.1,4.7,99.8,9.6,104.7,18.6,104.7,42.7,104.7,56.6,95.9,72.9,85.7,71.5,65.2,69.8,41.5,74,34.4,77.5,28.8,85.3,19.3,91.4,11,91.4,4.3,91.4,-12.6,78.5,-21.6,67.4,-29.3,53.1,-28.1,39.8,-26.9,21.1,-36.5,8.1,-43.2,7.7,-43.4,0.7,-46.6,-4,-46.6,-14.7,-46.6,-27.9,-36.7,-41.3,-26.6,-41.8,-20.6,-42.4,-14.7,-44.6,-9.1,-46.8,-3.6,-42,16.2]}},79).wait(1));

	// Layer 152
	this.instance_1 = new lib.circle("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(36.1,-5.5);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 153, 204, 153, 0)];
	this.instance_1.cache(-38,-38,77,77);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[36.1,-5.5,46.5,-12.7,46.5,-20.2,46.5,-21,45.9,-24.5,45.2,-28.1,45.2,-28.9,45.2,-34.5,39.3,-41.2,37,-43.7,28.8,-49.3,28.7,-49.4,28.6,-49.5,28.4,-49.5,28.2,-49.5,2.8,-54.1,-2.4,-54.1,-9.9,-54.1,-14.6,-52.5,-17.6,-51.5,-22.9,-48.3,-36.5,-40.1,-56.2,-35,-77.2,-29.6,-86.9,-19,-98,-6.9,-98,15.1,-98,33.1,-83.9,50.5,-78.4,57.3,-72.4,61.6,-66.6,65.8,-63.3,65.8,-62.5,65.8,-58.7,65.3,-54.8,64.7,-54.1,64.7,-48.8,64.7,-45,70.1,-42.6,73.3,-37.2,81.9,-24,99.2,9.3,99.2,20.6,99.2,28.7,94.2,37.8,88.5,37.8,78.5,37.8,69.9,27.6,58.4,16.9,46.5,5.9,44.3,-7.3,41.8,-19.7,33.8,-33.4,25,-33.4,16.7,-33.4,8.2,-25.5,2.5,-17.9,-2.9,-6.8,-2.9,-5.6,-2.9,3.1,-2,11.8,-1.1,18.1,-1.1,27.3,-1.1,34.2,-4.2]}},79).wait(1));

	// Layer 151
	this.instance_2 = new lib.heptagon("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-20.6,-50.4);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 153, 204, 153, 0)];
	this.instance_2.cache(-45,-44,90,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:-22.2,y:-49.5},79).wait(1));

	// Layer 150
	this.instance_3 = new lib.circle("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-14.5,-57.9);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 153, 204, 153, 0)];
	this.instance_3.cache(-38,-38,77,77);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[-14.4,-57.9,-30.3,-52.1,-31.2,-46.9,-33.1,-36.2,-34,-33.1,-36.2,-26.5,-40,-25.3,-44.6,-24,-50.2,-23.9,-53.4,-23.8,-59.2,-24,-68.8,-24.2,-72,-19.2,-75.1,-14.6,-77.9,-2.2,-80.8,10.4,-80.8,19.8,-80.8,31.8,-75.8,40.9,-70.5,50.6,-62.2,50.6,-59.9,50.6,-54.9,48.8,-49.8,47,-48.1,47,-40.7,47,-36.4,56.4,-33.7,62.1,-29,77.2,-23.8,91,-16,97.9,-5.3,107.3,12.7,107.3,44.9,107.3,58.2,98.8,71.6,90.1,71.6,69.2,71.6,58.1,59.5,50.2,51.4,44.9,32.9,38.6,12.1,31.6,6.4,28.6,-5.6,22.5,-5.6,14.4,-5.6,6.4,4.2,0.4,12.4,-4.6,19.2,-4.6,23.9,-4.6,29.1,0.4,32.1,3.2,38.3,11.4,44.3,19.2,47.8,22.3,53.4,27.3,58.6,27.3,64.5,27.3,69.3,20,74.1,12.5,74.1,2.7,74.1,-8.4,69.7,-13.9,66.9,-17.4,59.9,-20.6,52.7,-23.8,50.2,-26.7,45.8,-31.8,45.8,-42.1,45.8,-43.6,48.8,-53.6,51.9,-63.7,51.9,-66,51.9,-72.8,45.8,-78.4,39.2,-84.4,29.7,-84.4,15.6,-84.4,4.6,-72.2,-1.1,-65.9,-12.6,-58.4]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-89.4,-94.2,161.8,144.8);


(lib.anim1_19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 145
	this.instance = new lib.square8_2("single",0);
	this.instance.parent = this;
	this.instance.setTransform(19.7,17.5);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 71, 172, 184, 0)];
	this.instance.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[19.7,17.4,19.9,25.3,20.3,31.5,20.6,38.4,22.9,43.8,27.2,54.3,27.2,68.8,27.2,81.6,20.4,91.3,13.1,101.7,2.3,101.7,-5.4,101.7,-16,97.1,-26.5,92.6,-35.4,85.8,-41.7,81,-45.3,69.3,-47.1,63.3,-47.8,60.7,-49.1,56.2,-50.3,54.3,-52.8,50.2,-59.3,48.6,-66.5,46.7,-69.3,43.9,-76.4,36.8,-78.2,33.5,-81,28.2,-81,18.6,-81,7.4,-75.9,2.3,-72.9,-0.7,-63.4,-4.3,-53.4,-8.1,-48.1,-12.6,-39.4,-20,-34.2,-34.1,-28.2,-50.8,-26.5,-54.8,-21.9,-66.2,-17.1,-73.2,-5.1,-91.4,14.9,-91.4,28.9,-91.4,42,-84,56.1,-75.9,56.1,-65.5,56.1,-57.3,47.7,-42.5,38.3,-26.2,37,-18.1,36.1,-12.5,36.1,-5.5,36.1,1.5,20.6,16.1]}},79).wait(1));

	// Layer 144
	this.instance_1 = new lib.octagon6("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-83.3,8.6);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 71, 172, 184, 0)];
	this.instance_1.cache(-44,-44,88,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-83.2,8.7,-80.6,20.1,-79.3,25.9,-78,31.6,-72.3,40,-66.6,48.4,-58.9,53.2,-51.1,58.1,-45.4,58.1,-44.6,58.1,-39.7,57.5,-34.8,56.9,-34,56.9,-26,56.9,-17.6,62.3,-13.2,65.2,-3.2,74.1,6.3,82.5,12.3,86,21.6,91.4,31.4,91.4,39.6,91.4,46.8,84.6,54.8,77.1,54.8,66.1,54.8,53.2,44.6,30.1,39.6,19,37.6,14.6,34.5,7.4,34.5,4.9,34.5,-3.3,38.6,-9.6,40.9,-13.1,47.7,-19.5,54.2,-25.5,56.8,-30,60.9,-37,60.9,-46.4,60.9,-56.7,54.1,-63.7,46.8,-71.1,34.5,-71.1,23.5,-71.1,5.6,-55.9,-5.2,-46.9,-7,-45.5,-13.3,-40.9,-17.1,-40.9,-20.5,-40.9,-26,-43.1,-27.1,-43.5,-36.7,-47.9,-52.2,-55.1,-62.6,-55.1,-73.9,-55.1,-80.5,-45.8,-87.2,-36.4,-87.2,-20,-87.2,-14.4,-86,-5.4,-84.8,3.3,-83.6,6.9]}},79).wait(1));

	// Layer 143
	this.instance_2 = new lib.heptagon("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(4.2,-74.4);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 71, 172, 184, 0)];
	this.instance_2.cache(-45,-44,90,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:3,y:-74.1},79).wait(1));

	// Layer 142
	this.instance_3 = new lib.pentagon2("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-1.7,51.2);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 71, 172, 184, 0)];
	this.instance_3.cache(-40,-38,80,76);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[-1.7,51.2,0,52.6,0.1,52.7,6.5,59,8.5,61.8,12.3,67,12.3,72.2,12.3,85.4,0.7,97.5,-11,109.8,-24.5,109.8,-33.2,109.8,-43.6,103.8,-53.6,98,-62.6,88.2,-71.7,78.2,-77.1,66.8,-82.9,54.5,-82.9,43.3,-82.9,27.2,-76.6,19.2,-73.1,14.6,-63,9.3,-53.6,4.4,-50.2,-1.1,-44.7,-9.9,-45.9,-27.3,-47.3,-48.4,-41.6,-66.6,-33.9,-91.4,-19.7,-93,-5.9,-94.7,-2.8,-76.6,-2.7,-76.1,-2.7,-75.6,-1.2,-58.4,9.7,-45.4,18.5,-35,36.4,-23.2,36.8,-22.9,50.6,-14.2,58.7,-9.1,63.1,-5.7,75.2,3.6,75.2,11.6,75.2,23.3,64.7,31,55.4,37.8,44.6,37.8,41.1,37.8,35.9,35.3,35,34.9,25.6,29.8,10.9,21.8,-0.3,21.8,-6.9,21.8,-9,23,-12.1,24.7,-12.1,30.4,-12.1,36.9,-8.2,42.9,-6.3,45.9,-2.6,50]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-125,-116.4,177.5,203.6);


(lib.anim1_18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 137
	this.instance = new lib.square8_2("single",0);
	this.instance.parent = this;
	this.instance.setTransform(11.8,45);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 152, 12, 100, 0)];
	this.instance.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[12,44.9,12.7,45.1,19.2,47.1,27.9,49.2,35.6,49.2,49.4,49.2,67.3,42.4,84.7,35.8,94.8,27,105,18.2,109.1,6.5,112.6,-3.5,112.6,-19.1,112.6,-35.1,99.4,-51.7,95.7,-56.3,88.4,-64.1,81.5,-71.3,79.3,-74.4,71,-85.6,50.5,-93.5,34.4,-99.7,26.3,-99.7,10.2,-99.7,-5.2,-93.9,-23.7,-87,-33.8,-73.8,-37.7,-68.6,-46.3,-60.2,-56.3,-50.6,-59.7,-46.7,-64.7,-40.9,-71.1,-29.4,-79.3,-14.9,-79.3,-7.4,-79.3,3.7,-67.6,15.9,-64.1,19.6,-57.7,25,-51,30.8,-49.2,32.5,-42.9,38.8,-20.4,41.4,-9,42.7,9.2,44]}},79).wait(1));

	// Layer 136
	this.instance_1 = new lib.square8_2("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-1.5,83.6);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 152, 12, 100, 0)];
	this.instance_1.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-1.4,83.6,0.6,84.3,2.6,85,26.6,92.9,41.8,92.9,55.1,92.9,71,83.6,88.6,73.3,92.3,60.3,93.9,54.3,96.8,35.2,100.3,12.9,100.3,2.2,100.3,-15.4,95,-24.8,89.2,-35.5,71.4,-46.7,59.4,-54.3,37.5,-59.4,17.4,-64,0.9,-64,-6.5,-64,-18.2,-60.2,-29.8,-56.5,-35.3,-56.5,-38.6,-56.5,-55.6,-59.3,-72.7,-62.1,-76.6,-62.1,-86.6,-62.1,-92.9,-52.3,-99,-42.7,-99,-28,-99,-14,-89.9,4.4,-85.1,13.5,-83.1,17.4,-79.6,24.1,-78.7,27.6]}},79).wait(1));

	// Layer 135
	this.instance_2 = new lib.triangle("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-36.5,-35.2);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 152, 12, 100, 0)];
	this.instance_2.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-36.4,-35.2,-31,-33.7,-24.8,-33.7,-20.3,-33.7,9,-37.4,38.4,-41.2,51.3,-41.2,71,-41.2,78.8,-34.1,84.4,-29.2,88.5,-14,91.3,-3.9,92,10.7,92.2,15.4,92.2,31,92.2,45.9,91.8,50,91,56.4,87.9,60.7,85.3,64.2,77,71.3,61.2,84.6,55.3,89.8,47.6,96.7,20.2,97.6,-7.3,98.5,-21.7,100.9,-36.3,103.3,-56.6,102,-77,100.6,-83,93.9,-89.1,87.2,-99.1,75,-109.2,62.8,-110.2,57.3,-111.3,51.9,-108.7,45.3,-104.5,34.7,-103.3,30.2,-102.1,25.7,-100.9,17.5,-99.6,8.1,-99,3.7,-99.8,-11,-86.8,-22.5,-74.7,-33.1,-60.9,-33.1,-57.2,-33.1,-55.8,-34.3,-54.5,-35.4,-38.1,-35.5]}},79).wait(1));

	// Layer 134
	this.instance_3 = new lib.circle("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(32,-35.6);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 152, 12, 100, 0)];
	this.instance_3.cache(-38,-38,77,77);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[32,-35.6,43.6,-25.4,37.5,-18.8,31.3,-12.1,41.9,-2.2,54.9,9.8,60.9,17.3,71.2,30.1,71.2,39.2,71.2,68.7,46.6,78.8,35.9,83.1,18.7,84.8,5.4,86.1,-17.1,86.1,-25.4,86.1,-36.5,88.6,-47.6,91.1,-49.8,91.1,-62.4,91.1,-74.8,72,-79.8,64.2,-82.9,55.7,-86,47.3,-86,41.7,-86,34,-88.3,24.8,-89.5,20.2,-93.4,8.2,-100.7,-14.7,-100.7,-30.7,-100.7,-37.4,-96.7,-44.7,-92.8,-51.8,-86.1,-57.8,-70.9,-71.2,-52.8,-71.2,-39.7,-71.2,-14.5,-60.9,11.4,-50.4,30.7,-36.8]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.5,-76.7,152.7,193.1);


(lib.anim1_17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 129
	this.instance = new lib.hexagon2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(57.9,45.1);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 204, 200, 28, 0)];
	this.instance.cache(-50,-44,101,88);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[57.9,45.1,64.1,42.4,70,35.2,78.8,24.7,78.8,15.9,78.8,8.5,75.5,0.1,73.5,-5.4,68.2,-15.3,62.2,-26.4,59.9,-31.6,55.6,-41.4,54.1,-50.4,50,-73.7,37.4,-86.3,24.2,-99.6,2.9,-99.6,-12.5,-99.6,-27.6,-86.3,-41.9,-73.7,-47.9,-56.5,-53.7,-39.5,-61,-29.3,-64,-25,-72.4,-16.9,-78.2,-11.1,-80.4,-4.9,-83.5,3.7,-83.5,20.7,-83.5,42.5,-65.1,54.1,-49.5,63.9,-25.8,63.9,-3,63.9,20.3,57.7,26,56.2,34.5,53.5,36,53,56,46]}},79).wait(1));

	// Layer 128
	this.instance_1 = new lib.heptagon("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(29.1,-45.4);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 204, 200, 28, 0)];
	this.instance_1.cache(-45,-44,90,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[29.1,-45.3,95.9,-26,95.9,13.6,95.9,21.3,77.1,36.8,60.7,50.4,34.3,66.6,9.7,81.7,-12.3,92.3,-35.1,103.2,-42.7,103.2,-58.2,103.2,-73.8,83.7,-80.3,75.5,-84.3,66.6,-88.4,57.8,-88.4,51.5,-88.4,36.8,-73.5,19,-60.9,3.9,-39,-12.1,-20.8,-25.5,-0.4,-36.5,17.5,-46.3,27.8,-45.5]}},79).wait(1));

	// Layer 127
	this.instance_2 = new lib.triangle("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-72.4,-36.2);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 204, 200, 28, 0)];
	this.instance_2.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:-73.7,y:-35.8},79).wait(1));

	// Layer 126
	this.instance_3 = new lib.square8_2("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-40.2,62.6);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 204, 200, 28, 0)];
	this.instance_3.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[-40.1,62.6,-10.2,73.8,-4.7,74.9,8.1,77.5,24.5,77.5,70.6,77.5,95.9,56.6,118.1,38.2,118.1,10.3,118.1,-8.7,104.6,-22.9,99.3,-28.5,89,-36.7,76.2,-46.6,68.7,-52.7,66.8,-54.2,48,-70.1,36.9,-79.4,30.1,-84.2,11.5,-97,-6.8,-97,-24.3,-97,-51.5,-78.2,-66.1,-68.1,-87.2,-50.3,-97.8,-42.1,-103.2,-35.9,-110.1,-27.9,-111.9,-19.5,-112.3,-17.9,-118.8,3.4,-124.1,20.9,-124.1,25.8,-124.2,36.6,-116.3,42.1,-108.4,47.5,-97.6,51.4,-86.9,55.3,-70,57.1,-53.2,58.9,-41.8,61.7]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-120.4,-87.4,226.5,182.7);


(lib.anim1_16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 121
	this.instance = new lib.circle("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-31.6,77.7);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 204, 0, 0)];
	this.instance.cache(-38,-38,77,77);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[-31.5,77.6,-41.4,74.8,-49.7,72.2,-65.4,67.3,-77,61.9,-112.9,45.3,-112.9,22.9,-112.9,14.1,-108.1,5.4,-104.9,-0.3,-96.6,-10.4,-86.8,-22.2,-82.7,-28.3,-74.9,-39.9,-70.6,-52.2,-67.9,-60.4,-65.1,-72.7,-62.1,-85.5,-60.9,-89.3,-58.4,-97,-54.6,-100.5,-50.4,-104.5,-43.1,-104.5,-21.4,-104.5,2.8,-92,11.3,-87.6,22.4,-80.4,34.4,-72.5,39.9,-69.1,45.3,-65.6,59.2,-58.1,71,-51.7,76.8,-47.5,94.5,-34.6,94.5,-15.3,93.8,1.2,93.8,3.1,93.8,19.9,89.8,34.8,84.2,56,72.2,63.8,58.4,72.8,43.6,78,29.4,83,19.1,83,8.5,83,-4.2,82.2,-16.8,81.4,-29.9,78.2]}},79).wait(1));

	// Layer 120
	this.instance_1 = new lib.rectangle("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(50,-39.9);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 204, 0, 0)];
	this.instance_1.cache(-50,-35,100,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[49.9,-39.8,56.3,-33.1,62.1,-15.9,68.4,3,68.4,19.5,68.4,35.7,58.8,50,49.6,63.8,29.1,79.2,19.6,86.4,15.4,88.8,6.7,93.7,-3.1,95.4,-33.1,100.8,-40.3,100.8,-61.9,100.8,-73.4,85.1,-77.7,79.2,-81.1,70.4,-82.6,66.5,-86.1,55.3,-88.1,48.9,-89.4,37.1,-90.7,24,-91.4,18.4,-92.3,11.6,-96.8,-2.5,-100.7,-14.6,-100.7,-22.9,-100.7,-28.6,-88.7,-45.2,-82.7,-53.4,-76.8,-60.6,-71.4,-65.8,-56.2,-69.5,-42.7,-72.9,-32.2,-72.9,-11,-72.9,8.2,-66.7,24.9,-61.3,48.8,-40.8]}},79).wait(1));

	// Layer 119
	this.instance_2 = new lib.triangle("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-82.9,-10.6);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 204, 0, 0)];
	this.instance_2.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-82.6,-10.4,-83.7,8.8,-75.2,21.2,-62.7,39.3,-46.7,59.6,-28.3,82.9,-15.3,90.2,-1.2,98.1,24.6,98.1,58.1,98.1,71.6,81.1,82.2,67.7,82.2,39.6,82.2,39.5,81.5,29,80.7,18.5,80.7,13.4,80.7,8.8,79.6,-1.9,78.4,-12.6,78.4,-17.6,78.4,-22.9,79.9,-36.1,81.5,-49.3,81.5,-54.9,81.5,-76.1,45.4,-94.1,31.7,-101.1,16.6,-105.5,2.9,-109.5,-4.5,-109.5,-36,-109.5,-53.1,-105.8,-69.2,-102.4,-76,-94.9,-81.8,-88.5,-82.8,-76.5,-82.9,-74.8,-82.9,-50.6,-82.9,-40.1,-82,-28.8,-81.4,-20.9,-80.7,-17.4]}},79).wait(1));

	// Layer 118
	this.instance_3 = new lib.pentagon2("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(37.5,63.9);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 204, 0, 0)];
	this.instance_3.cache(-40,-38,80,76);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:31.7,y:64.1},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-130.9,-72.6,229,186.6);


(lib.anim1_15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 113
	this.instance = new lib.triangle("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-39.3,-8.5);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 204, 204, 0)];
	this.instance.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-47.3,y:-4},79).wait(1));

	// Layer 112
	this.instance_1 = new lib.pentagon2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-34.3,78.8);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 204, 204, 0)];
	this.instance_1.cache(-40,-38,80,76);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-34.3,78.7,-34.1,78.8,-33.9,78.8,-24.9,81.5,-15.3,87.1,-9.6,90.4,1,97.3,10.5,103.2,18.1,105.9,28.3,109.5,39.8,109.5,66.9,109.5,87.3,99.6,110.7,88.3,110.7,69.3,110.7,56.4,102.1,45.6,98.9,41.7,93.2,36.3,86.5,30.1,83,26.7,70.1,14.1,63.9,1.1,55.3,-17.2,55.3,-43,55.3,-81.2,4.2,-81.2,-11.1,-81.2,-18.6,-77.5,-24.6,-74.6,-29.7,-66.7,-35.9,-56,-41.1,-49,-50.5,-36.3,-65.1,-24.4,-73.7,-17.4,-84.4,-12,-90.2,-9.1,-99.5,-4.7,-106.5,-1,-109.5,3.6,-113,9.2,-113,19,-113,29,-100.5,41,-90,51.2,-79.9,55.3,-70,59.3,-59,68.9,-54.4,72.9,-51.8,74.5,-48.1,76.7,-43.8,77.3]}},79).wait(1));

	// Layer 111
	this.instance_2 = new lib.rectangle("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(38.3,64.8);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 204, 204, 0)];
	this.instance_2.cache(-50,-35,100,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:30.6,y:63.4},79).wait(1));

	// Layer 110
	this.instance_3 = new lib.octagon6("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(13.4,-42.9);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 204, 204, 0)];
	this.instance_3.cache(-44,-44,88,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[13.5,-42.9,16.1,-40.2,31,-33.6,54.1,-23.2,60.6,-20,100.8,0,100.8,16.6,100.8,17.2,96.5,33.4,92.2,49.8,92.2,55.3,92.2,56.8,93.5,64.8,94.7,72.8,94.7,74.3,94.7,89.5,87.4,94.7,82.2,98.4,69.4,98.4,60.5,98.4,49.5,92.8,44.2,90.1,41.9,89,38,87.3,35.5,87.3,31.8,87.3,13,92.8,-5.6,98.4,-12.1,98.4,-18.8,98.4,-27.8,96.7,-38.8,94.7,-47.8,91.1,-72.4,81.1,-72.4,63.2,-72.4,61.7,-71.2,59.3,-70,56.8,-70,55.3,-70,51.7,-73.9,45.5,-75,43.6,-82.3,33.4,-94.5,16.1,-94.5,6.1,-94.5,-13,-73.6,-26.9,-64.9,-32.7,-54.6,-36.1,-44.6,-39.3,-36.1,-39.3,-36,-39.3,-23.3,-36.8,-10.6,-34.3,-8.4,-34.3,-6.8,-34.3,-3.2,-35.5,0.3,-36.8,1.9,-36.8,3.9,-36.8,5.9,-36,6.6,-35.7,7.2,-35.3,8,-34.9,8.6,-34.3,8.6,-34.3,8.6,-34.3]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-87.3,-84.7,173.6,199.5);


(lib.anim1_14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 105
	this.instance = new lib.heptagon("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-39.5,82.7);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 102, 204, 255, 0)];
	this.instance.cache(-45,-44,90,88);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[-39.4,83.1,-34.8,83,-13.8,83.3,-0.7,83.5,6.8,81.8,16.8,79.5,26.3,72.4,36.5,64.7,49.2,49.2,54.8,42.3,61.2,31.5,64.6,25.9,68.9,18.4,72.8,12.3,74.4,5.3,75.7,-0.3,75.7,-7.9,75.7,-25.8,71.1,-34.9,65.5,-46,52.3,-47.3,52.2,-47.3,34,-48.1,21.3,-48.6,14.7,-50.4,0,-54.3,-34,-60,-66.4,-65.5,-69.2,-64.3,-69.4,-64.1,-69.4,-64,-68.8,-64,-68.2,-64,-68.6,-64.2,-69.2,-64.3,-73.7,-65.1,-86.1,-58.2,-98.2,-51.5,-101.5,-47.9,-108.9,-39.9,-111.7,-27.8,-113.8,-19.4,-113.8,-7.3,-113.8,5.2,-112.8,12,-111.6,19.8,-108.5,26,-105.7,31.7,-99.4,39.3,-95.7,43.9,-83.6,57.2,-74.8,66.9,-64.2,74.4,-53,82.3,-45.3,83.6]}},79).wait(1));

	// Layer 104
	this.instance_1 = new lib.circle("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-88.9,-28.3);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 102, 204, 255, 0)];
	this.instance_1.cache(-38,-38,77,77);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-88.9,-28.3,-86.3,-28.5,-75.3,-32,-70.2,-33.6,-67.7,-34.1,-65.2,-34.5,-65.2,-33.7,-65.8,-33.7,-66.4,-33.7,-50.5,-31.8,-38.5,-25.7,-33,-23,-20.2,-13.8,-9.4,-6.1,-0.6,-2.9,12.6,1.9,31.3,1.9,41.4,1.9,57.6,-1.8,73.8,-5.5,76.5,-5.5,114.4,-5.5,114.4,49.5,114.4,54.7,114.8,62.2,114.9,68,114,71.5,112.1,79.5,99,94.2,93.9,100,91,102.3,88.1,104.7,87.5,103.6,86.2,101.4,90.5,88.2,94.8,75,74.9,81.2,50.6,104.7,47.2,73.2,43.8,41.7,11.1,72,-2.4,90.6,-10,89.9,-17.7,89.3,-32.7,89.6,-47.6,90,-54.1,89.8,-66.4,89.5,-88.4,90.9,-106.1,91.2,-113.8,85.5,-121.4,79.8,-125.6,64.7,-129.1,52.1,-129.1,38.7,-129.1,11.7,-115.6,-2.5,-112,-6.3,-104.3,-11.9,-98.2,-16.3,-95.5,-19.3]}},79).wait(1));

	// Layer 103
	this.instance_2 = new lib.rectangle("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-32,-55.3);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 102, 204, 255, 0)];
	this.instance_2.cache(-50,-35,100,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-31.9,-55.3,-13.6,-55.3,4.8,-55.3,23.1,-49.6,33.4,-40.7,41.7,-33.6,45.9,-23.2,47,-20.4,51.2,-5.3,54.1,5.1,58.5,10.6,59.7,12.1,71.8,26.5,79.1,35.3,83,41.1,93.6,57.1,93.6,74.8,93.6,90.4,83.8,96,75.2,100.9,52.9,101,49.6,101,26,98.2,2.5,95.4,2.2,95.4,-6.4,95.4,-28.9,97.3,-51.4,99.2,-57.5,99.2,-76.4,99.2,-86.6,88.7,-97.1,78,-97.1,57.9,-97.1,31.4,-88.8,18.4,-85.7,13.4,-79.5,7.2,-67.7,-4.6,-67.5,-4.8,-65.8,-6.6,-60.8,-17,-56.5,-25.8,-53.4,-33.1,-52.5,-35.4,-51.5,-39.5,-50.6,-43.1,-49.7,-44.8,-48.7,-46.7,-44.8,-47.9,-43.4,-48.3,-39.4,-49.1]}},79).wait(1));

	// Layer 102
	this.instance_3 = new lib.triangle("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-52.6,-16.6);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 102, 204, 255, 0)];
	this.instance_3.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[-52.5,-16.5,-42,-21.1,-28,-26.2,-19.3,-29.3,-16.9,-30.1,-10.3,-31.8,-3.6,-31.8,-0.7,-31.8,9.3,-29.4,20.3,-26.8,21.5,-25.1,22.9,-23,25,-18.3,26.4,-15.2,28.3,-14,31.8,-11.6,43.9,-9,58.2,-5.9,61.5,-4.7,79.4,1.9,84.7,16,86.7,21.2,87.1,28.2,87.3,30.7,87.3,39.7,87.3,43.1,87.5,48.6,87.4,52.8,86,55.9,82.8,63.2,67,73.3,62.4,76.2,49.1,80.3,34,85,25.2,85,21.9,85,20.1,83.1,17.7,80.4,15.3,79.5,13.9,78.9,10.4,78.8,6.9,78.8,6.1,78.8,-1,78.8,-18.1,83.8,-35.2,88.7,-46.6,88.7,-67.6,88.7,-77.5,63.4,-80.8,55,-82.5,44.6,-83.6,37.4,-83.6,32.9,-83.6,16.1,-76.8,2.8,-70.2,-9.9,-60.2,-13.7]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-125.2,-88.1,141.3,212.8);


(lib.anim1_13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 97
	this.instance = new lib.pentagon2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(50.9,46.9);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 204, 102, 0, 0)];
	this.instance.cache(-40,-38,80,76);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:54.3,y:45.4},79).wait(1));

	// Layer 96
	this.instance_1 = new lib.square8_2("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-30.5,72.9);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 204, 102, 0, 0)];
	this.instance_1.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-30.5,72.9,39.8,96.5,61.4,97.5,83.5,98.4,87.8,95.7,91.4,93.4,91.7,88.2,91.3,81.1,91.2,76.8,91.1,68.9,93.5,62.7,96.4,55.4,98.1,44,99.6,32.9,99.6,20.9,99.6,-3.1,98.8,-13.6,97.4,-32.8,92.3,-51.4,89.5,-61.8,68.6,-74.5,47.7,-87.2,33.7,-87.2,31.4,-87.2,21.2,-83.7,7.4,-78.9,-0.7,-76.1,-33.1,-65,-45.4,-65,-69.1,-65,-77.5,-66.9,-86,-68.8,-106.3,-68.8,-116.4,-68.8,-125.4,-53.9,-128.6,-48.6,-130.8,-42.7,-132.7,-37.6,-132.7,-35.5,-132.7,-24.7,-122.7,3.8,-113.4,30.2,-108.2,38.1,-106.6,40.5,-104.5,45.8,-102.3,51.1,-100.7,53.7,-94.8,62.9,-79.9,66.4,-70.8,68.6,-60.8,70.4,-48.6,72.5,-43.5,72.5,-40.8,72.5,-38.6,72.4]}},79).wait(1));

	// Layer 95
	this.instance_2 = new lib.rectangle("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(2.5,-39.3);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 204, 102, 0, 0)];
	this.instance_2.cache(-50,-35,100,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[2.5,-39.3,7.3,-29.2,19.2,-25.1,28.6,-21.9,44.8,-21.9,51.1,-21.9,64.8,-24.4,78.4,-26.9,81.7,-26.9,93.4,-26.9,96,-20.7,97,-18,97.2,-13,97.2,-6.4,97.2,-2.4,97.2,8.3,95.6,14.7,94,21,89.9,26.5,86.7,30.9,78.9,38.4,61.8,54.9,61.4,55.3,52,64.6,35.8,72.5,21.6,79.3,5.4,83.5,-9.6,87.5,-19.9,87.6,-25.2,87.7,-27.9,86.7,-30.5,85.7,-30.5,83.7,-26.3,83.7,-22,83.7,-62.4,82.9,-80,77.9,-95,73.6,-99.5,63.9,-103.5,55.4,-108.5,45.9,-112.7,38.2,-113.7,35.5,-116.7,28.3,-116.7,11.1,-116.7,-6.3,-113.1,-14.1,-109.1,-22.6,-94.5,-34.3,-92.1,-36.2,-84.7,-37.5,-75.7,-39.2,-72.4,-40.5,-65.6,-43.5,-60.8,-45.5,-51.8,-49.1,-47.8,-49.1,-41.4,-49.1,-36.5,-46.3,-34,-44.8,-28.7,-40,-24,-35.5,-20.1,-33.6,-14.5,-30.9,-6.8,-30.7]}},79).wait(1));

	// Layer 94
	this.instance_3 = new lib.octagon6("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-49.5,-7.4);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 204, 102, 0, 0)];
	this.instance_3.cache(-44,-44,88,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[-49.4,-7.3,-69.4,-10.3,-79.7,-0.8,-89.7,8.3,-89.7,28.4,-89.7,35.6,-87.2,44,-84.7,52.6,-84.7,54.1,-84.7,57.4,-85.9,61,-87.2,64.6,-87.2,65.2,-87.2,80.6,-74.9,91.1,-63.4,100.9,-49.1,100.9,-47.5,100.9,-34,99.7,-20.5,98.4,-18.9,98.4,-1.8,98.4,5.8,102.7,9.9,105,12.4,105.7,17.2,107,25.8,107,42.3,107,50.8,103.4,63.2,98.2,67.7,83.8,71.2,72.3,75.4,68.9,78,66.8,84.8,63.9,93.1,58.7,95.7,52.2,97.2,48.4,97.2,40.7,97.2,27.3,86.7,19.5,83,16.8,75.7,13,65.2,7.6,62.7,6.2,54.3,1.5,47.9,-4.5,45,-7.3,39.3,-13.9,35,-18.8,32.2,-20.6,28.1,-23.1,22.2,-23.1,10.6,-23.1,-1.1,-20.7,-14.3,-17.9,-36.3,-17]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-91.3,-72.1,180,177.8);


(lib.anim1_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 88
	this.instance = new lib.pentagon2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(73.9,27.3);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 255, 0, 0)];
	this.instance.cache(-40,-38,80,76);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:68.2,y:40.9},79).wait(1));

	// Layer 87
	this.instance_1 = new lib.octagon6("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-53.9,38.1);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 255, 0, 0)];
	this.instance_1.cache(-44,-44,88,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-51.7,y:48.4},79).wait(1));

	// Layer 86
	this.instance_2 = new lib.circle("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(48.8,-65.3);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 255, 0, 0)];
	this.instance_2.cache(-38,-38,77,77);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:34.8,y:-71.7},79).wait(1));

	// Layer 85
	this.instance_3 = new lib.triangle("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-44.8,-61.5);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 255, 0, 0)];
	this.instance_3.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[-44.7,-61.5,-30,-69.6,-22,-71.1,-18.8,-71.7,-3.3,-71.7,13.4,-71.7,19.8,-71.3,30.2,-70.6,36.8,-68.1,44.3,-65.3,50,-59.3,55.9,-53.2,61.5,-42.2,70.9,-23.5,80.9,-8.2,86.3,0.3,94.5,11.7,100.4,20.2,102.5,26.4,105.2,34.1,105.2,45.5,105.2,71.8,87.1,87.1,70.4,101.2,44.7,101.2,38.6,101.2,30.5,98,26.2,96.3,15.5,91,5.6,86,-0.2,84,-9.1,80.8,-16.6,80.8,-26.7,80.8,-50.1,86.6,-73.5,92.3,-78.7,92.3,-106.4,92.3,-117.9,66.7,-125.5,49.5,-125.5,21.6,-125.5,-14.7,-89.5,-38.8,-79.2,-45.7,-64.9,-52.1,-62.3,-53.2,-60.3,-54.1,-53.6,-57.2,-53.6,-57.6,-52.9,-57.6,-52.2,-57.6,-50.5,-57.6,-48.8,-57.6]}},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-95.7,-103,207.3,182.9);


(lib.anim1_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 2
	this.instance = new lib.triangle("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(40.8,-18.8);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 95, 118, 1, 0)];
	this.instance.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:37.5,y:-17.9},79).wait(1));

	// 7
	this.instance_1 = new lib.hexagon2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-1.7,-60.8);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 95, 118, 1, 0)];
	this.instance_1.cache(-50,-44,101,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-1.7,-60.7,-0.9,-61.3,0,-62.1,3.8,-65.6,12.5,-74.8,21.1,-83.2,29.4,-87.6,40.6,-93.3,53.8,-93.3,79.3,-93.3,101.5,-76.5,111,-69.2,116.7,-61.1,122.3,-52.8,122.3,-45.9,122.3,-36.2,114,-31.3,105.8,-26.5,93.1,-28.6,89.1,-29.2,80.5,-29.1,69,-29,59.4,-27.3,30.8,-22.3,30.8,-5.7,30.8,5.6,32.4,10.2,34.1,15,38.7,16.4,42.3,17.5,51.8,17.1,68.3,16.6,73.8,16.6,95.1,16.9,103.5,18.4,119.3,21.4,119.3,30.4,119.3,35.1,116,40.9,114.1,44.2,108.9,51.2,103.7,58,101.7,61.7,98.4,67.7,98.4,72.8,98.4,75,101.2,84.4,103.9,93.9,103.9,94.3,103.9,103.5,93.4,108.2,82.9,112.8,61.9,112.8,52.8,112.8,51.9,112.8,46,112.4,42.3,110.5,32.3,105.5,32.3,87,32.3,77.2,40.8,70.4,45,67.3,46.6,65.9,49.2,63.6,49.2,61.3,49.2,56.8,45.6,50.8,41.8,44.4,35.3,38.9,19.3,25.1,-1.5,25.1,-4.3,25.1,-17.2,33.9,-29,41.9,-34.4,46.6,-40.3,51.7,-45.3,57,-48,59.8,-52,64.1,-58.4,70.4,-70.6,75.9,-79.2,79.7,-87.8,84.2,-92.3,86.6,-99.2,90.2,-108.9,95.1,-117.5,95.1,-130.7,95.1,-133.7,89.7,-135,87.4,-135.2,83.2,-135.2,78.7,-135.2,74.3,-135.2,49.1,-124.9,39,-117.6,31.9,-102.1,30.7,-93.8,30.4,-90,30.1,-83.2,29.6,-79.4,28.1,-69,24.2,-69,9.7,-69,2.6,-71.3,0.2,-72.1,-0.7,-76.6,-2.1,-80.5,-3.4,-82.7,-7,-86,-12.2,-87.6,-24,-90.2,-43.6,-84.8,-55.6,-77.2,-72.6,-54.1,-72.6,-52.4,-72.6,-47.6,-70.1,-41.2,-66.5,-37.3,-64.5,-22,-56.5,-11.7,-56.4]}},79).wait(1));

	// 9
	this.instance_2 = new lib.square8_2("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-102.8,21.4);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 95, 118, 1, 0)];
	this.instance_2.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-102.7,21.3,-94.3,16.8,-90.4,12,-84.5,4.9,-84.5,-6.1,-84.5,-14.8,-72.2,-28.7,-67.3,-34.2,-62.6,-38,-57.8,-41.8,-55.7,-41.8,-51.2,-41.8,-36.5,-36.8,-21.8,-31.8,-16,-31.8,-5.5,-31.8,1.3,-39,3.5,-41.2,7.2,-46.4,11.4,-52.1,13.8,-54.9,22.9,-65.4,36.5,-70.8,54.9,-78,84.9,-78,102.4,-78,106.6,-75.4,109,-73.8,110.8,-70.3,111.5,-68.7,114.5,-61,115.9,-57.4,118.6,-45.3,121.5,-32.3,121.5,-28.3,121.5,-13.6,112.7,-5.4,107.1,-0.1,93.4,5,78.7,10.4,74.1,13.9,65.3,20.6,65.3,32.7,65.3,46.2,73.6,50.8,78.3,53.3,91.9,54.1,105,54.9,110.2,58.2,118.5,63.6,118.5,78.5,118.5,89.8,103.9,96.6,92.1,102.1,79.5,102.1,74.4,102.1,67,97.7,57.5,91.7,51.7,88.2,28.1,74.3,0.7,74.3,-9.9,74.3,-20.6,76.7,-27,78.2,-38.8,82,-50.5,85.9,-56.9,87.3,-67.5,89.7,-78,89.7,-101.2,89.7,-113,72.7,-122.2,59.4,-122.2,40.7,-122.2,34.7,-117.6,30.3]}},79).wait(1));

	// 5
	this.instance_3 = new lib.circle("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-61.1,-28);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 95, 118, 1, 0)];
	this.instance_3.cache(-38,-38,77,77);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:-62.6,y:-7.8},79).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135.5,-102.8,224.4,156.9);


(lib.anim1_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 52
	this.instance = new lib.octagon10_3("single",0);
	this.instance.parent = this;
	this.instance.setTransform(18.8,89.5);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 246, 145, 5, 0)];
	this.instance.cache(-44,-44,88,88);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[18.8,89.5,9.9,89.8,0.1,87.8,-29.4,82,-23.7,64.8,-17.9,47.6,-29.2,17.7,-40.4,-12.3,-87.5,-19.5,-87.8,-21.9,-88,-27.9]}},19).to({guide:{path:[-88.1,-28.1,-88.6,-38.5,-89.2,-59.3,-90.1,-92.5,-47.9,-95.9,-24.6,-97.8,1,-98.6]}},20).to({guide:{path:[1,-98.5,21.5,-99.1,43.4,-99,92.4,-98.8,106.3,-59.3,96,-20.1,68.3,10.2,61.4,17.7,67.5,41.5,73.5,65.3,51.6,79.5,35.2,90.1,14.6,89.5]}},40).wait(1));

	// Layer 56
	this.instance_1 = new lib.rectangle10_3("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-22.6,-102.1);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 246, 145, 5, 0)];
	this.instance_1.cache(-50,-35,100,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-22.5,-102.1,-18.9,-104.6,-15,-107,-6.6,-104.3,-3.4,-97.2,8.4,-70.2,19.1,-42.3,57.4,-22.3,73.9,-20,90.3,-17.6,101,6.9,101.9,9,102.6,11]}},19).to({guide:{path:[102.7,11.2,111,34.5,102.8,66,93.8,100.5,44.6,97.9,24.4,96.8,8.4,97]}},20).to({guide:{path:[8.3,96.9,-14.7,97.2,-29,100,-53.1,104.8,-72.3,91.1,-91.5,77.4,-102.1,50.7,-112.8,23.9,-71.5,-13.7,-66.1,-18.7,-65.5,-25.1,-60.6,-73.7,-24.8,-100.5]}},40).wait(1));

	// Layer 60
	this.instance_2 = new lib.hexagon10_3("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-87.5,-9.4);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 246, 145, 5, 0)];
	this.instance_2.cache(-50,-44,101,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-87.4,-9.4,-83.5,-15.2,-78,-20.9,-61,-38.8,-60.9,-56.8,-60.9,-74.9,-45.7,-86.1,-30.7,-97.3,-12.8,-95.3,1.5,-93.8,13.5,-91.4]}},19).to({guide:{path:[13.6,-91.5,16.6,-90.9,19.4,-90.3,45.9,-72.5,60.5,-41.2,61.5,-39.1,65.8,-39.4,70.1,-39.6,77.7,-42.1,92.9,-47.1,97.2,-22.9,101.6,1.1,101.3,20.1,101,39.1,76.7,51.7,68,56.1,59.5,59.8]}},20).to({guide:{path:[59.5,59.8,43.8,66.6,28.4,70.9,4.6,77.5,-4.7,83.3,-14,89,-36.4,92.3,-58.8,95.6,-86,55.7,-108.1,23.4,-89.1,-6.9]}},40).wait(1));

	// Layer 62
	this.instance_3 = new lib.circle10_1("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-103,70.9);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 246, 145, 5, 0)];
	this.instance_3.cache(-38,-38,77,77);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[-102.9,70.8,-104.3,65.8,-104.3,60.1,-104.3,45.6,-97.6,33,-93.2,24.7,-83,12.9,-71.7,-0.1,-68.3,-5.3,-61.7,-15.9,-61.7,-27,-61.7,-28.5,-62.5,-29.1,-63.5,-30,-66.3,-30,-72.4,-30,-78.8,-26.7,-82.8,-24.7,-89.7,-19.5,-96.9,-14.2,-100.4,-12.3,-106.5,-9,-112.2,-9,-115.1,-9,-118.4,-13.1,-121.8,-17.4,-121.8,-21.6,-121.8,-42.3,-88.5,-66.3,-77.8,-74,-65.7,-80.6]}},19).to({guide:{path:[-65.8,-80.5,-64.5,-81.2,-63.3,-81.9,-51.9,-87.8,-46.7,-89.2,-37.7,-91.7,21.1,-96.4,80,-101,58.5,-59.2,55.2,-58.1,52.3,-56.7]}},20).to({guide:{path:[52.3,-56.6,45.6,-53.3,41.4,-48.2,31.6,-36.3,31.6,-12,31.6,-0.6,38.9,3.8,41.6,5.4,46.4,6.8,49.2,7.6,55.1,9.2,65.9,12.7,71.2,20.5,78.5,31.3,76.2,54.6,74,77.8,52.8,85.8,31.6,93.8,27,95.2,22.4,96.7,2.1,100.5,-8,102.4,-13.6,100.8,-19.3,99.3,-20.6,94.4,-22.2,83.5,-23.2,79.5,-25,72.7,-30.8,72.7,-35.9,72.7,-39.1,76.7,-39.7,77.5,-44.1,85.7,-47.3,91.7,-51.4,94.6,-57.2,98.6,-66.7,98.6,-79.7,98.6,-90.9,89.4,-98.1,83.5,-101.5,75.5]}},40).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-157,-145,314.1,290.1);


(lib.anim1_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 34
	this.instance = new lib.pentagon9_1("single",0);
	this.instance.parent = this;
	this.instance.setTransform(-20.8,-100.5);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 128, 128, 255, 0)];
	this.instance.cache(-40,-38,80,76);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[-20.8,-100.4,-32,-99.6,-45,-95,-59.5,-89.8,-72.8,-81.1,-86.1,-72.4,-94,-62.8,-102.4,-52.7,-102.4,-44.4,-102.4,-32.4,-94.7,-23.7,-86.9,-14.8,-75.4,-14.8,-68.6,-14.8,-63.4,-16.5,-58.2,-18.3,-55.9,-18.3,-48.7,-18.3,-44.4,-16,-39.2,-13.1,-39.2,-6.8,-39.2,-1.6,-42.1,1.8,-45.2,5.3,-50.1,5.3,-51.7,5.3,-57.1,4.4,-62.5,3.5,-64.2,3.5,-70.3,3.5,-74.7,5.3,-75.3,5.5,-75.9,5.8]}},19).to({guide:{path:[-75.9,6,-81.7,8.8,-82.3,14.9,-83.6,30.8,-87.1,42.4,-90,52,-90,60.1,-90,82.4,-72.8,93.6,-59.3,102.5,-39.4,102.5,-29,102.5,-24.2,101.4,-15.7,99.4,-7.1,92.4,-1.1,87.5,0.7,83.6,2.1,79,3.5,75.8,4.6,73.3,5.9,66.4,7.5,58,8.3,53.8,9.9,45.9,11.7,42,13.4,38.1,15.3,38.1,16.6,38.1,17.6,40,18.5,41.9,19.2,45.7,19.8,48.5,20.7,54.1]}},20).to({guide:{path:[20.9,54.1,21.4,57.6,22.1,62.2,27,86.5,42,86.5,48,86.5,59.1,84.4,69.4,82.5,75.2,80.6,78.1,79.6,83.6,73.7,85.1,72.2,90.6,65.7,93.6,62.2,99.4,41.6,105.5,19.9,105.5,10.1,105.5,-13.8,93.2,-23.6,88.2,-27.5,80.5,-29.8,75.7,-31.3,66.1,-32.9,55.9,-34.6,51.6,-35.8,43.8,-37.9,39,-41.4,26.7,-50.3,26.7,-72.7,26.7,-83.6,36.5,-90.3,37.6,-91.1,38.8,-91.8,35.8,-92.8,32.4,-93.8,8.7,-100.6,-16.1,-100.6,-19.5,-100.6,-23,-100.2]}},40).wait(1));

	// Layer 36
	this.instance_1 = new lib.circle9_3("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-107.5,-46);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 128, 128, 255, 0)];
	this.instance_1.cache(-38,-38,77,77);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-107.4,-46,-110.6,-35.5,-110.6,-22.7,-110.6,3.1,-102.9,16,-93.7,31.3,-72.2,31.3,-53.1,31.3,-35.1,21.3,-26.6,16.3,-22.8,14.4,-16.4,11.2,-11.2,11.2,-7.5,11.2,-5.9,12.5,-4.8,13.2,-4.7,14.4]}},19).to({guide:{path:[-4.6,14.5,-4.6,14.7,-4.6,14.9,-4.6,20.7,-11.1,27.7,-16.9,34,-26.5,39.8,-35.6,45.3,-44.7,48.5,-54.2,51.7,-59.7,51,-73.5,49.3,-83.7,51,-102.3,53.9,-102.3,67.5,-102.3,71.1,-98.4,77.3,-94.4,83.5,-88.2,89.4,-72.7,104.3,-58.8,104.3,-54.2,104.3,-11.4,100.3,33.2,96.1,45.6,94.2,62.6,91.7,79.7,85.8,94.1,80.8,103.1,72.5,110.3,65.8,113.8,53.9]}},20).to({guide:{path:[113.8,53.8,114.7,50.9,115.3,47.7,118.6,31.3,117.1,19.1,115.5,7,110.2,-1,104.9,-9,98,-13.9,91,-18.8,87.6,-19.5,84.1,-20.2,80.3,-20.9,76.4,-21.6,60.7,-27.3,45,-33.1,29.5,-41,15.4,-48.2,15.4,-63.9,15.4,-70.3,17.8,-82.6,18.4,-85.4,18.9,-87.8,13.9,-89.4,10.7,-90,-1.1,-92.3,-22.7,-92.3,-60.4,-92.3,-82.8,-78.1,-102.2,-65.8,-108.1,-43.7]}},40).wait(1));

	// Layer 38
	this.instance_2 = new lib.pentagon9_1("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-9.8,92);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 128, 128, 255, 0)];
	this.instance_2.cache(-40,-38,80,76);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-9.7,92.1,19.5,106.6,50,95.8,85.4,83.2,95.7,47,106.9,7.5,66.9,-5.8,63.7,-6.8,61.8,-8.9]}},19).to({guide:{path:[61.7,-9,59.4,-11.5,59.1,-15.5,56.5,-49.4,58.6,-83.4,53.9,-61.3,32.8,-56,27.2,-54.6,23.4,-58,11.5,-68.1,-11.5,-89.1,-12.3,-87.4,-13.1,-85.8]}},20).to({guide:{path:[-13.2,-85.8,-24.3,-64.5,-46.4,-51,-70,-36.4,-84.5,-69.2,-70.3,-16,-90.4,25.1,-110.5,66.3,-77.6,89.4,-45.1,112.2,-11.8,91.8]}},40).wait(1));

	// Layer 42
	this.instance_3 = new lib.heptagon9_1("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(84,91.4);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 128, 128, 255, 0)];
	this.instance_3.cache(-45,-44,90,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[84,91.4,81.5,92.7,78.4,93.7,67.8,97.2,58.3,97.5,48.9,97.7,39.4,95.6,30,93.6,22.2,84,14.4,74.5,7,64.9,0.5,56.8,-0.5,56.3,-0.5,56.9,-1.1,56.9,-0.6,57.9,0.8,64,2.4,70.9,2.4,73.7,2.4,82.1,-3.4,85.9,-8.8,89.4,-20,89.4,-24.2,89.4,-32.2,83.9,-40.1,78.3,-47.9,69.9,-58.2,59,-63.1,49.5]}},19).to({guide:{path:[-63.1,49.5,-67.4,41,-67.4,33.8,-67.4,25.9,-58.6,16.4,-54,11.4,-39.4,-1,-25.8,-12.4,-20.1,-19.3,-11.3,-29.8,-11.3,-39.5,-11.3,-52,-16,-58.5,-20.3,-64.4,-27.8,-64.4,-38.9,-64.4,-43.5,-54.8,-46.2,-48.8,-47.7,-33.6,-49.3,-18,-51.5,-12.5,-55.4,-2.9,-65.4,-2.9,-75.4,-2.9,-81,-14.7,-86.4,-25.8,-86.4,-44.3,-86.4,-77.2,-70.2,-88.2,-66.6,-90.7,-63.3,-92.5]}},20).to({guide:{path:[-63.3,-92.6,-52,-98.7,-44.8,-97,-35.6,-94.8,-19.6,-94.6,-3.6,-94.4,18.5,-95.9,40.7,-97.3,67.5,-85.8,86.4,-77.6,96.5,-63.8,95.5,-56.4,92.5,-48.5,89.7,-41.3,82.3,-27.5,74.9,-13.7,72.1,-6.5,67.5,5.5,67.5,16.5,67.5,30.4,71.6,40.2,74.5,47.4,80.5,53.9,83.8,57.4,89.5,63.4,93.6,68.6,93.6,74.6,93.6,77.8,91.4,83.7,89.6,88.7,82.9,91.9]}},40).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-157,-145,314.1,290.1);


(lib.anim1_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 36
	this.instance = new lib.pentagon8_1("single",0);
	this.instance.parent = this;
	this.instance.setTransform(29.6,-99);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 195, 3, 0, 0)];
	this.instance.cache(-40,-38,80,76);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[29.6,-99,29.8,-98.9,30,-98.8,41.1,-91.1,44.1,-72.8,47.1,-54.4,34.9,-31.9,33.2,-28.8,31.5,-25.7,34.3,-22.8,36.6,-19.8,37.3,-19,40.9,-17.3]}},19).to({guide:{path:[40.8,-17.1,49.3,-13.2,73.8,-4.8,108.6,7,108.2,39.4,107.9,71.6,65.6,86.4,23.4,101.2,10.4,99.5,-2.6,97.7,-14.7,98,-23.4,98.1,-44.6,95.5]}},20).to({guide:{path:[-44.5,95.4,-52.8,94.4,-62.9,93,-99,87.9,-113.1,55.8,-127.2,23.8,-86.2,-2.5,-45.2,-28.7,-38.3,-35.7,-53.8,-47.7,-49.4,-74.5,-44.9,-101.3,-13.1,-103.9,18.8,-106.5,30,-98.8,30.3,-98.5,30.6,-98.3]}},40).wait(1));

	// Layer 38
	this.instance_1 = new lib.hexagon8_1("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-39,-87.4);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 195, 3, 0, 0)];
	this.instance_1.cache(-50,-44,101,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-39,-87.4,-49.6,-80.9,-58.8,-66.6,-75.7,-40.3,-82.6,26.3,-84.8,47.6,-83.1,62]}},19).to({guide:{path:[-83.1,62.1,-79.3,93.1,-57.4,93.1,-25.3,93.1,-0.5,92.9,24.5,92.8,37.7,93.1,42.2,93.2,47.2,92.6]}},20).to({guide:{path:[47.2,92.6,42.2,93.2,37.7,93.1,24.5,92.8,-0.5,92.9,-25.3,93.1,-57.4,93.1,-73.5,93.1,-79.8,76.4,-86.1,59.7,-82.7,26.4,-75.8,-40.2,-58.8,-66.6,-50.1,-80.2,-39.9,-86.7]}},40).wait(1));

	// Layer 42
	this.instance_2 = new lib.circle8_1("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-14.4,79.3);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 195, 3, 0, 0)];
	this.instance_2.cache(-38,-38,77,77);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-14.3,79.3,-3,73.4,12.9,71,34.8,67.7,38.1,44.6,42.7,12.3,28.4,-18.2,25.2,-25.1,27.7,-32.4,29.5,-37.5,31.1,-42.7]}},19).to({guide:{path:[31.1,-42.8,34.5,-53.8,36.7,-65.1,38.2,-72.3,37.5,-79.7,33.9,-103,8.7,-102.8,5.3,-102.3,1.8,-101.9,1.6,-101.9,1.3,-101.9,-13.3,-99.6,-15.4,-93.4,-16.9,-89.2,-14.7,-85,-25.8,-82.8,-35.6,-80.1]}},20).to({guide:{path:[-35.6,-80,-25.9,-82.7,-14.7,-85,-16.9,-89.2,-15.4,-93.4,-13.3,-99.6,1.4,-101.8,1.7,-101.9,1.9,-101.9,5.3,-102.3,8.7,-102.7,33.9,-102.9,37.5,-79.6,38.2,-72.3,36.7,-65.1,33.4,-48.5,27.7,-32.3,25.1,-25,28.3,-18.2,42.6,12.3,38,44.7,34.8,67.8,12.9,71.1,-4.3,73.6,-16.1,80.3]}},40).wait(1));

	// Layer 44
	this.instance_3 = new lib.square8_2("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(77,-57.9);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 195, 3, 0, 0)];
	this.instance_3.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[77,-57.8,77.3,-53.7,77.3,-49.3,77.3,-33.3,72.9,-17.9,71,-11.1,68.8,-4.3]}},6).to({guide:{path:[68.9,-4.3,64.2,9.9,58.4,23.5,55.6,30.2,52.5,36.7,50.7,40.4,49.7,44.1,47.8,52.1,49.2,60.7,54.3,90.3,20.8,91]}},13).to({guide:{path:[20.7,91.1,19.8,91.1,18.9,91.1,-7.8,91,-33.3,84.3,-48.3,80.2,-64.2,77.2,-105.3,68.9,-94.2,35.6,-93.4,33.2,-94.4,25.3]}},20).to({guide:{path:[-94.4,25.2,-93.4,33.1,-94.2,35.5,-105.3,68.9,-64.2,77.2,-48.3,80.2,-33.2,84.3,-7.8,91,18.9,91.1,54.3,91.2,49.2,60.8,47.7,52.1,49.7,44.2,50.6,40.3,52.4,36.6,55.5,30.1,58.4,23.4,66.9,3.4,72.9,-17.8,77.3,-33.3,77.3,-49.3,77.3,-52.5,77.1,-55.6]}},40).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-157,-145,314.1,290.1);


(lib.anim1_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 41
	this.instance = new lib.hexagon7("single",0);
	this.instance.parent = this;
	this.instance.setTransform(22,89.4);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 69, 152, 0, 0)];
	this.instance.cache(-50,-44,101,88);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[21.9,89.4,4.9,93,-22.2,93.6,-59.3,94.5,-55.5,75.8,-51.7,57,-49.3,54,-37.3,38.9,-49.8,28.4,-67.3,39.9,-87.2,36.9,-100.3,34.7,-107.8,23.6,-112.1,17.3,-113.6,11.2]}},19).to({guide:{path:[-113.6,11.1,-116.6,-1.5,-107.5,-13,-103.1,-18.7,-96,-20.9,-58.4,-32.5,-19.8,-27.4,-18.5,-27.4,-17.2,-28.8,-5.6,-42,-17.1,-47,-20.6,-48.5,-24.5,-46.9,-38.6,-41.2,-53.1,-43.8,-58,-44.9,-57.7,-50,-56.3,-79.9,-29.2,-89.8]}},20).to({guide:{path:[-29.1,-89.8,-27.1,-90.6,-25,-91.2,-4.4,-97.4,19.3,-98.7,51.2,-99.5,71.6,-86.6,92,-73.6,99.7,-56.1,115.7,-19.6,78,-5.9,72.9,-4,67.5,-5.7,36,-15.8,4,-7,-13.4,-2.5,-4,10.7,13.3,34.7,42.4,43.9,51.5,46.8,51.6,63.2,51.6,79.7,33.4,86.2,29.2,87.8,23.9,89]}},40).wait(1));

	// Layer 43
	this.instance_1 = new lib.circle7("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(13.4,-98.6);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 69, 152, 0, 0)];
	this.instance_1.cache(-38,-38,77,77);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[13.5,-98.5,42,-102.3,70.6,-106.2,85.1,-105.3,85.6,-91.3,86.1,-80.5,76.5,-76.8,44.8,-64.8,12.7,-77.9,-7.3,-85.9,-11,-67.4,-12.9,-58,-4.2,-56.7,33.6,-51.2,72.4,-59.4,77.9,-60.5,82.3,-58.7]}},19).to({guide:{path:[82.3,-58.7,83.8,-58.1,85.1,-57.2,117.5,-35.8,92.7,-2.5,90,1.2,86.1,0.7,54.8,-11.6,30.4,-3.3,24.6,5.3,31.7,11.8,38.7,18.4,70.6,20.1,90.4,20.7,86.8,54.2,83.3,87.7,60.7,94.4,38.2,101,31.3,102.9,22.4,105.2,14.5,106]}},20).to({guide:{path:[14.4,106,-38.1,111.4,-47.6,51.7,-50.4,33.7,-39.3,19.9,-26.2,3.6,-19.9,-12.2,-16.8,-20.2,-24.6,-25.2,-32.4,-30.3,-51,-32.4,-88.4,-36.7,-82.3,-61.9,-76.3,-87.2,-54.4,-89.8,-32.5,-92.4,3.9,-97.2,9.4,-98,14.9,-98.7]}},40).wait(1));

	// Layer 45
	this.instance_2 = new lib.pentagon7("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-112.8,11.2);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 69, 152, 0, 0)];
	this.instance_2.cache(-40,-38,80,76);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-113.9,11.3,-113.7,26.8,-100,40.5,-79.8,60.5,-51.4,49.6,-29.1,41,-10.2,26.3,-2.4,41.4,-16.5,52.7,-30.7,64,-29.2,80.4,-27.7,96.7,-3.8,99,14.8,100.7,30.2,91.7]}},19).to({guide:{path:[30.3,91.7,34.9,89.1,39.1,85.5,57.9,69.9,40,35.7,34.8,25.8,37.5,14.8,45.4,-17.2,64.6,0.8,69.2,5.2,68.5,12.5,65.4,44.9,88.6,32.6,111.9,20.4,114.6,-7.8,116.6,-27.5,105.5,-40.2]}},20).to({guide:{path:[105.5,-40.3,100.8,-45.8,93.6,-49.9,69.8,-63.8,30.3,-65.2,10.9,-74.4,12.4,-88.2,14,-102,1.2,-101.8,-11.4,-101.6,-15.3,-88.7,-19.2,-75.9,-21.1,-66.8,-27.6,-35.6,-62.2,-36.5,-91.7,-37.4,-106.2,-13.4,-113.3,-1.7,-113.8,9.2]}},40).wait(1));

	// Layer 47
	this.instance_3 = new lib.heptagon7("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(101.1,5.2);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 69, 152, 0, 0)];
	this.instance_3.cache(-45,-44,90,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[101.1,5.3,99.8,9,98.2,12.8,83.2,48.1,63.3,49.9,43.6,51.8,38.6,41.6,33.5,31.5,25.7,24.5,24.2,23.3,23.9,27.4,23.5,31.6,24.3,41.1,25.9,60.1,21.8,83.8,17.8,107.6,-4.8,103.2,-8.3,102.6,-11.6,101.4]}},19).to({guide:{path:[-11.7,101.5,-29.3,95.4,-39.5,76.4,-51.5,53.9,-46.4,9.3,-50.7,10,-53.9,13.6,-63.4,23.9,-76.2,26.8,-89,29.7,-98.2,13.4,-100.3,9.7,-101.8,5.3]}},20).to({guide:{path:[-101.9,5.2,-107.2,-9.8,-106.2,-32.8,-105,-62.3,-60.7,-58.3,-16.4,-54.3,-15.1,-80,-13.8,-105.6,12.2,-100.8,13.1,-101.1,14.1,-101,41.8,-96.8,40.1,-62.3,75.6,-63.6,94.4,-43.1,111.5,-24.3,100.6,6.6]}},40).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-157,-145,314.1,290.1);


(lib.anim1_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 34
	this.instance = new lib.triangle6("single",0);
	this.instance.parent = this;
	this.instance.setTransform(4.1,94.5);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 203, 103, 199, 0)];
	this.instance.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[4.1,94.5,-9.2,91,-2.9,72.9,11.7,31,25.4,-11.3,30.3,-26.1,27.1,-40.9,20.1,-73.1,-5.7,-56,-20,-11.9,-34.3,32.2,-63.1,41.5,-83.9,19.6,-98.6,4.3,-102.5,-11.3]}},19).to({guide:{path:[-102.5,-11.4,-107.5,-31.2,-95.2,-51.3,-73.1,-87.6,-28.4,-92.9,-20.1,-93.9,-11.9,-94.4]}},20).to({guide:{path:[-11.7,-94.5,24.3,-97.1,58,-92,99.6,-85.7,104.8,-38.9,109.9,7,88,47.5,65.1,89.8,17.8,94.9,7.8,96,2.2,93.8]}},40).wait(1));

	// Layer 36
	this.instance_1 = new lib.rectangle6("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(11.7,-105.5);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 203, 103, 199, 0)];
	this.instance_1.cache(-50,-35,100,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[11.7,-105.4,11.7,-105.4,11.7,-105.4,-25.6,-107.5,-56.6,-99.5,-87.6,-91.4,-93.8,-59.9,-98.7,-34.9,-80.6,-16.4,-80.6,-16.4,-80.6,-16.4]}},19).to({guide:{path:[-80.5,-16.3,-83.6,-8.5,-86.8,-5.3,-90,-2.1,-93.3,-3.5,-98.5,-4.2,-100.5,1.6,-102.6,7.4,-101.5,19.6,-99.3,43.9,-77,54.4,-54.7,65,-47,50.1,-39.2,35.4,-40.1,29.5,-41.7,20.2,-37.2,13.2,-25.1,19.1,-29.7,32.3,-32.5,40.5,-33.8,49.5,-36.7,70.3,-43,90.5,-43.9,93.3,-39.3,95.8,-34.7,98.3,-24.6,100.6,-13.2,103.1,3,103.9]}},20).to({guide:{path:[3.1,103.9,15.3,104.5,30.2,104,64.9,103,83.8,80,102.8,57,75.3,33.7,68.5,27.8,64.5,20,59.1,9.2,68.3,3.9,76,12.8,82.1,16.1,88.2,19.4,92.6,17.1,101.5,12.5,100.6,-13.1,99.7,-38.8,96.5,-65.9,93.2,-93.1,74.6,-98.6,56.6,-103.9,14,-105.3]}},40).wait(1));

	// Layer 38
	this.instance_2 = new lib.octagon6("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-110.6,9.7);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 203, 103, 199, 0)];
	this.instance_2.cache(-44,-44,88,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-110.5,9.8,-108.4,34.5,-103.5,44.5,-98.3,55,-90.3,59.8,-82.4,64.5,-60.9,50.3,-50.9,43.3,-46.5,40.6,-39.1,36.1,-33,36.1,-23.9,36.1,-17.9,40.7,-11.2,45.8,-11.2,55.2,-11.2,60,-13.8,65.9,-16.4,71.8,-16.3,81.6,-16.3,91.5,0.5,93.3,17.3,95.1,36.8,98.2,56.3,101.4,73.1,97.7,89.8,94.1,96.3,80.2,97.7,77.4,99,74.5]}},19).to({guide:{path:[99,74.5,104.1,63.9,108.9,54.3,115,42.3,111.4,30.6,107.9,18.7,108,8.2,108.1,3,106.8,0.3,105.5,-2.4,102.9,-2.6,97.8,-2.9,93.3,-1.8,88.8,-0.7,85.6,-0.7,71,-0.7,64.7,-4.4,60.6,-6.8,58.7,-11.2]}},20).to({guide:{path:[58.8,-11.3,57.2,-15,57.2,-20.3,57.2,-27.1,61,-33.7,63.6,-38.2,69.6,-44.4,76.3,-51.7,78.1,-54.2,81.9,-59.6,81.9,-64.5,81.9,-71.9,73.4,-77.7,65,-83.6,48.1,-87.9,21.8,-94.6,-5.6,-94.6,-13.3,-94.6,-22.7,-92.9,-20.3,-90.8,-18.6,-88.4,-15.7,-84.5,-15.1,-80,-14.9,-78.8,-14.9,-74.7,-14.9,-60.9,-23.9,-54,-33.8,-46.4,-55.5,-46.4,-68.2,-46.4,-80,-54,-88,-59.1,-92.6,-60,-97.1,-61,-102.3,-54,-107.4,-47,-110.1,-33.6,-112.8,-20.2,-110.7,6.8,-110.5,9.5,-110.3,11.9]}},40).wait(1));

	// Layer 40
	this.instance_3 = new lib.heptagon6("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(98.3,-41);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 203, 103, 199, 0)];
	this.instance_3.cache(-45,-44,90,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[98.3,-41.1,88,-75.9,47.4,-75.5,35.1,-92.8,14.7,-97.8,-28.6,-108.4,-47.9,-71.9,-53.7,-60.9,-44.6,-54.1,-30.3,-43.4,-14.8,-40.6]}},19).to({guide:{path:[-14.9,-40.5,3.1,-37.3,22.7,-44.8,-2.7,-12.2,-45.7,-28.1,-85.5,-42.8,-88,-8.4]}},20).to({guide:{path:[-87.9,-8.4,-88,-6.9,-88.1,-5.3,-89.2,43.8,-40.1,57.1,10.9,71.3,16.6,23.2,21.8,-20.6,46.4,8.8,54.6,18.5,66.4,20.6,103.9,26.6,101.6,-20,101,-33,97.7,-43]}},40).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-157,-145,314.1,290.1);


(lib.anim1_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 36
	this.instance = new lib.circle5_4();
	this.instance.parent = this;
	this.instance.setTransform(-69.7,7.9);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 204, 203, 0)];
	this.instance.cache(-38,-38,77,77);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[-69.6,7.9,-67.8,8.2,-65.1,6.9,-60.2,4.5,-52.9,2.3,-45.6,0,-39.3,-0.4,-33,-0.8,-17.1,8.5,-21.1,20.1,-21.1,30,-21.1,39.8,-18.5,48.7,-16,57.6,10.4,65.8,33.2,72.9,46,65.5]}},19).to({guide:{path:[46.1,65.5,48.1,64.3,49.9,62.8,62.8,51.5,62.9,27.6,62.9,13.9,56.7,5.9,52.1,0,43.3,-3.3,33.5,-6.1,29.9,-7.5,23.7,-9.8,23.7,-14,23.7,-18.7,26.7,-23,30.1,-28.1,35.3,-28.1,36.5,-28.1,43.9,-24.7,51.5,-21.2,56.3,-21.2,71.3,-21.2,80.2,-30.5,82.7,-33.1,84.5,-36.2]}},20).to({guide:{path:[84.5,-36.3,89.4,-44.8,89.4,-57.1,89.4,-68.5,84.4,-74.3,79.4,-80.1,72.3,-84.2,65.2,-88.4,59.6,-91,54.1,-93.6,39.2,-100,24.3,-106.5,8.3,-106.6,-7.6,-106.6,-19.5,-92.7,-23.8,-87.6,-26.5,-81.7,-28.7,-76.6,-28.7,-73.5,-28.7,-58.6,-18.9,-57,-14,-56.6,-11.3,-55.4,-8.6,-54.1,-7.4,-46.8,-6.1,-39.4,-10.6,-39.2,-15.1,-39,-17.9,-39.6,-20.6,-40.3,-28.3,-38.2,-35.9,-36.1,-43.7,-32.7,-51.4,-29.2,-62.9,-21.5,-74.3,-13.8,-74.3,-3.2,-74.3,3,-72.1,6.3,-70.4,8.7,-66.7,7.5]}},40).wait(1));

	// Layer 38
	this.instance_1 = new lib.rectangle5_4("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(1.8,-53.4);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 204, 203, 0)];
	this.instance_1.cache(-50,-35,100,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[1.8,-53.3,-7.6,-55.9,-17.4,-54.7,-55.6,-50.5,-64.7,-14.2,-66.6,-6.6,-62.3,-0.7,-60.2,2.2,-58,4.6]}},19).to({guide:{path:[-58,4.7,-36.1,28.5,-3.4,5.8,6.3,-0.8,13.7,6.7,31.6,24.6,3.5,35.6,-14.2,42.4,-29.9,51.7,-41.1,58.2,-32.5,66.1,-4.5,91.9,31.4,78.4,36.4,76.5,40.3,73.9]}},20).to({guide:{path:[40.4,73.9,54.6,64.5,55,45.9,55.8,15.5,48.9,-13.2,48,-16.8,51.2,-17.4,65,-20.4,71.8,-3.8,74.9,3.6,82.6,5,96.8,7.8,94.5,-9.6,88.7,-53.8,47.4,-32.2,20.4,-18,6,-37.5,4.5,-45.3,3,-53,1.3,-53.5,-0.4,-53.9]}},40).wait(1));

	// Layer 40
	this.instance_2 = new lib.heptagon5_1("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-48.6,-9.5);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 204, 203, 0)];
	this.instance_2.cache(-45,-44,90,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-48.7,-9.4,-48.3,-5.6,-52.5,-2.4,-71.5,12.7,-68.8,35.7,-64.1,77,-23.5,81.8,-15.5,82.9,-10.2,78,0.5,68.4,-2.6,49.3,-0.9,50,-0.6,51.1,4.8,67.3,19.2,66.2,19.5,66.2,19.9,66.1]}},19).to({guide:{path:[20,66.1,59.9,62.3,65.1,23.1,70,-13,44,-39.9,41.8,-42.1,40.1,-44.2]}},20).to({guide:{path:[40.1,-44.3,24.5,-63.5,48.6,-70.2,47.4,-77.5,41.6,-81.6,2.1,-109.4,-42.7,-79,-85.6,-49.9,-61.6,-5.7,-59.3,-5.9,-57.7,-7.7,-54.6,-11.3,-50.9,-14.4,-47,-9.4,-49.8,-5.2]}},40).wait(1));

	// Layer 42
	this.instance_3 = new lib.triangle5_1("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-33.3,-44.9);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 204, 203, 0)];
	this.instance_3.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[-33.2,-44.8,-37.2,-58.6,-21.6,-69.5,1.7,-85.8,28.5,-75.9]}},19).to({guide:{path:[28.5,-75.9,31.4,-74.8,34.4,-73.4,41.9,-69.8,48.8,-65.2,66.9,-49.4,58.2,-23.7,48.1,6.2,13.5,4.3,2.4,4.5,-8.2,7.6,-23.8,12.1,-24.1,25.6,-24.3,30.8,-20.2,34.6,-4.9,49,15.6,39.1,41.6,26.6,68.6,30.9,71.5,31.3,73.5,33.8,78.1,39.8,80,44.9]}},20).to({guide:{path:[80,44.9,86.4,61.6,63.9,67.8,34.5,75.9,9.1,79.3,-16.5,82.6,-38.8,82.8,-61.2,83,-54.6,57.3,-48.1,31.5,-33.2,15.5,-10.7,-8.9,-29.1,-36.3,-31.3,-39.5,-32.5,-42.6]}},40).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-157,-145,314.1,290.1);


(lib.anim1_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 34
	this.instance = new lib.square4_1("single",0);
	this.instance.parent = this;
	this.instance.setTransform(14,-67.8);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 48, 50, 249, 0)];
	this.instance.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[14.1,-67.8,12.8,-64.3,11.6,-60.8,14.3,-52,22,-48,31.6,-43,41.2,-38.1,76,-23.8,81.1,6.5]}},19).to({guide:{path:[81,6.7,82.1,12.9,81.9,19.7,81.5,30.6,72.8,38,52,55.9,27.8,41.6,27.3,42.2,26.9,42.9,41.5,63.7,19,76.6,0.6,87,-15.7,72.2,-11.2,62.2,-10.8,51.1,-10.4,40.7,-14.9,31.4,-13.3,38.6,-19.2,37.9,-40.3,35.8,-43.2,13.9,-43.2,13.9,-43.2,13.9]}},20).to({guide:{path:[-43.2,13.8,-54.5,31.6,-74.9,19.4,-107.3,-0.1,-90.3,-35.4,-79.4,-58.1,-55.6,-68.2,-20.9,-83,13.9,-67.7,13.9,-67.7,13.9,-67.7]}},40).wait(1));

	// Layer 36
	this.instance_1 = new lib.rectangle4_4("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-72.7,-38);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 48, 50, 249, 0)];
	this.instance_1.cache(-50,-35,100,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-72.6,-37.9,-72.8,-36.5,-72.8,-35,-72.8,-18.4,-61.7,-7.9,-61.3,-7.4,-60.8,-7,-61.7,-5.8,-62.5,-4.4,-67,2.3,-69.4,9.6,-71.8,16.3,-71.8,21.4,-71.8,36.7,-59.5,50.5,-54.9,55.8,-49.7,59.2,-45,62.3,-42.5,62.3,-37.4,62.3,-34.4,58.3,-31.8,54.9,-31.8,51.5,-31.8,51.2,-32,49.6,-32.1,48.7,-32.3,47.4,-32.8,43.8,-32.8,42.3,-33.1,42.3,-33.3,42.3,-33.4,42.3,-33.5,42.3,-33.8,42.6,-33.8,43.4,-33.2,46.5,-32,49.6,-30.2,54.2,-27.2,58.8,-22.3,66.2,-15.7,70]}},19).to({guide:{path:[-15.6,70,-8.4,74.3,0.9,74.3,9.5,74.3,14.9,68.6,20.1,63.2,20.1,55.4,20.1,49.8,12.9,43.4,9.3,40.3,4,36.4,3.9,36.3,3.7,36.3,4.2,36.3,4.7,36.3,4.5,36.3,4.3,36.3,4.1,36.3,4,36.4,3.8,36.6,3.7,36.7,4.7,37.3,7.5,39.6,10.6,42.1,12.9,43.4,21.2,48.4,32.8,48.4,41.9,48.4,50.8,41.3,59.5,34.2,59.5,27.2,59.5,23.2,57.4,19.8,55.6,16.8,53.3,15.7,54.4,15.7,56.8,16,59.2,16.2,59.8,16.2,61.3,16.2,64.9,13.9,69.4,11.2,73.4,7,74.7,5.6,75.9,4.3]}},20).to({guide:{path:[75.8,4.1,84.7,-7,84.7,-21.8,84.7,-34.4,79.7,-46,74.6,-58.1,65.2,-67.4,43.7,-88.4,8.6,-88.4,-25.6,-88.4,-50.2,-70.6,-60.9,-62.8,-66.9,-53.3,-72.7,-44.1,-72.8,-35.4]}},40).wait(1));

	// Layer 38
	this.instance_2 = new lib.triangle4_1("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-9.4,-53);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 48, 50, 249, 0)];
	this.instance_2.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-9.3,-52.9,-0.4,-53.4,11.5,-49.4,27.2,-44.2,29.4,-35.8,30.9,-30,30.9,-27.4,30.9,-26.9,30.8,-26.5,31.3,-27.1,31.9,-28.1,34.4,-31.8,37.1,-34.3,45.7,-42.3,60.3,-42.3,71.4,-42.3,79,-33.5,85.9,-25.6,85.9,-16.4,85.9,-11.4,84.9,-7.1]}},19).to({guide:{path:[84.8,-6.9,80.9,9.2,62.4,14.3,55.5,16.2,45.4,16.6,36.3,17,35.9,17.3,48,21.3,53.8,25.1,64.4,32.2,64.4,42.4,64.4,53.8,54.9,62.7,44.1,72.9,27.1,72.9,12.3,72.9,-5.2,59.8,-8.9,57,-12.1,54.1]}},20).to({guide:{path:[-12.2,54.1,-14.8,51.7,-17.1,49.2,-18.9,47.3,-20.1,45.8,-21.2,48.5,-23.6,50.7,-29.6,56.4,-42.3,56.4,-49.4,56.4,-55.3,52.6,-63.5,47.3,-63.5,36.4,-63.5,32.6,-60.7,24.4,-58.5,17.6,-55.3,11.5,-64.8,10.8,-74.2,5.8,-87,-0.8,-80.2,-13.5,-73.5,-26.2,-71.9,-31.6,-70.4,-37,-57.3,-43.8,-44.3,-50.8,-35.1,-50.1,-25.9,-49.5,-15.2,-52.1,-13.6,-52.5,-11.8,-52.7]}},40).wait(1));

	// Layer 40
	this.instance_3 = new lib.hexagon1_4("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(32.2,44.9);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 48, 50, 249, 0)];
	this.instance_3.cache(-50,-44,101,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[32.1,44.9,31.1,44.9,30,44.9,11.4,44.9,-2.3,34.6,-6.8,31.1,-10,27.2,-12.5,24.2,-12.5,23.3,-12.5,22.6,-8.8,17.5,-5.1,12.4,-5.1,8.4,-5.1,7.1,-6.3,5.6,-7.7,3.9,-9.7,3.9,-17.6,3.9,-22.7,12.2,-25.3,16.5,-30.3,30.6,-34.9,43.5,-39.2,49,-45.7,57.4,-56,57.4,-67.3,57.4,-75.7,50,-86.4,40.7,-86.4,23,-86.4,7.3,-77.2,-3.6]}},19).to({guide:{path:[-77.2,-3.8,-74.7,-6.7,-71.7,-9.2,-66.3,-13.6,-59.9,-16.2,-54.5,-18.4,-51.1,-18.4,-49.2,-18.4,-43,-13.8,-36.9,-9.2,-31.9,-9.2,-28.9,-9.2,-26.2,-12.1,-23.2,-15.2,-23.2,-19.3,-23.2,-23.7,-25,-25.8,-26.9,-28.1,-31,-28.1,-32.3,-28.1,-35.8,-26.4,-39.1,-24.7,-41.7,-24.7,-46.5,-24.7,-51.2,-29.8,-56.2,-35.4,-56.2,-42.6,-56.2,-53.3,-44.2,-62.2,-31.2,-72,-12.5,-72,-11.4,-72,-10.4,-71.9]}},20).to({guide:{path:[-10.3,-72,13,-71.4,29.8,-57.7,31.3,-56.5,32.6,-55.2,24.9,-54.7,19.6,-51.4,11,-46.1,11,-34.3,11,-21.4,15,-17.1,18.7,-13.2,29.5,-13.2,38.6,-13.2,45.8,-17.4,47.6,-18.5,50.7,-20.4,53.2,-21.7,55.7,-21.7,61.4,-21.7,66.8,-16.6,73.1,-10.7,73.1,-1.6,73.1,15.7,66.2,27.2,55.7,44.6,30.8,44.9]}},40).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-157,-145,314.1,290.1);


(lib.anim1_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 34
	this.instance = new lib.triangle3_1("single",0);
	this.instance.parent = this;
	this.instance.setTransform(-49.9,3.4);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 251, 102, 0, 0)];
	this.instance.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[-49.8,3.3,-45.2,-1.9,-37.1,-4.5,-31,-6.4,-23.5,-6.7,-16.6,-6.7,-15.6,-6.7,-15,-6.7,-11.5,-6,-8.1,-5.4,-8.1,-5.4,-7.2,-5.4,-5.8,-7.6,-4.5,-9.8,-4.5,-11,-4.5,-14,-7.2,-16.3,-9.9,-18.5,-13.5,-18.5,-15.2,-18.5,-17.4,-16.2,-19.7,-14,-20.8,-14,-23.5,-14,-26.1,-18,-28.7,-22,-31.1,-29.9,-36.1,-45.9,-36.1,-64.5,-36.1,-76.2,-27.1,-84.7,-18.5,-93,-4.8,-94.1]}},19).to({guide:{path:[-4.7,-94.1,-2.6,-94.2,-0.3,-94.2,19,-94.2,30.3,-74,34.9,-65.8,37,-56.3,37.8,-52.4,38.2,-48.8,42.9,-47,45.2,-44.3,47.6,-41.3,47.6,-36.2,47.6,-32.8,44,-30.8,40.9,-29,36.5,-29,32.2,-29,28.1,-32.6,24.1,-36.2,24,-36.2,22.8,-36.2,21,-31.2,19.7,-27.9,19.3,-25.9]}},20).to({guide:{path:[19.2,-25.8,19,-24.9,19,-24.3,19,-20.9,21.3,-18.9,23.8,-16.6,28.4,-16.6,30.7,-16.6,34.6,-17.7,38.5,-18.9,42.9,-18.9,53.6,-18.9,61.7,-12.5,72.6,-3.8,72.6,13.6,72.6,29.6,49.5,37.2,34.4,42.2,17.7,42.2,10.8,42.2,5.1,35.9,0.6,30.9,0.6,28.8,0.6,28,0.6,27.2,2,28.7,3.2,26.9,4.2,25.5,4.2,23.8,4.2,23.1,3.3,21.8,1.9,20,-0.1,20,-1.1,20,-3.5,20.9,-6.2,21.9,-6.2,22.9,-6.2,23.5,-5.7,25.2,-5.3,26.9,-5.3,27.5,-5.3,34.9,-11.7,40.9,-19.9,48.6,-35.3,48.6,-44.1,48.6,-50.3,38.6,-55.7,29.9,-55.7,21.1,-55.7,11,-50.7,4.6]}},40).wait(1));

	// Layer 36
	this.instance_1 = new lib.circle3_4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-66.1,12.9);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 251, 102, 0, 0)];
	this.instance_1.cache(-38,-38,77,77);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-66,13,-65.3,31.1,-58.4,42,-47.4,59.1,-21,59.1,-2.6,59.1,8.5,50.6,14.9,45.6,18.1,38.2]}},19).to({guide:{path:[18.2,38.3,21.4,30.8,21.4,21,21.4,17.3,15.7,13.5,10.4,10,6.7,10,2.1,10,-0.6,7.8,-3.5,5.4,-3.5,1.1,-3.5,-0.5,2.2,-3.4,8,-6.2,11.7,-6.2,12.7,-6.2,18.6,-3.5,24.8,-0.6,24.9,-0.6,31.1,1.4,34.6,2.6,35.5,2.8,42.2,2.8,59.1,2.8,66.9,-4.9,74,-12,74,-26.2,74,-31.4,68.5,-36.6,68.5,-36.6,68.4,-36.7]}},20).to({guide:{path:[68.5,-36.7,63,-41.9,54.8,-44.6,46.7,-47.4,17.4,-34.7,23.9,-49.9,18.5,-58.8,13.1,-67.7,8.1,-71.6,1.3,-76.8,-5.5,-76.8,-16.2,-76.8,-24.8,-70.4,-35.5,-62.5,-35.5,-48.4,-35.5,-41,-31.7,-36,-29.1,-32.8,-23.3,-29.3,-16.8,-25.3,-15,-23.6,-11.2,-19.9,-11.2,-14.6,-11.2,-11.5,-13.4,-9.9,-15.2,-8.5,-18.1,-8.5,-20.1,-8.5,-21.3,-10,-21.3,-10.1,-23.1,-13.5,-25.7,-18.5,-32.7,-18.5,-46.3,-18.5,-56.1,-10.7,-66.1,-2.8,-66.1,8.4,-66.1,9.3,-66,10.1]}},40).wait(1));

	// Layer 40
	this.instance_2 = new lib.heptagon3_1("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(23.6,10.2);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 251, 102, 0, 0)];
	this.instance_2.cache(-45,-44,90,88);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[23.8,10.2,22.5,14.4,20.9,21.6,18.8,30.3,22.2,42.8,25.5,55.2,38.4,61.9,51.3,68.5,57,69.7,62.7,71,68.7,69.9,74.8,68.9,82.6,66.5,90.4,64.1,99.7,48.4,109,32.7,105.5,12.8,102,-7.1,95.3,-11.1,88.6,-15.1,69.9,-16,51.3,-16.9,41.2,-14.6,36.2,-13.5,31.8,-17.8,27.4,-22,23.7,-31.7,26.6,-45.4,30.8,-55.6]}},19).to({guide:{path:[30.6,-55.6,32.3,-59.6,34.1,-63.1,40.6,-75.5,35.5,-89.7,30.4,-103.8,13.4,-103.8,-11,-103.8,-19.1,-94.5,-24.8,-88.1,-24.8,-71.8,-24.8,-66.6,-21.6,-59.7,-18.5,-52.8,-18.5,-46.6,-18.5,-44.5,-18.8,-42.7]}},20).to({guide:{path:[-18.9,-42.6,-19.9,-36.6,-24.3,-32.6,-29.8,-27.6,-38.4,-27.6,-45.1,-27.6,-50.5,-33,-53.2,-35.7,-54.9,-36.7,-57.8,-38.3,-61.9,-38.3,-79.4,-38.3,-87.5,-23.4,-94.7,-10,-94.7,16,-94.7,42.3,-83.3,59.1,-72.3,75.5,-55.8,75.5,-49.5,75.5,-40.8,69.4,-32.8,63.8,-24.9,54.7,-17.1,45.6,-12.2,36.3,-7.1,26.3,-7.1,19.1,-7.1,17.4,-8.1,13.9,-9.2,10.3,-9.2,8.9,-9.2,4.7,-5.6,1.5,-1.6,-2,4.5,-2,7.6,-2,14.9,0.8,24.2,4.3,24.2,8.5,23.5,10.6,22.7,13.5]}},40).wait(1));

	// Layer 42
	this.instance_3 = new lib.square3_4("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(24.3,-56.5);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 251, 102, 0, 0)];
	this.instance_3.cache(-35,-35,70,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[24.4,-56.4,31.2,-58.1,38.2,-59.2,59.3,-57.8,71.4,-40.2,86.6,-18.3,70.9,0.9,60.3,13.8,45.4,7.3,34.2,2.4,27.7,5.5]}},19).to({guide:{path:[27.6,5.6,20.8,8.9,19.4,21.4,18.2,32.9,26.7,30.4,54.4,22.4,57.9,54.6,59,64.6,51.8,70.4,39.9,80.1,23.7,79.1,-11.4,78.3,-24.4,48,-26.3,43.4,-24.3,39.2,-21.7,33.7,-21.9,28.5]}},20).to({guide:{path:[-22,28.4,-22.1,25.3,-23.2,22.3,-25.1,16.9,-27.7,21.5,-35.3,34.6,-32.6,51.3,-30.9,62.3,-39.5,69.2,-43.6,72.5,-48.1,70.3,-84.3,52.1,-83.6,9.2,-83.4,-4.2,-83.5,-17.8,-83.8,-40.1,-68.7,-55.3,-40.2,-84.2,-7,-69,-19.4,-59.5,-10.6,-47.5,-8.2,-44.2,-5,-45.8,8.3,-52.2,22.3,-56]}},40).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-157,-145,314.1,290.1);


(lib.anim1_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 40
	this.instance = new lib.hexagon2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(14.1,77.1);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 102, 1, 253, 0)];
	this.instance.cache(-50,-44,101,88);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[14,76,-1.9,76.4,-18.8,66.4,-23.1,70.8,-27.4,75.2,-29,76.9,-31.2,76.7,-16.9,39.2,-13.6,20.7,-11.9,11.4,-12.8,7.9,-13.6,4.5,-17,6.9,-18.4,7.9,-19.6,9,-30,59.1,-80.2,51.5]}},17).to({guide:{path:[-80.2,51.5,-81.6,51.3,-82.9,51.1,-94.2,49.2,-96.7,37.4,-97,36.4,-97.2,35.3]}},2).to({guide:{path:[-97.1,35.3,-102.1,9.4,-93.7,-12.9]}},6).to({guide:{path:[-93.7,-12.9,-87.8,-28.7,-75.2,-42.5,-44.9,-76.4,-8.1,-80.8]}},14).to({guide:{path:[-8,-80.9,13.8,-83.5,37.6,-75.9,47.8,-72.7,55.8,-65.6,78.5,-34.7,47.3,-13.3,46.3,-12.7,45.4,-12.2,84.7,5.5,61.3,46.4,51.5,63.5,33.3,71.6,23.2,76.1,12.5,76]}},40).wait(1));

	// Layer 42
	this.instance_1 = new lib.rectangle2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-30.1,-5.1);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 102, 1, 253, 0)];
	this.instance_1.cache(-50,-35,100,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({guide:{path:[-30,-5,-12.4,3.1,-9.3,25.3,-3.9,63.9,-11.8,89,1.4,104.4,17.8,99.1,30,99.6,28.1,79.1,26.3,58.7,14.1,38.1,8.1,27.8,6.9,21.6,5.7,15.4,9.3,13.4,32,0.8,56.2,13.6,76.2,24,86.1,20,93.4,17,93.8,-4.8]}},19).to({guide:{path:[93.9,-4.9,93.9,-5.4,93.9,-5.8,94.2,-28.5,72.2,-51.7,57.9,-66.8,36.6,-76.1]}},20).to({guide:{path:[36.5,-76.1,25,-81.1,11.4,-84.3,-9.7,-90.7,-41.2,-78.5,-72.9,-66.4,-86.2,-38.4,-99.5,-10.6,-91.6,9.6,-87.7,12.8,-79,9.5,-70.2,6.2,-56.5,-3.6,-47.1,-10.4,-36.5,-7.5,-34,-6.8,-31.6,-5.8]}},40).wait(1));

	// Layer 46
	this.instance_2 = new lib.pentagon2("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-46,0);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 102, 1, 253, 0)];
	this.instance_2.cache(-40,-38,80,76);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({guide:{path:[-46,0,-42.1,-3.5,-48.8,-5.3,-53,-6.5,-57.8,-4.9,-70.4,-0.7,-80.5,-8.5,-111.8,-32.5,-75.3,-58.2,-44.1,-80.2,-11.3,-86.2]}},17).to({guide:{path:[-11.2,-86.2,-1.1,-88.1,9.1,-88.4]}},2).to({guide:{path:[9.2,-88.4,35.4,-89.2,62.5,-80.1,101.2,-61.9,99.9,-20.4,99.3,-1.7,87.9,10.3]}},20).to({guide:{path:[87.9,10.4,80.4,18.3,68.3,23.3,89,49.4,60.9,67.3,26.8,89.1,-14.4,82.8,-26.2,80.9,-37.4,77.7,-36.8,79.1,-36.2,80.6,-52.8,93.7,-64.8,70.3,-87.8,25.6,-48.6,2,-47.6,1.4,-46.9,0.8]}},40).wait(1));

	// Layer 48
	this.instance_3 = new lib.triangle2("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-10,53.7);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 102, 1, 253, 0)];
	this.instance_3.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({guide:{path:[-10.1,53.7,-16.4,42.4,-19.5,28.5,-26.7,-3.8,-54.2,-1.3,-63.5,-0.4,-71.6,2.8,-81.8,6.8,-75.6,-11,-73.1,-18,-70.3,-24.8]}},19).to({guide:{path:[-70.2,-25,-66.8,-33.1,-62.8,-40.9,-56.5,-53.1,-46.7,-69.3,-36.8,-85.6,-19.1,-90.2,-1.5,-94.9,15,-94,28.4,-93.4,38,-88.3]}},20).to({guide:{path:[38.1,-88.2,57.2,-78,60.7,-49.5,62.1,-44.6,66.3,-42.2,77.9,-35.5,87.3,-26.2,100.4,-13.1,85.7,-4.5,75.9,1.1,64.9,-2.9,64.3,17.8,60.7,38.6,54.6,72.9,22.3,79.1,13.9,80.8,7.6,75.3,-1.9,67,-8.5,56.2]}},40).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-157,-145,314.1,290.1);


(lib.anim1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Guide: Layer 6
	this.instance = new lib.heptagon("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0.2,77.7);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 48, 151, 0)];
	this.instance.cache(-45,-44,90,88);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-55.3,y:-5.4},19).to({x:-7.3,y:-100.4},20).to({x:-2.6,y:77.7},40).wait(1));

	// Layer 4
	this.instance_1 = new lib.rectangle("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-17,-34.3);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 48, 151, 0)];
	this.instance_1.cache(-50,-35,100,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-95.9,y:21.7},19).to({x:30.5,y:29.1},20).to({x:-15.6,y:-35.7},40).wait(1));

	// Layer 6
	this.instance_2 = new lib.circle("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(0.7,14.5);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 48, 151, 0)];
	this.instance_2.cache(-38,-38,77,77);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:-76.7,y:-8},19).to({x:-21.5,y:-45.5},20).to({x:0.1,y:16},40).wait(1));

	// Layer 10
	this.instance_3 = new lib.triangle("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-49.4,66.5);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 48, 151, 0)];
	this.instance_3.cache(-50,-43,100,87);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:-7.4,y:-10.5},19).to({x:19.2,y:-76.6},20).to({x:-55.4,y:56.4},40).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-97.4,-67.1,140.3,186.8);


(lib.MainAnimationPart = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// QuestionSets
	this.instance = new lib.anim1_1();
	this.instance.parent = this;
	this.instance.setTransform(94,40.5,1,1,0,0,0,66.7,66.7);
	this.instance.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 48, 151, 0)];
	this.instance.cache(-99,-69,144,191);

	this.instance_1 = new lib.anim1_2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(104.5,78.5,1,1,0,0,0,66.7,66.7);
	this.instance_1.filters = [new cjs.ColorFilter(0, 0, 0, 1, 102, 1, 253, 0)];
	this.instance_1.cache(-159,-147,318,294);

	this.instance_2 = new lib.anim1_3();
	this.instance_2.parent = this;
	this.instance_2.setTransform(103.7,126.7,1,1,0,0,0,66.7,66.7);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 251, 102, 0, 0)];
	this.instance_2.cache(-159,-147,318,294);

	this.instance_3 = new lib.anim1_4();
	this.instance_3.parent = this;
	this.instance_3.setTransform(109.9,112,1,1,0,0,0,66.7,66.7);
	this.instance_3.filters = [new cjs.ColorFilter(0, 0, 0, 1, 48, 50, 249, 0)];
	this.instance_3.cache(-159,-147,318,294);

	this.instance_4 = new lib.anim1_5();
	this.instance_4.parent = this;
	this.instance_4.setTransform(122.8,164.3,1,1,0,0,0,66.7,66.7);
	this.instance_4.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 153, 0, 0)];
	this.instance_4.cache(-159,-147,318,294);

	this.instance_5 = new lib.anim1_6();
	this.instance_5.parent = this;
	this.instance_5.setTransform(91.4,105.3,1,1,0,0,0,66.7,66.7);
	this.instance_5.filters = [new cjs.ColorFilter(0, 0, 0, 1, 204, 0, 102, 0)];
	this.instance_5.cache(-159,-147,318,294);

	this.instance_6 = new lib.anim1_7();
	this.instance_6.parent = this;
	this.instance_6.setTransform(89.1,86.9,1,1,0,0,0,66.7,66.7);
	this.instance_6.filters = [new cjs.ColorFilter(0, 0, 0, 1, 69, 152, 0, 0)];
	this.instance_6.cache(-159,-147,318,294);

	this.instance_7 = new lib.anim1_8();
	this.instance_7.parent = this;
	this.instance_7.setTransform(56.5,112.4,1,1,0,0,0,66.7,66.7);
	this.instance_7.filters = [new cjs.ColorFilter(0, 0, 0, 1, 195, 3, 0, 0)];
	this.instance_7.cache(-159,-147,318,294);

	this.instance_8 = new lib.anim1_9();
	this.instance_8.parent = this;
	this.instance_8.setTransform(103.2,88.3,1,1,0,0,0,66.7,66.7);
	this.instance_8.filters = [new cjs.ColorFilter(0, 0, 0, 1, 128, 128, 255, 0)];
	this.instance_8.cache(-159,-147,318,294);

	this.instance_9 = new lib.anim1_10();
	this.instance_9.parent = this;
	this.instance_9.setTransform(134.1,96.5,1,1,0,0,0,66.7,66.7);
	this.instance_9.filters = [new cjs.ColorFilter(0, 0, 0, 1, 246, 145, 5, 0)];
	this.instance_9.cache(-159,-147,318,294);

	this.instance_10 = new lib.anim1_11();
	this.instance_10.parent = this;
	this.instance_10.setTransform(118.1,123.1,1,1,0,0,0,66.7,66.7);
	this.instance_10.filters = [new cjs.ColorFilter(0, 0, 0, 1, 95, 118, 1, 0)];
	this.instance_10.cache(-137,-105,228,161);

	this.instance_11 = new lib.anim1_12();
	this.instance_11.parent = this;
	this.instance_11.setTransform(102.7,108.4,1,1,0,0,0,66.7,66.7);
	this.instance_11.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 51, 0, 0)];
	this.instance_11.cache(-98,-105,211,187);

	this.instance_12 = new lib.anim1_13();
	this.instance_12.parent = this;
	this.instance_12.setTransform(96,74,1,1,0,0,0,66.7,66.7);
	this.instance_12.filters = [new cjs.ColorFilter(0, 0, 0, 1, 204, 102, 0, 0)];
	this.instance_12.cache(-93,-74,184,182);

	this.instance_13 = new lib.anim1_14();
	this.instance_13.parent = this;
	this.instance_13.setTransform(159.3,78.5,1,1,0,0,0,66.7,66.7);
	this.instance_13.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 51, 255, 0)];
	this.instance_13.cache(-127,-90,145,217);

	this.instance_14 = new lib.anim1_15();
	this.instance_14.parent = this;
	this.instance_14.setTransform(87.2,103.7,1,1,0,0,0,66.7,66.7);
	this.instance_14.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 0, 51, 0)];
	this.instance_14.cache(-89,-87,178,204);

	this.instance_15 = new lib.anim1_16();
	this.instance_15.parent = this;
	this.instance_15.setTransform(111.2,86.1,1,1,0,0,0,66.7,66.7);
	this.instance_15.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 51, 51, 0)];
	this.instance_15.cache(-133,-75,233,191);

	this.instance_16 = new lib.anim1_17();
	this.instance_16.parent = this;
	this.instance_16.setTransform(101.8,100.8,1,1,0,0,0,66.7,66.7);
	this.instance_16.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 204, 0, 0)];
	this.instance_16.cache(-122,-89,231,187);

	this.instance_17 = new lib.anim1_18();
	this.instance_17.parent = this;
	this.instance_17.setTransform(129,88.3,1,1,0,0,0,66.7,66.7);
	this.instance_17.filters = [new cjs.ColorFilter(0, 0, 0, 1, 152, 12, 100, 0)];
	this.instance_17.cache(-86,-79,157,197);

	this.instance_18 = new lib.anim1_19();
	this.instance_18.parent = this;
	this.instance_18.setTransform(131,99.3,1,1,0,0,0,66.7,66.7);
	this.instance_18.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 102, 255, 0)];
	this.instance_18.cache(-127,-118,182,208);

	this.instance_19 = new lib.anim1_20();
	this.instance_19.parent = this;
	this.instance_19.setTransform(103.2,132.6,1,1,0,0,0,66.7,66.7);
	this.instance_19.filters = [new cjs.ColorFilter(0, 0, 0, 1, 102, 0, 204, 0)];
	this.instance_19.cache(-91,-96,166,149);

	this.instance_20 = new lib.anim1_21();
	this.instance_20.parent = this;
	this.instance_20.setTransform(91.1,134.1,1,1,0,0,0,66.7,66.7);

	this.instance_21 = new lib.anim1_22();
	this.instance_21.parent = this;
	this.instance_21.setTransform(89,103.2,1,1,0,0,0,66.7,66.7);

	this.instance_22 = new lib.anim1_23();
	this.instance_22.parent = this;
	this.instance_22.setTransform(103.7,117.4,1,1,0,0,0,66.7,66.7);

	this.instance_23 = new lib.anim1_24();
	this.instance_23.parent = this;
	this.instance_23.setTransform(88.4,124,1,1,0,0,0,66.7,66.7);
	this.instance_23.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 51, 51, 0)];
	this.instance_23.cache(-87,-101,201,143);

	this.instance_24 = new lib.anim1_25();
	this.instance_24.parent = this;
	this.instance_24.setTransform(106,109.8,1,1,0,0,0,66.7,66.7);

	this.instance_25 = new lib.anim1_26();
	this.instance_25.parent = this;
	this.instance_25.setTransform(90.7,69.8,1,1,0,0,0,66.7,66.7);
	this.instance_25.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 102, 0, 0)];
	this.instance_25.cache(-96,-84,194,155);

	this.instance_26 = new lib.anim1_27();
	this.instance_26.parent = this;
	this.instance_26.setTransform(110.3,124.6,1,1,0,0,0,66.7,66.7);
	this.instance_26.filters = [new cjs.ColorFilter(0, 0, 0, 1, 51, 51, 255, 0)];
	this.instance_26.cache(-126,-127,238,235);

	this.instance_27 = new lib.anim1_28();
	this.instance_27.parent = this;
	this.instance_27.setTransform(83,114.7,1,1,0,0,0,66.7,66.7);

	this.instance_28 = new lib.anim1_29();
	this.instance_28.parent = this;
	this.instance_28.setTransform(87.8,117.9,1,1,0,0,0,66.7,66.7);
	this.instance_28.filters = [new cjs.ColorFilter(0, 0, 0, 1, 102, 0, 51, 0)];
	this.instance_28.cache(-88,-126,175,192);

	this.instance_29 = new lib.anim1_30();
	this.instance_29.parent = this;
	this.instance_29.setTransform(104.6,109.8,1,1,0,0,0,66.7,66.7);

	this.instance_30 = new lib.anim1_31();
	this.instance_30.parent = this;
	this.instance_30.setTransform(91.9,109.1,1,1,0,0,0,66.7,66.7);

	this.instance_31 = new lib.anim1_32();
	this.instance_31.parent = this;
	this.instance_31.setTransform(93,125.2,1,1,0,0,0,66.7,66.7);
	this.instance_31.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 0, 0, 0)];
	this.instance_31.cache(-82,-115,179,170);

	this.instance_32 = new lib.anim1_33();
	this.instance_32.parent = this;
	this.instance_32.setTransform(91.4,132.2,1,1,0,0,0,66.7,66.7);
	this.instance_32.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 153, 0, 0)];
	this.instance_32.cache(-105,-88,213,148);

	this.instance_33 = new lib.anim1_34();
	this.instance_33.parent = this;
	this.instance_33.setTransform(91.4,115.9,1,1,0,0,0,66.7,66.7);

	this.instance_34 = new lib.anim1_35();
	this.instance_34.parent = this;
	this.instance_34.setTransform(70,129.7,1,1,0,0,0,66.7,66.7);
	this.instance_34.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 0, 102, 0)];
	this.instance_34.cache(-77,-100,170,141);

	this.instance_35 = new lib.anim1_36();
	this.instance_35.parent = this;
	this.instance_35.setTransform(58.9,120.3,1,1,0,0,0,66.7,66.7);
	this.instance_35.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 51, 0, 0)];
	this.instance_35.cache(-83,-84,202,154);

	this.instance_36 = new lib.anim1_37();
	this.instance_36.parent = this;
	this.instance_36.setTransform(67.4,135.7,1,1,0,0,0,66.7,66.7);
	this.instance_36.filters = [new cjs.ColorFilter(0, 0, 0, 1, 153, 0, 255, 0)];
	this.instance_36.cache(-114,-137,224,177);

	this.instance_37 = new lib.anim1_38();
	this.instance_37.parent = this;
	this.instance_37.setTransform(54.8,120.5,1,1,0,0,0,66.7,66.7);
	this.instance_37.filters = [new cjs.ColorFilter(0, 0, 0, 1, 51, 0, 153, 0)];
	this.instance_37.cache(-91,-121,218,191);

	this.instance_38 = new lib.anim1_39();
	this.instance_38.parent = this;
	this.instance_38.setTransform(74.6,133,1,1,0,0,0,66.7,66.7);
	this.instance_38.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 0, 0, 0)];
	this.instance_38.cache(-104,-116,204,163);

	this.instance_39 = new lib.anim1_40();
	this.instance_39.parent = this;
	this.instance_39.setTransform(90.8,116.9,1,1,0,0,0,66.7,66.7);

	this.instance_40 = new lib.anim1_41();
	this.instance_40.parent = this;
	this.instance_40.setTransform(94.4,116.5,1,1,0,0,0,66.7,66.7);

	this.instance_41 = new lib.anim2_31();
	this.instance_41.parent = this;
	this.instance_41.setTransform(120,109.6,1,1,0,0,0,66.7,66.7);

	this.instance_42 = new lib.anim2_32();
	this.instance_42.parent = this;
	this.instance_42.setTransform(107.5,125.8,1,1,0,0,0,66.7,66.7);
	this.instance_42.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 51, 0, 0)];
	this.instance_42.cache(-112,-102,213,154);

	this.instance_43 = new lib.anim2_33();
	this.instance_43.parent = this;
	this.instance_43.setTransform(92.2,100.8,1,1,0,0,0,66.7,66.7);
	this.instance_43.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 51, 255, 0)];
	this.instance_43.cache(-136,-77,238,163);

	this.instance_44 = new lib.anim2_34();
	this.instance_44.parent = this;
	this.instance_44.setTransform(108.4,121.3,1,1,0,0,0,66.7,66.7);

	this.instance_45 = new lib.anim2_35();
	this.instance_45.parent = this;
	this.instance_45.setTransform(103.7,106.7,1,1,0,0,0,66.7,66.7);
	this.instance_45.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 51, 51, 0)];
	this.instance_45.cache(-119,-97,189,168);

	this.instance_46 = new lib.anim2_36();
	this.instance_46.parent = this;
	this.instance_46.setTransform(98.4,148,1,1,0,0,0,66.7,66.7);
	this.instance_46.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 0, 204, 0)];
	this.instance_46.cache(-109,-91,184,154);

	this.instance_47 = new lib.anim2_37();
	this.instance_47.parent = this;
	this.instance_47.setTransform(121.7,87.2,1,1,0,0,0,66.7,66.7);
	this.instance_47.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 153, 0, 0)];
	this.instance_47.cache(-139,-55,205,144);

	this.instance_48 = new lib.anim2_38();
	this.instance_48.parent = this;
	this.instance_48.setTransform(94.1,140.8,1,1,0,0,0,66.7,66.7);
	this.instance_48.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 51, 255, 0)];
	this.instance_48.cache(-91,-97,168,165);

	this.instance_49 = new lib.anim2_39();
	this.instance_49.parent = this;
	this.instance_49.setTransform(123.9,122.1,1,1,0,0,0,66.7,66.7);
	this.instance_49.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 0, 102, 0)];
	this.instance_49.cache(-125,-89,189,156);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_24}]},1).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_26}]},1).to({state:[{t:this.instance_27}]},1).to({state:[{t:this.instance_28}]},1).to({state:[{t:this.instance_29}]},1).to({state:[{t:this.instance_30}]},1).to({state:[{t:this.instance_31}]},1).to({state:[{t:this.instance_32}]},1).to({state:[{t:this.instance_33}]},1).to({state:[{t:this.instance_34}]},1).to({state:[{t:this.instance_35}]},1).to({state:[{t:this.instance_36}]},1).to({state:[{t:this.instance_37}]},1).to({state:[{t:this.instance_38}]},1).to({state:[{t:this.instance_39}]},1).to({state:[{t:this.instance_40}]},1).to({state:[{t:this.instance_41}]},1).to({state:[{t:this.instance_42}]},1).to({state:[{t:this.instance_43}]},1).to({state:[{t:this.instance_44}]},1).to({state:[{t:this.instance_45}]},1).to({state:[{t:this.instance_46}]},1).to({state:[{t:this.instance_47}]},1).to({state:[{t:this.instance_48}]},1).to({state:[{t:this.instance_49}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70.1,-93.3,140.3,186.8);


// stage content:
(lib.question = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.question = new lib.MainAnimationPart();
	this.question.parent = this;
	this.question.setTransform(400,300,0.72,0.72);

	this.timeline.addTween(cjs.Tween.get(this.question).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(749.5,532.8,101.1,134.5);
// library properties:
lib.properties = {
	width: 800,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;