var introArrow, introfingure, introTitle, introHolder, introQues;
var introChoiceArr = [];
var introChoiceArr1 = [];
var highlightTweenArr = []
var setIntroCnt = 0;
var removeIntraval = 0, introCount = -1;
var ArrowXArr = [360, 430], FingXArr = [370, 440], FingX1Arr = [505, 450];
var ArrowYArr = [200, 200], FingYArr = [250, 250], FingY1Arr = [600, 600];
var introQuesArr = [];
var introChoiceArr = [];
var introArr1 = [];
var introbtnX = [, 170, 547, 930];
var introbtnY = [, 440, 485, 440];
var introqHolder = [];
var introchHolder = [];
var val = []; var val1 = [];
var TempIntroVal = 0;
function commongameintro() {

    introTitle = Title.clone();
    introArrow = arrow1.clone();
    introfingure = fingure.clone();
    introquestionText = questionText.clone();


    container.parent.addChild(introTitle)
    introTitle.visible = true;

    container.parent.addChild(introquestionText);
    introquestionText.visible = false;

    
    val = [1, 0, 2, 4, 3];

    for (i = 0; i < 5; i++) {
        introChoiceArr[i] = choice1.clone()
        container.parent.addChild(introChoiceArr[i])
        introChoiceArr[i].visible = false;
        introChoiceArr[i].gotoAndStop(val[i]);
        introChoiceArr[i].x = 380 + (i * 125);
        introChoiceArr[i].y = 600;
    } 
    

    for (i = 0; i < 5; i++) {
        introQuesArr[i] = question.clone()
        container.parent.addChild(introQuesArr[i])
        introQuesArr[i].visible = false;
        introQuesArr[i].x = 380 + (i * 125);
        introQuesArr[i].y = 320;
        introQuesArr[i].gotoAndStop(i);
    }


    introquestionText.alpha = 0;
    introquestionText.visible = true
    createjs.Tween.get(introquestionText).to({ alpha: 1 }, 1000).wait(100).call(handleComplete1_1);
}
function handleComplete1_1() {
    createjs.Tween.removeAllTweens();
    quesTween()
}

function quesTween() {

    TempIntroVal = 0;
    for (i = 0; i < 5; i++) { 
        introChoiceArr[i].visible = true; 
    }

    for (i = 0; i < 5; i++) {
        createjs.Tween.get(introQuesArr[i]).to({ visible: true }, 10, createjs.Ease.bounceOut).wait(1000).call(handleComplete2_1);
    }

}
function handleComplete2_1() {
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        createjs.Tween.removeAllTweens();
        setArrowTween();
    }
}

function handleComplete3_1() {
    introfingure.visible = false;
    for (i = 0; i < 5; i++) { 
        introChoiceArr[i].visible = false; 
        introQuesArr[i].visible = false;
    }
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        createjs.Tween.removeAllTweens();
        choiceTween();
    }
}
function choiceTween() {
    val1 = [1, 2, 4, 3];
    for (i = 0; i < 4; i++) { 

        introChoiceArr[i].visible = true;
        introChoiceArr[i].x = 445 + (i * 120);
        introChoiceArr[i].y = 600;
        introChoiceArr[i].gotoAndStop(val1[i]); 

        introQuesArr[i].visible = true;
        introQuesArr[i].x = 442 + (i * 120);
        introQuesArr[i].y = 320;
        introQuesArr[i].gotoAndStop(i + 1);
        if (i == 3) {
            createjs.Tween.get(introQuesArr[i]).to({ visible: true }, 10, createjs.Ease.bounceOut).wait(1000).call(handleComplete2_1);
        }


    }


}
function setArrowTween() {

    if (stopValue == 0) {
        console.log("setArrowTween  == stopValue")
        removeGameIntro()

    }
    else {
        container.parent.addChild(introArrow); 
        introArrow.visible = true;
        introArrow.x = ArrowXArr[TempIntroVal];
        introArrow.y = ArrowYArr[TempIntroVal];
        highlightTweenArr[0] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[0])
        highlightTweenArr[0] = createjs.Tween.get(introArrow).to({ y: ArrowYArr[TempIntroVal] + 10 }, 250)
            .to({ y: ArrowYArr[TempIntroVal] }, 250)
            .to({ y: ArrowYArr[TempIntroVal] + 10 }, 250).wait(400).call(this.onComplete1);
    }

}

function setFingureTween() {
    // fingerVal++;
    if (stopValue == 0) {
        console.log("setFingureTween  == stopValue")
        removeGameIntro()

    }
    else {

        container.parent.removeChild(introArrow);
        introArrow.visible = false;
        container.parent.addChild(introfingure);
        introfingure.visible = true; 
        introfingure.x = FingXArr[TempIntroVal];
        introfingure.y = FingYArr[TempIntroVal];

        if (TempIntroVal == 1) {
            createjs.Tween.get(introfingure).wait(100)
                .to({ x: FingX1Arr[TempIntroVal], y: FingY1Arr[TempIntroVal] }, 500);           

            createjs.Tween.get(introQuesArr[0]).wait(100)
                .to({ x: FingX1Arr[TempIntroVal], y: FingY1Arr[TempIntroVal] }, 500).call(this.onComplete2);
        }
        else {

            createjs.Tween.get(introfingure).wait(100)
                .to({ x: FingX1Arr[TempIntroVal], y: FingY1Arr[TempIntroVal] }, 500);
            createjs.Tween.get(introQuesArr[TempIntroVal]).wait(100)
                .to({ x: FingX1Arr[TempIntroVal], y: FingY1Arr[TempIntroVal] }, 500).wait(1000)
                .call(handleComplete3_1);
        }

        TempIntroVal++;
    }
}
this.onComplete1 = function (e) {
    createjs.Tween.removeAllTweens();
    // for (i = 0; i < 2; i++) {
    if (highlightTweenArr[0]) {
        console.log("onComplete1")
        container.parent.removeChild(highlightTweenArr[0]);
    }
    // }
    container.parent.removeChild(introArrow);
    if (stopValue == 0) {
        console.log("onComplete1  == stopValue")
        removeGameIntro()

    } else {
        setTimeout(setFingureTween, 200)
    }
}

this.onComplete2 = function (e) {
    createjs.Tween.removeAllTweens();
    introChoiceArr[0].visible = false;
    // // for (i = 0; i < 2; i++) {
    if (highlightTweenArr[1]) {
        console.log("onComplete2")
        container.parent.removeChild(highlightTweenArr[1]);
    }
    // // }
    container.parent.removeChild(introfingure);
    introfingure.visible = false;

    if (stopValue == 0) {
        console.log("onComplete2  == stopValue")
        removeGameIntro()

    }
    else {
        setTimeout(setCallDelay, 500)
    }


}
function setCallDelay() {
    clearInterval(removeIntraval)
    removeIntraval = 0
    setIntroCnt++
    removeGameIntro()
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        commongameintro()
        if (setIntroCnt > 0) {
            isVisibleStartBtn()
        }
    }

}
function removeGameIntro() {
    createjs.Tween.removeAllTweens();
    container.parent.removeChild(introArrow);
    introArrow.visible = false;
    container.parent.removeChild(introfingure);
    introfingure.visible = false;
    // container.parent.removeChild(introTitle);
    // introTitle.visible = false;
    container.parent.removeChild(introquestionText);
    introquestionText.visible = false;

    for (i = 0; i < 5; i++) { 
        introChoiceArr[i].visible = false;
        container.parent.removeChild(introChoiceArr[i]) 
        introQuesArr[i].visible = false;
        container.parent.removeChild(introQuesArr[i])
    }


    if (highlightTweenArr[0]) {
        highlightTweenArr[0].setPaused(false);
        container.parent.removeChild(highlightTweenArr[0]);
    }
    if (highlightTweenArr[1]) {
        highlightTweenArr[1].setPaused(false);
        container.parent.removeChild(highlightTweenArr[1]);
    }
}