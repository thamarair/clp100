

// //////////////////////////////////////////////////////===========COMMON GAME VARIABLES==========/////////////////////////////////////////////////////////////
var messageField; //Message display field
var assets = [];
var cnt = -1, qscnt = -1, ans, uans, interval, time = 180, totalQuestions = 10, answeredQuestions = 0,qchoiceCnt = 10, choiceCnt = 10, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0; var startBtn, introScrn, container, choice1, choice2, choice3, choice4, question, circleOutline, circle1Outline, boardMc, helpMc, quesMarkMc, questionText, quesHolderMc, resultLoading, preloadMc, introHintImg;
var mc, mc1, mc2, mc3, mc4, mc5, startMc, questionInterval = 0;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc, gameIntroAnimMc;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;
var bg;
var BetterLuck, Excellent, Nice, Good, Super, TryAgain;
var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle, timeOver_Status = 0; //for db //q
var isBgSound = true;
var isEffSound = true;
var url = "";
var nav = "";
var isResp = true;
var respDim = "both";
var isScale = true;
var scaleType = 1;
var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var loadProgressLabel, progresPrecentage, loaderWidth;


/////////////////////////////////////////////////////////////////////////GAME SPECIFIC VARIABLES//////////////////////////////////////////////////////////
var tween
var question1
var currentX, currentY
var objPos1, objPos2
var count = 0, count1 = 0
var checkVar, checkEndVal
var queNo
var getDragObj
var cmdText
///////////////////////////////////////////////////////////////////////GAME SPECIFIC ARRAY//////////////////////////////////////////////////////////////
var qno = [];
var chHolder = []
var choiceArr = [];
var checkArr1 = []
var checkArr2 = []
var tweenMcArr = [];
var choicePos = [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
var quesArr = []
var numArr = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
var qHolder = []
var currentObj = []
var currentObj1 = []
var currentObj2 = []
var currentObj3 = []
var chCount = 11
var chPos = []
//register key functions
///////////////////////////////////////////////////////////////////
window.onload = function (e) {
    checkBrowserSupport();
}
///////////////////////////////////////////////////////////////////
function init() {

    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);

    createLoader()
    createCanvasResize()

    stage.update();
    stage.enableMouseOver(40);
    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////

    /*Always specify the following terms as given in manifest array. 
         1. choice image name as "ChoiceImages1.png"
         2. question text image name as "questiontext.png"
     */

    assetsPath = "assets/";
    gameAssetsPath = "ShadowWar/";
    soundpath = "FA/"

    var success = createManifest();
    if (success == 1) {
        manifest.push( 
            { id: "question", src: gameAssetsPath + "question.png" },
            { id: "choice1", src: gameAssetsPath + "ChoiceImages1.png" },
            { id: "questionText", src: questionTextPath + "ShadowWar-QT.png"}
        )
        preloadAllAssets()
        stage.update();
    }
}
//=====================================================================//

function doneLoading1(event) {
    var event = assets[i];
    var id = event.item.id;
    console.log(" doneLoading ")
    loaderBar.visible = false;
    stage.update();

    if (id == "questionText") {
        questionText = new createjs.Bitmap(preload.getResult('questionText'));
        container.parent.addChild(questionText);
        questionText.visible = false;

    } 
    
    if (id == "question") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("question")],
            "frames": { "regX": 50, "height": 121, "count": 0, "regY": 50, "width": 121 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):

        });
        question = new createjs.Sprite(spriteSheet1);
        question.visible = false;
        container.parent.addChild(question);
        //
    };

    if (id == "choice1") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice1")],
            "frames": { "regX": 50, "height": 122, "count": 0, "regY": 50, "width": 122 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):

        });
        choice1 = new createjs.Sprite(spriteSheet1);
        choice1.visible = false;
        container.parent.addChild(choice1);
        //
    };

 
}

function tick(e) {

    stage.update();
}

/////////////////////////////////////////////////////////////////=======GAME START========///////////////////////////////////////////////////////////////////

function handleClick(e) {
    qno = between(0, 9);
    numArr = between(0, 9);
    CreateGameStart();
    if (gameType == 0) {
        CreateGameElements();
        getStartQuestion();
    } else {
        //for db
        getdomainpath();
        //end
    }

   
}

function CreateGameElements() {
    interval = setInterval(countTime, 1000);

    container.parent.addChild(questionText);
    questionText.visible = true; 
	
    for (i = 0; i < choiceCnt; i++) {
        choiceArr[i] = choice1.clone()
        container.parent.addChild(choiceArr[i])
        choiceArr[i].visible = false;
    }
 
    for (i = 0; i < choiceCnt; i++) {
        quesArr[i] = question.clone()
        container.parent.addChild(quesArr[i])
        quesArr[i].visible = false;
    }

    cmdText = new createjs.Text("There is no pair to match", "60px Lato-Bold", "white");
    cmdText.x = 643;
    cmdText.y = 320;
    cmdText.lineWidth = 1000;
    cmdText.textAlign = "center";
    container.parent.addChild(cmdText);
    cmdText.visible = false;

    for (i = 0; i < choiceCnt; i++) {
        checkArr1.push(i)
        checkArr2.push(i)
    }
    // if (isQuestionAllVariations) {
    //     createGameWiseQuestions()
    //      setTimeout(pickques, 200)
    // } else {
    //        setTimeout(pickques, 200)
    // }
}

function helpDisable() {
    for (i = 0; i < qchoiceCnt; i++) {
        quesArr[i].mouseEnabled = false;
    }
}

function helpEnable() {
    for (i = 0; i < qchoiceCnt; i++) {
        quesArr[i].mouseEnabled = true;
    }
}
//=================================================================================================================================//
function pickques() {
    setTimeout(pickques1, 200)
}

function pickques1() {
    pauseTimer();
    //for db
    tx = 0;
    qscnt++;
    //db
    cnt++;
    quesCnt++;

    panelVisibleFn();
    num = 0
    count = 0
    count1 = 0
    chCount = chCount - 1
    chPos = []
    checkVar = false;
 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    for (i = 0; i < choiceCnt; i++) {
        quesArr[i].visible = false
        choiceArr[i].visible = false 
    }

    switch (chCount) {
        case 1:
            for (i = 0; i < chCount; i++) {
                quesArr[i].x = 628
                quesArr[i].y = 320;

                choiceArr[i].x = 628
                choiceArr[i].y = 600; 
            }
            break;
        case 2:
            for (i = 0; i < chCount; i++) {
                quesArr[i].x = 568 + (i * 120);
                quesArr[i].y = 320;

                choiceArr[i].x = 568 + (i * 120);
                choiceArr[i].y = 600; 
            }

            break;
        case 3:
            for (i = 0; i < chCount; i++) {
                quesArr[i].x = 508 + (i * 120);
                quesArr[i].y = 320;

                choiceArr[i].x = 510 + (i * 120);
                choiceArr[i].y = 600; 
            }
            break;
        case 4:
            for (i = 0; i < chCount; i++) {
                quesArr[i].x = 442 + (i * 120);
                quesArr[i].y = 320;

                choiceArr[i].x = 445 + (i * 120);
                choiceArr[i].y = 600; 

            }
            break;
        case 5:
            for (i = 0; i < chCount; i++) {
                quesArr[i].x = 380 + (i * 125);
                quesArr[i].y = 320;

                choiceArr[i].x = 380 + (i * 125);
                choiceArr[i].y = 600;  
            }
            break;
        case 6:
            for (i = 0; i < chCount; i++) {
                quesArr[i].x = 315 + (i * 125);
                quesArr[i].y = 320;

                choiceArr[i].x = 315 + (i * 125);
                choiceArr[i].y = 600; 
            }
            break;
        case 7:
            for (i = 0; i < chCount; i++) {

                quesArr[i].x = 255 + (i * 125);
                quesArr[i].y = 320;

                choiceArr[i].x = 255 + (i * 125);
                choiceArr[i].y = 600; 
            }
            break;
        case 8:
            for (i = 0; i < chCount; i++) {
                quesArr[i].x = 190 + (i * 125);
                quesArr[i].y = 320;

                choiceArr[i].x = 190 + (i * 125);
                choiceArr[i].y = 600; 
            }
            break;
        case 9:
            for (i = 0; i < chCount; i++) {

                quesArr[i].x = 130 + (i * 125);
                quesArr[i].y = 320;

                choiceArr[i].x = 130 + (i * 125);
                choiceArr[i].y = 600; 
            }
            break;
        case 10:
            for (i = 0; i < chCount; i++) {

                quesArr[i].x = 70 + (i * 125);
                quesArr[i].y = 320;

                choiceArr[i].x = 70 + (i * 125);
                choiceArr[i].y = 600; 
            }
            break;
    }


   
	
    

    if (checkEndVal) {
        cnt += totalQuestions
        container.parent.addChild(cmdText)  
        cmdText.visible=true
        questionText.visible = false
        setTimeout(handleComplete, 1200);
    } else {
        showquestion()
    }


    
}

function showquestion() {
 
	
    for (i = 0; i < chCount; i++) {
		
		choiceArr[i].id = i
        quesArr[i].id = i
        choiceArr[i].gotoAndStop(numArr[i]);
        quesArr[i].gotoAndStop(qno[i]);
        quesArr[i].name = qno[i];
        choiceArr[i].name = numArr[i];
        choiceArr[i].visible = true
        quesArr[i].mouseEnabled = true;
        quesArr[i].visible = true;
        quesArr[i].cursor = "pointer"
        quesArr[i].scalex = quesArr[i].scaleY = .9;
        choiceArr[i].scalex = choiceArr[i].scaleY = .9;
        chPos.push({ posx: quesArr[i].x, posy: quesArr[i].y })
		
        quesArr[i].addEventListener("pressmove", onObjectDownHandler)
        quesArr[i].addEventListener("pressup", getDragUp)

    } 
	 
    rst = 0;
    gameResponseTimerStart();
    restartTimer()
}
function onObjectDownHandler(evt) {
    var p = evt.currentTarget.parent.globalToLocal(evt.stageX, evt.stageY);
    evt.currentTarget.x = p.x;
    evt.currentTarget.y = p.y;
    stage.update()
}
function getDragUp(evt) {
    var setDropTarget;
    for (i = 0; i < chCount; i++) {
        var p = choiceArr[i].globalToLocal(evt.stageX, evt.stageY);
        if (choiceArr[i].hitTest(p.x, p.y)) {
            setDropTarget = choiceArr[i]
            currentObj1.push(i)
            currentObj2.push(choiceArr[i].name)
        } else {
            // console.log("error...")
        }
    }
    getDragObj = evt.currentTarget
    container.parent.addChild(getDragObj)
    ans = evt.currentTarget.name;
    queNo = evt.currentTarget.id;
    objPos1 = chPos[queNo].posx
    objPos2 = chPos[queNo].posy

    if (intersect(evt.currentTarget, setDropTarget)) {
        getDragObj.mouseEnabled = false;
        getDragObj.visible = true;
        getDragObj.cursor = "default";
        getDragObj.x = setDropTarget.x;
        getDragObj.y = setDropTarget.y;
        uans = setDropTarget.name;
        answerSelected(evt)
        stage.update(evt)
    }
    else {
        getDragObj.x = objPos1;
        getDragObj.y = objPos2;
    }

}
function intersect(obj1, obj2) {
    if (obj2 == null) {
        getDragObj.x = objPos1;
        getDragObj.y = objPos2;
    } else {
        var objBounds1 = obj1.getTransformedBounds()
        var objBounds2 = obj2.getTransformedBounds()
        if (objBounds1.intersects(objBounds2)) {
            return true;
        } else {
            return false;
        }
    }
}

function enablechoices() {


}

function disablechoices() {

    for (i = 0; i < qchoiceCnt; i++) {
        quesArr[i].removeEventListener("pressmove", onObjectDownHandler)
        quesArr[i].removeEventListener("pressup", getDragUp)
    }
  
}

function answerSelected(e) {
    currentObj.push(queNo)
    currentObj3.push(qno[queNo])

    checkArr1.splice(checkArr1.indexOf(currentObj3[cnt]), 1)
    checkArr2.splice(checkArr2.indexOf(currentObj2[cnt]), 1)


    qno.splice(qno.indexOf(ans), 1)
    numArr.splice(numArr.indexOf(uans), 1)

    for (i = 0; i < checkArr1.length; i++) {
        for (j = 0; j < checkArr1.length; j++) {
            if (checkArr1[i] == checkArr2[j]) {
                checkVar = true;
            }
        }
    }

    if (checkVar == true) {
        console.log("There is possible")
    } else {
        console.log("There is no possible")
        checkEndVal = true

    }


    e.preventDefault();

    gameResponseTimerStop();
    if (ans == uans) {
        setTimeout(correct, 800)
        disablechoices();
    } else {
        getDragObj.x = objPos1;
        getDragObj.y = objPos2;

        getValidation("wrong");
        disablechoices();
    }
}

function correct() {
    getValidation("correct");
}