
//////////////////////////////////////////////////-------Common variables--------------/////////////////////////////////////////////////////////////////////
var messageField;		//Message display field
var assets = [];
var cnt = -1, qscnt = -1, ans, uans, interval, time = 180, totalQuestions = 10, questionCnt = 3, answeredQuestions = 0, choiceCnt = 4, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;
var startBtn, introScrn, container, choice1, choice2, choice3, choice4, question, circleOutline, circle1Outline, boardMc, helpMc, quesMarkMc, questionText, quesHolderMc, resultLoading, preloadMc;
var mc, mc1, mc2, mc3, mc4, mc5, startMc, questionInterval = 0;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc, gameIntroAnimMc, stopTimeOut;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;
var bg, introHintImg, introHintImg1, introHintImg2;
var BetterLuck, Excellent, Nice, Good, Super, TryAgain;
var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle, timeOver_Status = 0;//for db //q
var isBgSound = true;
var isEffSound = true;

var url = "";
var nav = "";
var isResp = true;
var respDim = 'both'
var isScale = true
var scaleType = 1;

var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var loadProgressLabel, progresPrecentage, loaderWidth;
/////////////////////////////////////////////////////////////////////////GAME SPECIFIC VARIABLES//////////////////////////////////////////////////////////
var animCnt1, animCnt2, animCnt1Check, animCnt2Check, enableCnt
var ansPos
var shuffleVal

///////////////////////////////////////////////////////////////////////GAME SPECIFIC ARRAY//////////////////////////////////////////////////////////////
var qno = [0, 1, 2, 3, 4, 5, 6, 0, 1, 2, 3, 4, 5, 6, 0, 1, 2, 3, 4, 5, 6];
var qno2 = []
var quesArr = []
var choiceArr = []
var sX = [460, 800]
var sY = [210, 210]
var sY1 = [397, 397]
var rand = []
var shuffleArr1 = []
//register key functions
///////////////////////////////////////////////////////////////////
window.onload = function (e) {
    checkBrowserSupport();
}
///////////////////////////////////////////////////////////////////
function init() {
    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);

    createLoader()
    createCanvasResize()

    stage.update();
    stage.enableMouseOver(40);
    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////

    /*Always specify the following terms as given in manifest array. 
         1. choice image name as "ChoiceImages1.png"
         2. question text image name as "questiontext.png"
     */

    assetsPath = "assets/";
    gameAssetsPath = "BallBounce-Level1/";
    soundpath = "FA/"

    var success = createManifest();
    if (success == 1) {
        manifest.push(
            { id: "introHintImg", src: questionTextPath+"Hint/" + "BallBounce-Level1-Hint.png" },
            { id: "chHolder", src: gameAssetsPath + "chHolder.png" },
            { id: "question", src: gameAssetsPath + "ChoiceImages1.png" },
            { id: "choice1", src: gameAssetsPath + "ChoiceImages2.png" },
            { id: "questionText", src: questionTextPath + "BallBounce-Level1-QT.png" }
        )
        preloadAllAssets()
        stage.update();
    }
}
//=====================================================================//
function doneLoading1(event) {
    var event = assets[i];
    var id = event.item.id;
    if (id == "introHintImg") {
        introHintImg = new createjs.Bitmap(preload.getResult('introHintImg'));
        container.parent.addChild(introHintImg);
        introHintImg.visible = false;
    }

    if (id == "chHolder") {
        chHolder = new createjs.Bitmap(preload.getResult('chHolder'));
        container.parent.addChild(chHolder);
        chHolder.visible = false;
    }
    if (id == "questionText") {
        var quesTextSprisheet = new createjs.SpriteSheet({
            framerate: 60,
            "images": [preload.getResult("questionText")],
            "frames": { "regX": 50, "height": 105, "count": 64, "regY": 50, "width": 564 }
        });
        questionText = new createjs.Sprite(quesTextSprisheet);
        container.parent.addChild(questionText);
        questionText.visible = false;
    }
    if (id == "choice1") {

        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice1")],
            "frames": { "regX": 50, "height": 146, "count": 0, "regY": 50, "width": 173 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        //
        choice1 = new createjs.Sprite(spriteSheet1);
        container.parent.addChild(choice1);
        choice1.visible = false;
    }

    if (id == "question") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("question")],
            "frames": { "regX": 50, "height": 119, "count": 0, "regY": 50, "width": 124 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):

        });
        question = new createjs.Sprite(spriteSheet1);
        question.visible = false;
        container.parent.addChild(question);

    };
}

function tick(e) {

    stage.update();
}

/////////////////////////////////////////////////////////////////=======GAME START========///////////////////////////////////////////////////////////////////
function handleClick(e) {
    qno = [0, 1, 2, 3, 4, 5, 6, 0, 1, 2, 3, 4, 5, 6, 0, 1, 2, 3, 4, 5, 6];
    qno.sort(randomSort)
    CreateGameStart()
    if (gameType == 0) {
        CreateGameElements()
        getStartQuestion();
    } else {
        //for db
        getdomainpath()
        //end
    }
    
}

function CreateGameElements() {

    interval = setInterval(countTime, 1000);
    questionText.visible = false;
    container.parent.addChild(questionText)
    questionText.gotoAndStop(0);
    questionText.x = 410;
    questionText.y = 100;

    chHolder.visible = false;
    container.parent.addChild(chHolder);
    for (i = 0; i < 2; i++) {
        quesArr[i] = question.clone();
        container.parent.addChild(quesArr[i]);
        quesArr[i].visible = false;
        quesArr[i].x = sX[i];
        quesArr[i].y = sY[i];
    }

    for (i = 0; i < 3; i++) {
        choiceArr[i] = choice1.clone()
        choiceArr[i].name = i;
        choiceArr[i].x = 262 + (i * 350);
        choiceArr[i].y = 590;
        container.parent.addChild(choiceArr[i]);
        choiceArr[i].visible = false;
    }



    if (isQuestionAllVariations) {

        choiceChange = [0, 1, 2, 0, 1, 2, 0, 1, 0, 1, 2, 0, 1, 2, 0, 1, 0, 1, 2, 0, 1, 2, 0, 1]
        spriteChange = [0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1]
        // setTimeout(pickques, 1000);
    } else {
        choiceChange = [0, 1, 2, 1, 0, 1, 2, 2, 0, 1]
        spriteChange = [0, 1, 0, 1, 0, 1, 0, 1, 0, 1]
        // setTimeout(pickques, 1000);
    }
    choiceChange.sort(randomSort)
    spriteChange.sort(randomSort)
}

function helpDisable() {
    for (i = 0; i < 4; i++) {
        dummyArr[i].mouseEnabled = false;
    }
}

function helpEnable() {
    for (i = 0; i < 4; i++) {
        dummyArr[i].mouseEnabled = true;
    }
}


//=================================================================================================================================//
function pickques() {
    console.log("check values")
    pauseTimer()
    //for db
    tx = 0;
    qscnt++;
    //db
    cnt++;
    quesCnt++;
    animCnt1Check = 0
    animCnt2Check = 0
    enableCnt = -1
    panelVisibleFn()

    rand = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    qno2 = between(0, 6)
	console.log("qno[cnt]....."+qno[cnt])
	console.log("qno..."+qno)	//1st ball
	console.log("ifqno2[0]...."+qno2[0])
	console.log("qno2...."+qno2)	//2nd ball
    if (qno2[0] == qno[cnt]) {
        if (qno[cnt] > 3) {
            qno2[0] = range(0, 3)
			console.log("ifqno2[0]"+qno2[0])
        } 
		else {
            qno2[0] = range(4, 6)
			console.log("elseqno2[0]"+qno2[0])
        }
    }

    animCnt1 = range(1, 9)
    animCnt2 = range(1, 9)

    if (spriteChange[cnt] == 1) {
        shuffleVal = 0
        ans = animCnt2;
		
    } else {
        shuffleVal = 1
        ans = animCnt1; 
		
    }
console.log("animCnt1....."+animCnt1)
console.log("animCnt2......."+animCnt2)
    quesArr[spriteChange[cnt]].gotoAndStop(qno[cnt]);
	console.log("spriteChange[cnt]"+spriteChange[cnt])
	console.log("quesArr[spriteChange[cnt]]"+quesArr[spriteChange[cnt]])
    quesArr[shuffleVal].gotoAndStop(qno2[0]);// for chosing 2nd ball. if comented any ball will come

    if (spriteChange[cnt] == 1) {
        rand.splice(animCnt2 - 1, 1)
    }
    else {
        rand.splice(animCnt1 - 1, 1)
    }
    rand.sort(randomSort)
    console.log(rand)
    for (i = 0; i < 3; i++) {
        choiceArr[i].gotoAndStop(rand[i])
        choiceArr[i].name = rand[i]
        choiceArr[i].visible = false;
    }
    if (spriteChange[cnt] == 1) {
        choiceArr[choiceChange[cnt]].gotoAndStop(animCnt2)
        choiceArr[choiceChange[cnt]].name = animCnt2
    } else {
        choiceArr[choiceChange[cnt]].gotoAndStop(animCnt1)
        choiceArr[choiceChange[cnt]].name = animCnt1
    }
    CreateTween()
}

function CreateTween() {
    questionText.gotoAndStop(14)
    questionText.visible = true;
    questionText.alpha = 0
    createjs.Tween.get(questionText).wait(200).to({ alpha: 1 }, 200);

    chHolder.visible = true;
    chHolder.alpha = 0
    chHolder.x = 1000
    createjs.Tween.get(chHolder).wait(400).to({ alpha: 1, x: 0 }, 200);

    var tempVal1 = 600;
    for (i = 0; i < 2; i++) {
        quesArr[i].visible = true
        quesArr[i].alpha = 0
        createjs.Tween.get(quesArr[i]).to({ alpha: 1 }, tempVal1, createjs.Ease.bounceOut);
        tempVal1 += 150;
    }

    setTimeout(bouncingFn1, 1800);
    setTimeout(bouncingFn2, 2000);
}
function AddListenerFn() {
    
    clearTimeout(repTimeClearInterval)
    for (i = 0; i < 3; i++) {
        choiceArr[i].addEventListener("click", answerSelected);
        choiceArr[i].cursor = "pointer";
        choiceArr[i].mouseEnabled = true;
    }

    rst = 0;
    gameResponseTimerStart();
    restartTimer()
}

// function enablechoices() {

//     rst = 0;
//     gameResponseTimerStart();
//     createjs.Ticker.addEventListener("tick", tick);
//     stage.update();

//     for (i = 0; i < 3; i++) {
//         choiceArr[i].addEventListener("click", answerSelected);
//         choiceArr[i].mouseEnabled = true;
//         choiceArr[i].cursor = "pointer";
//         choiceArr[i].visible = true;
//     }

// }
function disablechoices() {
    for (i = 0; i < 3; i++) {
        choiceArr[i].removeEventListener("click", answerSelected);
        choiceArr[i].mouseEnabled = false;
        choiceArr[i].cursor = "default";
    }

}


/////////////////////////////////////////////////////////////////////////

function bouncingFn1() {
    animCnt1Check++;
    if (animCnt1Check <= animCnt1) {
        createjs.Tween.get(quesArr[0]).to({ y: 210 }, 200).to({ y: 260 }, 200).to({ y: 310 }, 200).to({ y: 397 }, 200)
            .to({ y: 310 }, 200).to({ y: 260 }, 200).to({ y: 210 }, 200).call(bouncingFn1);

    } else {
        enableFn();
    }
}

function bouncingFn2() {
    animCnt2Check++;
    if (animCnt2Check <= animCnt2) {
        createjs.Tween.get(quesArr[1]).to({ y: 210 }, 200).to({ y: 260 }, 200).to({ y: 310 }, 200).to({ y: 397 }, 200)
            .to({ y: 310 }, 200).to({ y: 260 }, 200).to({ y: 210 }, 200).call(bouncingFn2);
    } else {

        enableFn();
    }

}

function enableFn() {
    enableCnt++;
    if (enableCnt == 1) {
        CreateTween1()
    }
}

function CreateTween1() {
    questionText.gotoAndStop(qno[cnt])
    var tempVal = 0;
    for (i = 0; i < 3; i++) {
        choiceArr[i].alpha = 0
        choiceArr[i].visible = true
        createjs.Tween.get(choiceArr[i]).wait(tempVal)
            .to({ visible: true, alpha: .5, rotation: 180, scaleX: .4, scaleY: .4 }, 300).to({ visible: true, alpha: .5, rotation: 90, scaleX: .4, scaleY: .4 }, 300)
            .to({ visible: true, alpha: 1, rotation: 360, scaleX: .8, scaleY: .8 }, 300)
        tempVal += 100;
    }
    repTimeClearInterval = setTimeout(AddListenerFn, 1000)
}

////////////////////////////////////////////////////////////////////////////


function answerSelected(e) {
    e.preventDefault();
    uans = e.currentTarget.name;
    gameResponseTimerStop();

    if (ans == uans) {
        if (spriteChange[cnt] == 1) {
            choiceArr[choiceChange[cnt]].gotoAndStop(animCnt2 + 10)
        }
        else {
            choiceArr[choiceChange[cnt]].gotoAndStop(animCnt1 + 10)
        }

        setTimeout(correct, 200)

    } else {

        getValidation("wrong");
        disablechoices();
    }
}

function correct() {
    getValidation("correct");
    disablechoices();
}
