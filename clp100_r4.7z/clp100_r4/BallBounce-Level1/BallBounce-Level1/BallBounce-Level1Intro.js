var introHolder, introArrow, introfingure, introTitle;
var introincrVal = 0
var introquesArr = [], introchoiceArr = []
var TempIntroVal;
var highlightTweenArr = []
var introansArr1 = []
var setIntroCnt = 0
var removeIntraval = 0
var introsX = [460, 800]
var introsY = [210, 210]
var introsY1 = [397, 397]
var introArrowX = 611, introArrowY = 470
var introfingureX = 660, introfingureY = 590
var introanimCnt1Check, introanimCnt2Check, introanimCnt1, introanimCnt2, introenableCnt
function commongameintro() {
    introanimCnt1Check = 0
    introanimCnt2Check = 0
    introenableCnt = -1
    introanimCnt1 = 3;
    introanimCnt2 = 5;

    introTitle = Title.clone();
    introArrow = arrow1.clone();
    introfingure = fingure.clone();

    introHolder = chHolder.clone();
    introquestionText = questionText.clone();
    for (i = 0; i < 3; i++) {
        introchoiceArr[i] = choice1.clone();
    }
    for (i = 0; i < 2; i++) {
        introquesArr[i] = question.clone();
    }
    container.parent.addChild(introTitle)
    introTitle.visible = true;
    container.parent.addChild(introHolder)
    introHolder.visible = false;
    container.parent.addChild(introquestionText);
    introquestionText.x = 410; introquestionText.y = 100;

    var introansVal = [2, 5, 4]
    for (i = 0; i < 3; i++) {
        container.parent.addChild(introchoiceArr[i]);
        introchoiceArr[i].visible = false;
        introchoiceArr[i].gotoAndStop(introansVal[i])
        introchoiceArr[i].x = 260 + (i * 350);
        introchoiceArr[i].y = 585;
        console.log(introchoiceArr[i].x)
        introchoiceArr[i].scaleX= introchoiceArr[i].scaleY=.8
    }

    var introansVal2 = [0, 1]	//ball img position
    for (i = 0; i < 2; i++) {
        container.parent.addChild(introquesArr[i]);
        introquesArr[i].visible = false;
        introquesArr[i].x = introsX[i]
        introquesArr[i].y = introsY[i]
        introquesArr[i].gotoAndStop(introansVal2[i])
    }

    container.parent.addChild(introHintImg)
    introHintImg.visible = false;   
    introHintImg.x=50;    introHintImg.y=200 ;

    introquestionText.gotoAndStop(14)

    introquestionText.alpha = 0;
    introquestionText.visible = true
    createjs.Tween.get(introquestionText).to({ alpha: 1 }, 1000).call(handleComplete1_1);
}
function handleComplete1_1() {
    createjs.Tween.removeAllTweens();
    quesTween()
}

function quesTween() {
    introHolder.visible = true;
    introHolder.alpha = 0
    introHolder.x = 1000
    createjs.Tween.get(introHolder).wait(100).to({ alpha: 1, x: 0 }, 500);

    var introtempVal1 = 400;
    for (i = 0; i < 2; i++) {
        introquesArr[i].visible = true		//ball
        introquesArr[i].alpha = 0
        createjs.Tween.get(introquesArr[i]).to({ alpha: 1 }, introtempVal1);
        introtempVal1 += 100;
    }
  

    introHintImg.visible = true;
    introHintImg.alpha = 0
    createjs.Tween.get(introHintImg).wait(1000).to({ alpha: 1, scaleX: 1, scaleY: 1}, 300)
        .to({ scaleX: .95, scaleY: .95 }, 300).to({ alpha: 1, scaleX: 1, scaleY: 1}, 300)
        .to({ alpha: 1, scaleX: 1, scaleY: 1}, 300)
        .to({ scaleX: .95, scaleY: .95 }, 300).to({ alpha: 1, scaleX: 1, scaleY: 1}, 300).wait(1000).call(handleComplete2_1);
}


function handleComplete2_1() {
    if (stopValue == 0) {
        removeGameIntro()

    }
    else {
        // createjs.Tween.removeAllTweens();
        introbouncingFn1()
        if (introanimCnt2Check == 0) {
            setTimeout(handleComplete3_1, 200)
        }
    }
}

function introbouncingFn1() {
    if (stopValue == 0) {
        removeGameIntro()

    }
    else {
        introanimCnt1Check++;
        if (introanimCnt1Check <= introanimCnt1) {
            createjs.Tween.get(introquesArr[0]).to({ x: 460, y: 210 }, 200).to({ x: 460, y: 260 }, 200).to({ x: 460, y: 310 }, 200).to({ x: 460, y: 397 }, 200)
                .to({ x: 460, y: 310 }, 200).to({ x: 460, y: 260 }, 200).to({ x: 460, y: 210 }, 200).call(handleComplete2_1);

        } else {
            handleComplete4_1();
        }
    }
}

function handleComplete3_1() {
    if (stopValue == 0) {
        removeGameIntro()

    }
    else {
        // createjs.Tween.removeAllTweens();
        introbouncingFn2()
    }
}
function introbouncingFn2() {
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        introanimCnt2Check++;
        if (introanimCnt2Check <= introanimCnt2) {
            createjs.Tween.get(introquesArr[1]).to({  y: 210 }, 200).to({  y: 260 }, 200).to({ y: 310 }, 200).to({  y: 397 }, 200)
                .to({  y: 310 }, 200).to({  y: 260 }, 200).to({  y: 210 }, 200).call(handleComplete3_1);
        } else {

            handleComplete4_1();
        }
    }

}
function handleComplete4_1() {
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        //  createjs.Tween.removeAllTweens();
        introenableCnt++;
        if (introenableCnt == 1) {
            choiceTween()
        }
    }
}

function choiceTween() {
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        introquestionText.gotoAndStop(1)
        var introtempVal = 0;
        for (i = 0; i < 3; i++) {
            introchoiceArr[i].alpha = 0
            introchoiceArr[i].visible = true
            if (i == 2) {
                createjs.Tween.get(introchoiceArr[i]).wait(introtempVal)
                    .to({ visible: true, alpha: .5, rotation: 180, scaleX: .4, scaleY: .4 }, 300).to({ visible: true, alpha: .5, rotation: 90, scaleX: .4, scaleY: .4 }, 300)
                    .to({ visible: true, alpha: 1, rotation: 360, scaleX: .8, scaleY: .8 }, 300).wait(400).call(handleComplete5_1)
                introtempVal += 100;
            } else {
                createjs.Tween.get(introchoiceArr[i]).wait(introtempVal)
                    .to({ visible: true, alpha: .5, rotation: 180, scaleX: .4, scaleY: .4 }, 300).to({ visible: true, alpha: .5, rotation: 90, scaleX: .4, scaleY: .4 }, 300)
                    .to({ visible: true, alpha: 1, rotation: 360, scaleX: .8, scaleY: .8 }, 300)
                introtempVal += 100;
            }
        }
    }
}
function handleComplete5_1() {
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        createjs.Tween.removeAllTweens();
        setArrowTween()
    }
}
function setArrowTween() {
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        container.parent.addChild(introArrow); 
        introArrow.visible = true;
        introArrow.x = introArrowX;
        introArrow.y = introArrowY;
        highlightTweenArr[0] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[0])

        highlightTweenArr[0] = createjs.Tween.get(introArrow).to({ y: introArrowY + 10 }, 350).to({ y: introArrowY }, 350).to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350)
            .to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350)
            .wait(400)
            .call(this.onComplete1)
    }
}

function setFingureTween() {
    if (stopValue == 0) {
        console.log("setFingureTween  == stopValue")
        removeGameIntro()

    }
    else {

        container.parent.removeChild(introArrow);
        introArrow.visible = false;
        container.parent.addChild(introfingure);
        introfingure.visible = true; 
        introfingure.x = introfingureX;
        introfingure.y = introfingureY;
        highlightTweenArr[1] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[1])
        highlightTweenArr[1] = createjs.Tween.get(introfingure)
            .to({ x: introfingureX }, 350)
            .to({ x: introfingureX - 15 }, 350)
            .to({ x: introfingureX }, 350)
            .to({ x: introfingureX - 15 }, 350)
            .wait(200)
            .call(this.onComplete2)
        setTimeout(textFn, 200)
    }
}
function textFn() {
    introchoiceArr[1].gotoAndStop(15)
}
this.onComplete1 = function (e) {
    createjs.Tween.removeAllTweens();

    if (highlightTweenArr[0]) {
        console.log("onComplete1")
        container.parent.removeChild(highlightTweenArr[0]);
    }

    container.parent.removeChild(introArrow);
    if (stopValue == 0) {
        console.log("onComplete1  == stopValue")
        removeGameIntro()

    } else {
        setTimeout(setFingureTween, 200)
    }
}

this.onComplete2 = function (e) {
    createjs.Tween.removeAllTweens();
    if (highlightTweenArr[1]) {
        console.log("onComplete2")
        container.parent.removeChild(highlightTweenArr[1]);
    }

    container.parent.removeChild(introfingure);
    introfingure.visible = false;

    if (stopValue == 0) {
        console.log("onComplete2  == stopValue")
        removeGameIntro()

    }
    else {
        setTimeout(setCallDelay, 500)
    }


}
function setCallDelay() {
    clearInterval(removeIntraval)
    removeIntraval = 0
    setIntroCnt++
    console.log("check cnt = " + setIntroCnt)
    removeGameIntro()
    if (stopValue == 0) {
        console.log("setCallDelay  == stopValue")
        removeGameIntro()
    }
    else {

        commongameintro()
        if (setIntroCnt > 0) {
            isVisibleStartBtn()
        }
    }

}
function removeGameIntro() {
    createjs.Tween.removeAllTweens();
    container.parent.removeChild(introArrow)
    introArrow.visible = false
    container.parent.removeChild(introfingure)
    introfingure.visible = false
    // container.parent.removeChild(introTitle)
    // introTitle.visible = false
    container.parent.removeChild(introHolder)
    introHolder.visible = false
    container.parent.removeChild(introquestionText)
    introquestionText.visible = false
    container.parent.removeChild(introHintImg)
    introHintImg.visible = false;
    // container.parent.removeChild(introHintImg1)
    // introHintImg1.visible = false;
    // container.parent.removeChild(introHintImg2)
    // introHintImg2.visible = false;
    for (i = 0; i < 2; i++) {
        container.parent.removeChild(introquesArr[i])
        introquesArr[i].visible = false
    }
    for (i = 0; i < 3; i++) {
        container.parent.removeChild(introchoiceArr[i])
        introchoiceArr[i].visible = false;
    }

}