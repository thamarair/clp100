//////////////////////////////////////////////////-------Common variables--------------/////////////////////////////////////////////////////////////////////
var messageField;		//Message display field
var assets = [];
var cnt = -1, qscnt = -1, ans, uans, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, choiceCnt = 3, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;
var startBtn, introScrn, container, choice1, choice2, choice3, choice4, question, circleOutline, circle1Outline, quesMarkMc, questionText, quesHolderMc, resultLoading, preloadMc;
var mc, mc1, mc2, mc3, mc4, mc5, startMc, questionInterval = 0;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc, gameIntroAnimMc;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;
var bg
var BetterLuck, Excellent, Nice, Good, Super, TryAgain;
var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle, timeOver_Status = 0;//for db //q
var isBgSound = true;
var isEffSound = true;

var url = "";
var nav = "";
var isResp = true;
var respDim = 'both'
var isScale = true
var scaleType = 1;

var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var loadProgressLabel, progresPrecentage, loaderWidth;
/////////////////////////////////////////////////////////////////////////GAME SPECIFIC VARIABLES//////////////////////////////////////////////////////////s
var currentX, currentY
var currentObj = []
var qcnt = 0
///////////////////////////////////////////////////////////////////////GAME SPECIFIC ARRAY//////////////////////////////////////////////////////////////
var qno = [];
var chpos = [];
var choiceMcArr = []
var qtext;
var btnX = []
var intr
///////////////////////////////////////////////////////////////////
//register key functions
window.onload = function (e) {
    checkBrowserSupport();
}
///////////////////////////////////////////////////////////////////
function init() {
    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);

    createLoader()
    createCanvasResize()

    stage.update();
    stage.enableMouseOver(40);
    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////

    /*Always specify the following terms as given in manifest array. 
         1. choice image name as "ChoiceImages1.png"
         2. question text image name as "questiontext.png"
     */

    assetsPath = "assets/";
    gameAssetsPath = "BallTrack-Level1/";
    soundpath = "FA/"

    var success = createManifest();
    if (success == 1) {
        manifest.push(
            { id: "questiontext", src: questionTextPath + "BallTrack-Level1-QT.png" },
            { id: "question", src: gameAssetsPath + "question.png" },
            { id: "introImg", src: gameAssetsPath + "introImg.png" }
        )
        preloadAllAssets()
        stage.update();
    }
}
//=================================================================DONE LOADING=================================================================// 
function doneLoading1(event) {

    var event = assets[i];
    var id = event.item.id;

    if (id == "introImg") {
        introImg = new createjs.Bitmap(preload.getResult('introImg'));
        container.parent.addChild(introImg);
        introImg.visible = false;
    }

    if (id == "questiontext") {
        var spriteSheet2 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("questiontext")],
            "frames": { "regX": 50, "height": 93, "count": 0, "regY": 50, "width": 770 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):

        });
        qtext = new createjs.Sprite(spriteSheet2);
        qtext.visible = false;
        container.parent.addChild(qtext);
        qtext.x = 310; qtext.y = 120;
    };


    if (id == "question") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("question")],
            "frames": { "regX": 50, "height": 562, "count": 0, "regY": 50, "width": 562 } 
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):

        });
        question = new createjs.Sprite(spriteSheet1);
        question.visible = false;
        container.parent.addChild(question);
    };
    //


}

function tick(e) {
    stage.update();
}
/////////////////////////////////////////////////////////////////=======HANDLE CLICK========//////////////////////////////////////////////////////////////    
function handleClick(e) {
    qno = between(0, 12);
    console.log(qno);
    CreateGameStart()
    if (gameType == 0) {
        CreateGameElements()
        getStartQuestion();
    } else {
        //for db
        getdomainpath()
        //end
    }

}

function CreateGameElements() {

    interval = setInterval(countTime, 1000);

}
function idle() {

    idle1()
}
function idle1() {
    
    pauseTimer()
    tx = 0;

    panelVisibleFn()
    gameQCntTxt.text = (quesCnt + 1) + "/" + totalQuestions;


    container.parent.addChild(qtext);
    qtext.gotoAndStop(0);
    qtext.visible = true;
    qtext.x = 340; qtext.y = 120;
    qtext.scaleX = qtext.scaleY = .9
    ans = "ch0";
    qtext.alpha = 0
    createjs.Tween.get(qtext).wait(600).to({ alpha: 1 }, 600)

    container.parent.addChild(question);

    question.x = 410; question.y = 200;
    question.visible = true;
    question.gotoAndStop(qno[qcnt]);
    question.y = -1200
    question.alpha = 0
    createjs.Tween.get(question).wait(1000)
        .to({ y: 200, alpha: 1 }, 1000)



    intr = setInterval(pickques, 3000);
}

//==============================================================HELP ENABLE/DISABLE===================================================================//
function helpDisable() {
    for (i = 0; i < 3; i++) {
        choiceMcArr[i].mouseEnabled = false;
    }
}

function helpEnable() {
    for (i = 0; i < 3; i++) {
        choiceMcArr[i].mouseEnabled = true;
    }
}
//==================================================================PICKQUES==========================================================================//
function pickques() {
    
    pauseTimer()
    clearInterval(intr);
    tx = 0;

    qscnt++;
    qcnt++;
    cnt++;
    quesCnt++;
    panelVisibleFn()
    //==================================================================================//
    chpos = [];
    console.log(qno[qcnt])
    ans1 = "ch1"

    ans = "ch0";
    question.gotoAndStop(qno[qcnt]);
    question.visible = true;
    qtext.gotoAndStop(0);
    qtext.visible = true;
    clearquesInterval = setInterval(createchoices, 3000);
}

function createchoices() {
    question.visible = false;
    clearInterval(clearquesInterval);
    qtext.gotoAndStop(1);
    qtext.visible = true;
    for (i = 0; i < choiceCnt; i++) {

        choiceMcArr[i] = question.clone();
        choiceMcArr[i].y = 300;
        choiceMcArr[i].name = "ch" + i;
        choiceMcArr[i].visible = true;
        choiceMcArr[i].regX = choiceMcArr[i].regY = 50
        choiceMcArr[i].gotoAndStop(qno[qcnt + i - 1]);
        container.parent.addChild(choiceMcArr[i]);
        choiceMcArr[i].scaleX = choiceMcArr[i].scaleY = .6;
    }

    chpos = between(0, 2)
    chpos.sort(randomSort);
    console.log("test= " + chpos)
    for (i = 0; i < choiceCnt; i++) {
        switch (i) {
            case 0:
                choiceMcArr[chpos[i]].x = 170;
                break;
            case 1:
                choiceMcArr[chpos[i]].x = 530;
                break;
            case 2:
                choiceMcArr[chpos[i]].x = 900;
                break;

        }

        btnX[chpos[i]] = choiceMcArr[chpos[i]].x;
    }
    // btnX = [170, 530, 900]
    console.log(qno[qcnt])
    createTween();
}
function createTween() {
    //////////////////////////////QuestionText////////////////////////////

    for (i = 0; i < 3; i++) {
        choiceMcArr[i].visible = true;
        choiceMcArr[i].alpha = 0.5;
        choiceMcArr[i].x = 500;
        createjs.Tween.get(choiceMcArr[i]).wait(100).to({ x: btnX[i], alpha: 1 }, 500, createjs.Ease.bounceOut)

    }

    repTimeClearInterval = setTimeout(AddListenerFn, 1500)
}

function AddListenerFn() {
    clearTimeout(repTimeClearInterval)
    console.log("eventlisterneer")

    for (i = 0; i < choiceCnt; i++) {
        choiceMcArr[i].addEventListener("click", answerSelected);
        choiceMcArr[i].alpha = 1;
        choiceMcArr[i].cursor = "pointer";
        choiceMcArr[i].mouseEnabled = true;
        console.log(choiceMcArr[i].x)
    }

    rst = 0;
    gameResponseTimerStart();
    restartTimer()
}
//====================================================================CHOICE ENABLE/DISABLE==============================================================//


function disablechoices() {
    for (i = 0; i < choiceCnt; i++) {
        choiceMcArr[i].removeEventListener("click", answerSelected);
        choiceMcArr[i].visible = false;
        choiceMcArr[i].alpha = .5;
        choiceMcArr[i].cursor = "default";
        choiceMcArr[i].mouseEnabled = false
    }
}


function answerSelected(e) {
    e.preventDefault();
    uans = e.currentTarget.name;
    gameResponseTimerStop();
    e.currentTarget.mouseEnabled = false;
    for (i = 0; i < choiceCnt; i++) {
        choiceMcArr[i].removeEventListener("click", answerSelected);
    }
    console.log(ans +"=ans===usans="+ uans)
    if (ans == uans) {
        currentX = e.currentTarget.x + 10
        currentY = e.currentTarget.y + 100
        e.currentTarget.visible = true;
        disableMouse()

        setTimeout(correct, 500)
    } else {
        getValidation("wrong");
        disablechoices();
    }
}

function correct() {
    getValidation("correct");
    disablechoices();
}


function disableMouse() {
    for (i = 0; i < choiceCnt; i++) {
        choiceMcArr[i].mouseEnabled = false
    }
}

function enableMouse() {

}